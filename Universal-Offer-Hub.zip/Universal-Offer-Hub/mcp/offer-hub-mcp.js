#!/usr/bin/env node
/*
 * Universal Offer Hub — MCP plugin (local, read-only)
 * ---------------------------------------------------
 * Lets an AI app on this computer (Claude Desktop, Claude Code, Gemini CLI,
 * Cursor, ...) search the offers the extension saves. It reads offers.json
 * from the live-file folder chosen in the dashboard, never writes, and never
 * goes online itself. Whatever the AI app looks up goes to that app's model
 * provider as part of the chat.
 *
 *   node mcp/offer-hub-mcp.js --dir "/Users/you/Offer Hub"
 *   (or OFFER_HUB_DIR=...; without either it reads ~/Offer Hub)
 *
 * Claude Desktop users never run this by hand: the dashboard's Download
 * plugin button packs it into "Offer Hub.mcpb" (lib/mcpb.js), which Claude
 * Desktop installs and starts with --dir set to the folder picked there.
 *
 * MCP over stdio: one JSON-RPC message per line on stdin and stdout; logs go
 * to stderr. No dependencies; Node 18 or later.
 */
"use strict";
var fs = require("fs"), path = require("path"), os = require("os"), readline = require("readline");
global.self = global;
var UOH = require("../lib/offers.js");
var CATS = require("../lib/categories.js").LIST;

var VERSION = "1.0.0";
var PROTOCOLS = ["2025-11-25", "2025-06-18", "2025-03-26", "2024-11-05"];
var DAY = 86400000;

function folder() {
  var i = process.argv.indexOf("--dir");
  var dir = i > -1 && process.argv[i + 1] ? process.argv[i + 1] : process.env.OFFER_HUB_DIR || path.join(os.homedir(), "Offer Hub");
  return path.resolve(dir.replace(/^~(?=$|[\\/])/, os.homedir()));
}
var DIR = folder(), FILE = path.join(DIR, "offers.json");

/* ---------- reading offers.json ---------- */

var cache = { mtime: 0, data: null };
function load() {
  var st;
  try { st = fs.statSync(FILE); } catch (e) {
    throw new Error("No offers saved in " + DIR + " yet. In the Offer Hub dashboard, click Open AI chat, then " +
      "Claude Desktop app, and choose a folder in step 1. Then pick that same folder in Claude's settings for Offer Hub.");
  }
  if (st.mtimeMs !== cache.mtime) cache = { mtime: st.mtimeMs, data: JSON.parse(fs.readFileSync(FILE, "utf8")) };
  return cache.data;
}

// "2026-10-31" -> the end of that day here, so an offer ending today still counts.
function endOfDay(ymd) {
  var m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(ymd || "");
  return m ? new Date(+m[1], +m[2] - 1, +m[3], 23, 59, 59, 999).getTime() : null;
}

// One row per offer: the same store and offer on several cards lists every card.
function rows(data, now, includeExpired) {
  var byKey = {}, out = [];
  (data.offers || []).forEach(function (o) {
    var end = endOfDay(o.expires);
    if (end != null && end < now && !includeExpired) return;
    var k = o.source + "|" + UOH.compact(o.merchant) + "|" + UOH.compact(o.offer), r = byKey[k];
    if (!r) {
      r = byKey[k] = { store: o.merchant, offer: o.offer, source: o.source, cards: [], category: o.category || "",
                       expires: o.expires || "", end: end, firstSeen: o.first_seen || "" };
      out.push(r);
    }
    if (o.card && r.cards.indexOf(o.card) < 0) r.cards.push(o.card);
    if (end != null && (r.end == null || end < r.end)) { r.end = end; r.expires = o.expires; }
    if (o.first_seen && (!r.firstSeen || o.first_seen < r.firstSeen)) r.firstSeen = o.first_seen;
  });
  out.forEach(function (r) {
    r.daysLeft = r.end == null ? null : Math.floor((r.end - now) / DAY);
    r.usd = UOH.estValueUsd(r.offer);
    var fs0 = endOfDay(r.firstSeen);
    r.isNew = fs0 != null && now - (fs0 - DAY + 1) < 7 * DAY;
  });
  return out;
}

function line(r) {
  return [r.store, r.offer, r.cards.join(", "),
          r.expires ? r.expires + " (" + (r.daysLeft === 0 ? "today" : r.daysLeft + "d") + ")" : "no end date",
          r.category, r.isNew ? "new" : ""].join(" | ");
}
function asOf(data) { return data.generated_at ? " Data: offers.json written " + data.generated_at.replace("T", " ").slice(0, 16) + " UTC." : ""; }

/* ---------- tools ---------- */

var TOOLS = [
  {
    name: "search_offers", title: "Search saved offers",
    description: "Search the credit card and store offers the user saved with Universal Offer Hub (Amex, Chase, Capital One, " +
      "Walgreens, Safeway). Returns one line per offer: store | offer | card(s) with nickname and ending | expiry (days left) | " +
      "category | new. Only active offers unless include_expired is true. With a query, offers matching more of its words rank " +
      "first. Answer only from these offers and say which card holds each one.",
    inputSchema: {
      type: "object",
      properties: {
        query: { type: "string", description: "Words to look for in the store, offer or category, such as \"hotel\", \"luggage\" or \"Marriott Hilton\". Any word can match. Leave out to list everything the other filters allow." },
        card: { type: "string", description: "Only offers on a card whose name, nickname or ending contains this, such as \"Platinum\", \"Mom\" or \"22001\"." },
        source: { type: "string", enum: ["Amex", "Chase", "Capital One", "Walgreens", "Safeway"] },
        category: { type: "string", enum: CATS },
        expiring_within_days: { type: "integer", minimum: 0, description: "Only offers that expire within this many days (0 = today)." },
        new_only: { type: "boolean", description: "Only offers first seen in the last 7 days." },
        min_value_usd: { type: "number", description: "Only offers worth at least this many dollars (points counted at 1 cent)." },
        sort: { type: "string", enum: ["relevance", "value", "expiry", "name"], description: "Default: relevance with a query, otherwise soonest expiry." },
        limit: { type: "integer", minimum: 1, maximum: 500, description: "Most offers to return (default 50)." },
        include_expired: { type: "boolean" }
      }
    },
    annotations: { title: "Search saved offers", readOnlyHint: true, openWorldHint: false }
  },
  {
    name: "list_cards", title: "List cards",
    description: "List the user's cards in Universal Offer Hub: issuer, card name, nickname, ending, and how many saved offers each has.",
    inputSchema: { type: "object", properties: {} },
    annotations: { title: "List cards", readOnlyHint: true, openWorldHint: false }
  },
  {
    name: "offers_overview", title: "Offers overview",
    description: "Totals for the user's saved offers: active offers, by issuer or store, expiring within 7 days, new this week, and when the data was last written.",
    inputSchema: { type: "object", properties: {} },
    annotations: { title: "Offers overview", readOnlyHint: true, openWorldHint: false }
  }
];

function searchOffers(a) {
  var data = load(), now = Date.now();
  var list = rows(data, now, !!a.include_expired);
  var words = UOH.tokenize(a.query || "");
  var cardQ = UOH.normalize(a.card || "");
  list = list.filter(function (r) {
    if (a.source && r.source !== a.source) return false;
    if (a.category && r.category !== a.category) return false;
    if (cardQ && !r.cards.some(function (c) { return UOH.normalize(c).indexOf(cardQ) > -1; })) return false;
    if (a.expiring_within_days != null && (r.daysLeft == null || r.daysLeft > a.expiring_within_days)) return false;
    if (a.new_only && !r.isNew) return false;
    if (a.min_value_usd != null && !(r.usd >= a.min_value_usd)) return false;
    if (words.length) {
      var rec = { m: r.store, v: r.offer }, extra = r.category + " " + r.cards.join(" ");
      r.score = words.reduce(function (s, w) { return s + UOH.scoreOffer(rec, [w], extra); }, 0);
      if (!r.score) return false;
    }
    return true;
  });
  var sort = a.sort || (words.length ? "relevance" : "expiry");
  var byName = function (x, y) { return x.store.localeCompare(y.store); };
  var exp = function (r) { return r.end == null ? Infinity : r.end; };
  list.sort(function (x, y) {
    if (sort === "value") return ((y.usd || 0) - (x.usd || 0)) || byName(x, y);
    if (sort === "name") return byName(x, y);
    if (sort === "expiry") return (exp(x) - exp(y)) || byName(x, y);
    return ((y.score || 0) - (x.score || 0)) || ((y.usd || 0) - (x.usd || 0)) || byName(x, y);
  });
  var limit = Math.max(1, Math.min(500, a.limit || 50)), shown = list.slice(0, limit);
  if (!shown.length) return "No saved offers match." + asOf(data);
  return list.length + (list.length === 1 ? " offer matches" : " offers match") +
    (list.length > shown.length ? " (showing the first " + shown.length + ")" : "") + "." + asOf(data) + "\n" +
    "store | offer | card(s) | expires (days left) | category | new\n" + shown.map(line).join("\n");
}

function listCards() {
  var data = load(), cards = data.cards || [];
  if (!cards.length) return "No cards saved yet." + asOf(data);
  return cards.length + " cards." + asOf(data) + "\nissuer | card | nickname | ending | saved offers\n" + cards.map(function (c) {
    return [c.issuer, c.name, c.nickname || "", c.last_digits || "", c.offers].join(" | ");
  }).join("\n");
}

function overview() {
  var data = load(), now = Date.now(), list = rows(data, now, false), by = {};
  list.forEach(function (r) { by[r.source] = (by[r.source] || 0) + 1; });
  var soon = list.filter(function (r) { return r.daysLeft != null && r.daysLeft <= 7; }).length;
  var fresh = list.filter(function (r) { return r.isNew; }).length;
  var age = data.generated_at ? (now - Date.parse(data.generated_at)) / DAY : null;
  return list.length + " active offers (one per offer, across cards)." + asOf(data) + "\n" +
    "By issuer or store: " + Object.keys(by).sort().map(function (k) { return k + " " + by[k]; }).join(", ") + "\n" +
    "Expiring within 7 days: " + soon + "\nNew this week: " + fresh +
    (age != null && age > 3 ? "\nThe data is " + Math.floor(age) + " days old: open the Offer Hub dashboard or run an autopilot to refresh it." : "");
}

function callTool(name, args) {
  var fn = { search_offers: searchOffers, list_cards: listCards, offers_overview: overview }[name];
  if (!fn) { var e = new Error("Unknown tool: " + name); e.code = -32602; throw e; }
  try { return { content: [{ type: "text", text: fn(args || {}) }], isError: false }; }
  catch (err) { return { content: [{ type: "text", text: err.message || String(err) }], isError: true }; }
}

/* ---------- JSON-RPC over stdio ---------- */

function respond(method, params) {
  switch (method) {
    case "initialize":
      return {
        protocolVersion: PROTOCOLS.indexOf(params.protocolVersion) > -1 ? params.protocolVersion : PROTOCOLS[1],
        capabilities: { tools: { listChanged: false } },
        serverInfo: { name: "offer-hub", title: "Universal Offer Hub", version: VERSION },
        instructions: "Use search_offers to answer questions about the user's saved credit card and store offers " +
          "(what expires soon, the best hotel offer, gift ideas, which card to use). Answer only from what the tools return."
      };
    case "ping": return {};
    case "tools/list": return { tools: TOOLS };
    case "tools/call": return callTool(params.name, params.arguments);
  }
  var e = new Error("Method not found: " + method);
  e.code = -32601;
  throw e;
}

function send(m) { process.stdout.write(JSON.stringify(m) + "\n"); }

if (require.main === module) {
  readline.createInterface({ input: process.stdin }).on("line", function (text) {
    if (!text.trim()) return;
    var msg;
    try { msg = JSON.parse(text); } catch (e) { send({ jsonrpc: "2.0", id: null, error: { code: -32700, message: "Parse error" } }); return; }
    if (msg.id === undefined || msg.id === null) return;           // a notification: nothing to answer
    try { send({ jsonrpc: "2.0", id: msg.id, result: respond(msg.method, msg.params || {}) }); }
    catch (err) { send({ jsonrpc: "2.0", id: msg.id, error: { code: err.code || -32603, message: err.message } }); }
  }).on("close", function () { process.exit(0); });
  process.stderr.write("Offer Hub MCP plugin " + VERSION + " reading " + FILE + "\n");
}

module.exports = { respond: respond, TOOLS: TOOLS };
