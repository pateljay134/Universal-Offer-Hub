/*
 * Universal Offer Hub — Background service worker
 * -------------------------------------------------
 * Watches every tab navigation and, when the page's hostname matches a merchant
 * stored in the local hub database, injects an in-page toast listing the
 * matching offers (value, card, expiry) so the user doesn't forget to use the
 * right card.
 *
 * Privacy:
 *   - The service worker reads only `tab.url`'s hostname, locally.
 *   - The match is computed against `chrome.storage.local`. Nothing is sent
 *     anywhere over the network.
 *   - The user can disable the entire feature from the popup; we honour
 *     `UOH_Settings.notifierOff` here.
 *   - Skipped on chrome://, file://, about:, the four issuer sites (the
 *     autopilot UI already handles those), and on pages where the extension
 *     can't inject (chrome-extension://, view-source:, etc — the catch handles
 *     those without spamming the console).
 */

// Compound country-code TLDs whose registrable domain sits three labels deep.
// e.g. "bbc.co.uk" → brand is "bbc", not "co". Only the most common ones; the
// long-tail of suffixes lives in the Public Suffix List which we don't ship.
var UOH_COMPOUND_TLDS = new Set([
  "co.uk","co.jp","co.kr","co.in","co.nz","co.za","co.id","co.il",
  "com.au","com.br","com.mx","com.sg","com.hk","com.tw","com.cn","com.tr","com.ar"
]);

// Skip the four issuer domains — the autopilot already runs on them.
var UOH_SOURCE_DOMAINS = /(chase|americanexpress|capitalone|capitaloneoffers|capitaloneshopping|walgreens)\.com$/i;

// Search-engine hostnames. Most users land here as a starting point, not a
// shopping destination — surfacing every Google offer on every Google search
// is just noise. Subdomains like `store.google.com` aren't in this set, so
// real Google product pages still get a toast.
var UOH_SEARCH_HOSTS = new Set([
  "google.com","www.google.com",
  "google.co.uk","www.google.co.uk","google.co.in","www.google.co.in",
  "google.co.jp","www.google.co.jp","google.de","www.google.de",
  "google.fr","www.google.fr","google.ca","www.google.ca",
  "google.com.au","www.google.com.au","google.com.br","www.google.com.br",
  "bing.com","www.bing.com",
  "duckduckgo.com","www.duckduckgo.com",
  "search.yahoo.com","yahoo.com","www.yahoo.com",
  "search.brave.com",
  "ecosia.org","www.ecosia.org",
  "ask.com","www.ask.com",
  "startpage.com","www.startpage.com",
  "yandex.com","www.yandex.com","yandex.ru","www.yandex.ru",
  "baidu.com","www.baidu.com",
  "qwant.com","www.qwant.com"
]);

// Per-tab dedup so we don't re-show the same toast on every soft-reload /
// hash change. Map<tabId, hostname>. In-memory only; resets when the service
// worker is recycled, which is fine for our use case.
var UOH_shownPerTab = new Map();

/* Pull the registrable "brand" label out of a hostname.
 *   play.google.com   → "google"   (subdomain "play" ignored)
 *   www.bestbuy.com   → "bestbuy"
 *   bbc.co.uk         → "bbc"      (compound TLD aware)
 *   shop.adidas.com   → "adidas"
 *   web.whatsapp.com  → "whatsapp"
 *
 * We only ever match against this single label. Subdomains like "play",
 * "mail", or "docs" are PRODUCT lines, not brands — using them as match
 * targets is what made "play.google.com" surface Coldplay offers.
 */
function uohExtractBrand(hostname) {
  if (!hostname) return null;
  var parts = String(hostname).toLowerCase().split(".").filter(Boolean);
  if (parts.length < 2) return null;
  var lastTwo = parts.slice(-2).join(".");
  if (UOH_COMPOUND_TLDS.has(lastTwo) && parts.length >= 3) {
    return parts[parts.length - 3];
  }
  return parts[parts.length - 2];
}

/* Whole-word containment: is `word` present in `text` with a non-alphanumeric
 * (or string-edge) boundary on both sides? Avoids matching "play" inside
 * "coldplay" while still matching "Google" inside "Google Play". */
function uohContainsAsWord(text, word) {
  if (!text || !word) return false;
  var idx = text.indexOf(word);
  while (idx !== -1) {
    var beforeOk = idx === 0 || !/[a-z0-9]/.test(text.charAt(idx - 1));
    var afterChar = text.charAt(idx + word.length);
    var afterOk = afterChar === "" || !/[a-z0-9]/.test(afterChar);
    if (beforeOk && afterOk) return true;
    idx = text.indexOf(word, idx + 1);
  }
  return false;
}

/* Three-tier matching. An offer matches ONLY when at least one tier fires:
 *   1. Compact equality           ("bestbuy" === "bestbuy")
 *      → handles single-word brands joined into one merchant token.
 *   2. Whole-word containment     ("google" is a word inside "Google Play")
 *      → handles multi-word merchant names that start/contain the brand.
 *   3. Brand head-prefixed by mc  (brand "googleplaystore" starts with mc "google",
 *      gap ≤ 12 chars, mc ≥ 5 chars)
 *      → handles compound brand domains. Length floor + gap cap keep "apple"
 *      from matching "pineapple"-style sites.
 *
 * Substring matching (the old behaviour) is intentionally GONE — that's what
 * caused "play.google.com" to surface "Coldplay" offers.
 */
function uohFindMatches(hostname, db) {
  if (!hostname || !db) return [];
  var brand = uohExtractBrand(hostname);
  if (!brand) return [];
  brand = brand.replace(/[^a-z0-9]/g, "");
  if (brand.length < 3) return [];

  var matches = [];
  var keys = Object.keys(db);
  for (var i = 0; i < keys.length; i++) {
    var offer = db[keys[i]];
    if (!offer || !offer.m) continue;
    var merchantLower = String(offer.m).toLowerCase();
    var merchantCompact = merchantLower.replace(/[^a-z0-9]/g, "");
    if (merchantCompact.length < 3) continue;

    var hit = false;
    if (merchantCompact === brand) hit = true;
    else if (uohContainsAsWord(merchantLower, brand)) hit = true;
    else if (
      merchantCompact.length >= 5 &&
      brand.indexOf(merchantCompact) === 0 &&
      brand.length - merchantCompact.length <= 12
    ) hit = true;

    if (hit) matches.push(offer);
  }
  return matches;
}

chrome.tabs.onUpdated.addListener(function (tabId, changeInfo, tab) {
  // Only act when the page has finished loading and we actually have a URL
  // we can reason about.
  if (changeInfo.status !== "complete") return;
  if (!tab || !tab.url || !/^https?:/i.test(tab.url)) return;

  var hostname;
  try { hostname = new URL(tab.url).hostname; } catch (e) { return; }
  if (!hostname || UOH_SOURCE_DOMAINS.test(hostname)) return;
  if (UOH_SEARCH_HOSTS.has(hostname)) return;

  chrome.storage.local.get(["UOH_Database", "UOH_Settings"], function (res) {
    if (chrome.runtime.lastError) return;
    var settings = res.UOH_Settings || {};
    if (settings.notifierOff) return;

    var matches = uohFindMatches(hostname, res.UOH_Database || {});
    if (!matches.length) {
      UOH_shownPerTab.delete(tabId);
      return;
    }

    // Dedup: don't show again for the same (tab, hostname) pair.
    if (UOH_shownPerTab.get(tabId) === hostname) return;
    UOH_shownPerTab.set(tabId, hostname);

    // Drop already-expired offers and sort soonest-expiry first so the most
    // urgent matches appear at the top of the toast.
    var now = Date.now();
    var active = matches.filter(function (o) {
      return o.expiresTs == null || o.expiresTs >= now;
    });
    if (!active.length) return;
    active.sort(function (a, b) {
      var ae = a.expiresTs == null ? Infinity : a.expiresTs;
      var be = b.expiresTs == null ? Infinity : b.expiresTs;
      return ae - be;
    });

    chrome.scripting.executeScript({
      target: { tabId: tabId },
      func: uohRenderToast,
      args: [{ matches: active }],
      world: "ISOLATED"
    }).catch(function () {
      // Restricted pages (chrome://, store pages, etc) refuse injection.
      // Silently ignore — nothing the user can do about it.
    });
  });
});

chrome.tabs.onRemoved.addListener(function (tabId) {
  UOH_shownPerTab.delete(tabId);
});

/* The function injected into the target tab. Must be self-contained — runs
 * in ISOLATED world with no access to service-worker globals. */
function uohRenderToast(payload) {
  if (document.getElementById("uoh-notifier")) return;
  var matches = (payload && payload.matches) || [];
  if (!matches.length) return;

  var SOURCE_COLORS = {
    Chase: "#1565C0",
    Amex: "#00838F",
    "Capital One": "#558B2F",
    Walgreens: "#6A1B9A"
  };

  function esc(s) {
    return String(s == null ? "" : s)
      .replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;").replace(/'/g, "&#39;");
  }

  function expiryLabel(o, now) {
    if (o.expiresTs != null) {
      var d = Math.floor((o.expiresTs - now) / 86400000);
      if (d < 0) return "expired";
      if (d === 0) return "expires today";
      if (d === 1) return "1 day left";
      if (d <= 30) return d + " days left";
      return new Date(o.expiresTs).toLocaleDateString();
    }
    return o.days ? String(o.days) : "";
  }

  var root = document.createElement("div");
  root.id = "uoh-notifier";
  root.style.cssText = [
    "all: initial",
    "position: fixed", "top: 20px", "right: 20px",
    "z-index: 2147483647",
    "width: 340px",
    "background: #1a232f", "color: #f1f5f9",
    "font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif",
    "font-size: 13px", "line-height: 1.4",
    "border: 1px solid #2d3a4c", "border-radius: 10px",
    "box-shadow: 0 12px 36px rgba(0,0,0,0.45)",
    "overflow: hidden", "opacity: 0",
    "transition: opacity 220ms ease"
  ].join(";");

  var headerHtml =
    '<div style="padding:10px 12px;display:flex;align-items:center;justify-content:space-between;background:linear-gradient(135deg,#3b82f6,#8b5cf6);">' +
      '<div style="font-weight:700;font-size:13px;letter-spacing:0.2px;">' +
        '🎯 You have ' + matches.length + ' card offer' + (matches.length === 1 ? '' : 's') + ' for this site' +
      '</div>' +
      '<div id="uoh-notifier-close" role="button" tabindex="0" aria-label="Dismiss" style="cursor:pointer;font-size:18px;line-height:1;opacity:0.85;padding:0 4px;">×</div>' +
    '</div>';

  var now = Date.now();
  var visible = matches.slice(0, 6);
  var rowsHtml = visible.map(function (o) {
    var color = SOURCE_COLORS[o.site] || "#475569";
    var card = o.card ? esc(o.card) : "";
    var expTxt = expiryLabel(o, now);
    return (
      '<div style="padding:9px 10px;margin:2px 4px;border-radius:6px;border-bottom:1px solid rgba(255,255,255,0.04);">' +
        '<div style="display:flex;align-items:center;gap:6px;margin-bottom:4px;flex-wrap:wrap;">' +
          '<span style="background:' + color + ';color:#fff;font-size:9px;font-weight:700;padding:2px 6px;border-radius:4px;text-transform:uppercase;letter-spacing:0.4px;">' + esc(o.site) + '</span>' +
          '<span style="font-weight:700;font-size:13px;">' + esc(o.m) + '</span>' +
        '</div>' +
        '<div style="color:#4ade80;font-size:12px;font-weight:600;margin-bottom:2px;">' + esc(o.v) + '</div>' +
        '<div style="color:#8da0b4;font-size:11px;">' +
          card +
          (card && expTxt ? ' • ' : '') +
          esc(expTxt) +
        '</div>' +
      '</div>'
    );
  }).join("");

  var moreHtml = matches.length > visible.length
    ? '<div style="padding:6px 12px 10px;color:#8da0b4;font-size:11px;text-align:center;">+ ' + (matches.length - visible.length) + ' more in the hub</div>'
    : "";

  root.innerHTML =
    headerHtml +
    '<div style="padding:4px 0;max-height:340px;overflow-y:auto;">' + rowsHtml + moreHtml + '</div>';

  // Attach to <html> instead of <body>. Next.js / React / Vue commonly replace
  // the entire <body> children tree when they hydrate, which used to wipe the
  // toast after 1–3 seconds on sites like oakley.com and ray-ban.com. <html>'s
  // children are virtually never touched by SPA frameworks, so the toast
  // survives hydration there.
  var host = document.documentElement || document.body;
  host.appendChild(root);

  // Belt-and-suspenders: if a particularly aggressive page DOES remove the
  // toast (e.g., a content-blocker or a rerender that wipes documentElement's
  // children too), re-attach it up to 3 times. Hard cap avoids an infinite
  // loop with hostile pages.
  var reattachBudget = 3;
  var observer = null;
  if (typeof MutationObserver === "function") {
    observer = new MutationObserver(function () {
      if (!root.isConnected && reattachBudget > 0) {
        reattachBudget--;
        try { host.appendChild(root); } catch (e) { /* host may be gone */ }
      }
    });
    try {
      observer.observe(host, { childList: true, subtree: false });
    } catch (e) {}
  }

  // Fade in.
  requestAnimationFrame(function () { root.style.opacity = "1"; });

  var timer = null;
  var dismiss = function () {
    if (observer) { try { observer.disconnect(); } catch (e) {} observer = null; }
    if (timer) { clearTimeout(timer); timer = null; }
    root.style.opacity = "0";
    setTimeout(function () { if (root.parentNode) root.parentNode.removeChild(root); }, 280);
  };
  var schedule = function () { timer = setTimeout(dismiss, 8000); };

  var closeBtn = root.querySelector("#uoh-notifier-close");
  if (closeBtn) {
    closeBtn.addEventListener("click", dismiss);
    closeBtn.addEventListener("keydown", function (e) {
      if (e.key === "Enter" || e.key === " ") { e.preventDefault(); dismiss(); }
    });
  }
  root.addEventListener("mouseenter", function () { if (timer) { clearTimeout(timer); timer = null; } });
  root.addEventListener("mouseleave", schedule);
  schedule();
}
