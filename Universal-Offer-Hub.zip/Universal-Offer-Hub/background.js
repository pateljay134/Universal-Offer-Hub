/*
 * Universal Offer Hub — Background service worker
 * -------------------------------------------------
 * 1. Offer reminder: watches every tab navigation and, when the page's
 *    hostname matches a merchant stored in the local hub database, injects an
 *    in-page toast listing the matching offers (value, card, expiry) so the
 *    user doesn't forget to use the right card.
 * 2. The only writer of the hub. Every save from the autopilots, and every
 *    clean-up, clear or settings change from the popup and dashboard, runs
 *    through one promise queue (uohQueue), so two tabs saving at once can't
 *    drop each other's updates and a save in flight can't bring cleared data
 *    back. Each offer's first-seen time is set here, once.
 * 3. Hosts the background auto-add runs (lib/autorun.js), one issuer file
 *    per issuer in lib/issuers/.
 *
 * Privacy:
 *   - The service worker reads only `tab.url`'s hostname, locally.
 *   - The match is computed against `chrome.storage.local`. Nothing is sent
 *     anywhere over the network.
 *   - The user can disable the reminder from the popup; we honour
 *     `UOH_Settings.notifierOff` here.
 *   - Skipped on chrome://, file://, about:, the issuer sites (the
 *     autopilot UI already handles those), and on pages where the extension
 *     can't inject (chrome-extension://, view-source:, etc — the catch handles
 *     those without spamming the console).
 */

importScripts("lib/sources.js", "lib/offers.js", "lib/categories.js", "lib/livefile.js",
              "lib/issuers/amex.js", "lib/issuers/chase.js", "lib/issuers/capitalone.js", "lib/autorun.js");

// Compound country-code TLDs whose registrable domain sits three labels deep.
// e.g. "bbc.co.uk" → brand is "bbc", not "co". Only the most common ones; the
// long-tail of suffixes lives in the Public Suffix List which we don't ship.
var UOH_COMPOUND_TLDS = new Set([
  "co.uk","co.jp","co.kr","co.in","co.nz","co.za","co.id","co.il",
  "com.au","com.br","com.mx","com.sg","com.hk","com.tw","com.cn","com.tr","com.ar"
]);

// Skip the four issuer domains — the autopilot already runs on them.
var UOH_SOURCE_DOMAINS = /(chase|americanexpress|capitalone|capitaloneoffers|capitaloneshopping|walgreens|safeway)\.com$/i;

// Search-engine hostnames. Most users land here as a starting point, not a
// shopping destination — surfacing every Google offer on every Google search
// is just noise. Subdomains like `store.google.com` aren't in this set, so
// real Google product pages still get a toast.
var UOH_SEARCH_HOSTS = new Set([
  "google.com","www.google.com",
  "google.co.uk","www.google.co.uk","google.co.in","www.google.co.in",
  "google.co.jp","www.google.co.jp","google.de","www.google.de",
  "google.fr","www.google.fr","google.ca","www.google.ca",
  "google.com.au","www.google.com.au","google.com.br","www.google.com.br",
  "bing.com","www.bing.com",
  "duckduckgo.com","www.duckduckgo.com",
  "search.yahoo.com","yahoo.com","www.yahoo.com",
  "search.brave.com",
  "ecosia.org","www.ecosia.org",
  "ask.com","www.ask.com",
  "startpage.com","www.startpage.com",
  "yandex.com","www.yandex.com","yandex.ru","www.yandex.ru",
  "baidu.com","www.baidu.com",
  "qwant.com","www.qwant.com"
]);

// Google productivity / non-commerce subdomains. These resolve to the brand
// "google" but the user is doing work / email / video calls / docs there —
// surfacing Google Store offers in the middle of a Meet call is just noise.
// The Google Store and similar commerce subdomains are deliberately NOT in
// this set (e.g. store.google.com, play.google.com).
var UOH_SKIP_HOSTS = new Set([
  "docs.google.com","drive.google.com","sheets.google.com",
  "slides.google.com","forms.google.com","sites.google.com",
  "gemini.google.com","bard.google.com",
  "meet.google.com","calendar.google.com",
  "mail.google.com","photos.google.com","contacts.google.com",
  "keep.google.com","chat.google.com","groups.google.com",
  "maps.google.com","translate.google.com","news.google.com",
  "scholar.google.com","accounts.google.com","myaccount.google.com",
  "analytics.google.com","ads.google.com","adsense.google.com",
  "support.google.com","workspace.google.com","cloud.google.com",
  "console.cloud.google.com","developers.google.com",
  "earth.google.com","voice.google.com","fi.google.com",
  "classroom.google.com","admin.google.com","passwords.google.com",
  "podcasts.google.com","one.google.com","domains.google.com",
  "trends.google.com","analytics.google.com","tagmanager.google.com",
  // Microsoft / Apple / Meta productivity equivalents for the same reason.
  "outlook.live.com","outlook.office.com","outlook.office365.com",
  "teams.microsoft.com","onedrive.live.com","office.com","www.office.com",
  "icloud.com","www.icloud.com",
  "messenger.com","www.messenger.com"
]);

// Per-tab dedup so we don't re-show the same toast on every soft-reload /
// hash change. Map<tabId, hostname>. In-memory only; resets when the service
// worker is recycled, which is fine for our use case.
var UOH_shownPerTab = new Map();

/* Pull the registrable "brand" label out of a hostname.
 *   play.google.com   → "google"   (subdomain "play" ignored)
 *   www.bestbuy.com   → "bestbuy"
 *   bbc.co.uk         → "bbc"      (compound TLD aware)
 *   shop.adidas.com   → "adidas"
 *   web.whatsapp.com  → "whatsapp"
 *
 * We only ever match against this single label. Subdomains like "play",
 * "mail", or "docs" are PRODUCT lines, not brands — using them as match
 * targets is what made "play.google.com" surface Coldplay offers.
 */
function uohExtractBrand(hostname) {
  if (!hostname) return null;
  var parts = String(hostname).toLowerCase().split(".").filter(Boolean);
  if (parts.length < 2) return null;
  var lastTwo = parts.slice(-2).join(".");
  if (UOH_COMPOUND_TLDS.has(lastTwo) && parts.length >= 3) {
    return parts[parts.length - 3];
  }
  return parts[parts.length - 2];
}

/* Whole-word containment: is `word` present in `text` with a non-alphanumeric
 * (or string-edge) boundary on both sides? Avoids matching "play" inside
 * "coldplay" while still matching "Google" inside "Google Play". */
function uohContainsAsWord(text, word) {
  if (!text || !word) return false;
  var idx = text.indexOf(word);
  while (idx !== -1) {
    var beforeOk = idx === 0 || !/[a-z0-9]/.test(text.charAt(idx - 1));
    var afterChar = text.charAt(idx + word.length);
    var afterOk = afterChar === "" || !/[a-z0-9]/.test(afterChar);
    if (beforeOk && afterOk) return true;
    idx = text.indexOf(word, idx + 1);
  }
  return false;
}

/* Four-tier matching. An offer matches ONLY when at least one tier fires:
 *   1. Compact equality           ("bestbuy" === "bestbuy")
 *      → handles single-word brands joined into one merchant token.
 *   2. Whole-word containment     ("google" is a word inside "Google Play")
 *      → handles multi-word merchant names that start/contain the brand.
 *   3. Brand head-prefixed by mc  (brand "googleplaystore" starts with mc "google",
 *      gap ≤ 12 chars, mc ≥ 5 chars)
 *      → handles compound brand domains. Length floor + gap cap keep "apple"
 *      from matching "pineapple"-style sites.
 *   4. The offer's saved store domain names the same brand (only Capital One
 *      Shopping saves one): its store names often aren't the site's name.
 *
 * Substring matching (the old behaviour) is intentionally GONE — that's what
 * caused "play.google.com" to surface "Coldplay" offers.
 */
function uohFindMatches(hostname, db) {
  if (!hostname || !db) return [];
  var brand = uohExtractBrand(hostname);
  if (!brand) return [];
  brand = brand.replace(/[^a-z0-9]/g, "");
  // Allow 2-char brands. Real domains exist for H&M (hm.com), LG (lg.com),
  // HP (hp.com), GE (ge.com), BJ's (bj.com), American Airlines (aa.com), etc.
  // Tiers 1 + 2 still require either exact compact equality or a whole-word
  // hit, so noise from a 2-char token landing inside an unrelated merchant
  // name (e.g. "ghminc") stays filtered.
  if (brand.length < 2) return [];

  var matches = [];
  var keys = Object.keys(db);
  for (var i = 0; i < keys.length; i++) {
    var offer = db[keys[i]];
    if (!offer || !offer.m) continue;
    var merchantLower = String(offer.m).toLowerCase();
    var merchantCompact = merchantLower.replace(/[^a-z0-9]/g, "");
    if (merchantCompact.length < 2) continue;

    var hit = false;
    if (merchantCompact === brand) hit = true;
    else if (uohContainsAsWord(merchantLower, brand)) hit = true;
    else if (
      merchantCompact.length >= 5 &&
      brand.indexOf(merchantCompact) === 0 &&
      brand.length - merchantCompact.length <= 12
    ) hit = true;
    // The store's own site, when the autopilot saved it (Capital One Shopping
    // names it in each logo's address): "T-Mobile Home Internet" is
    // t-mobile.com, "Superhuman Mail" is products-mail.superhuman.com.
    else if (offer.domain && String(uohExtractBrand(offer.domain) || "").replace(/[^a-z0-9]/g, "") === brand) hit = true;

    if (hit) matches.push(offer);
  }
  return matches;
}

chrome.tabs.onUpdated.addListener(function (tabId, changeInfo, tab) {
  // Only act when the page has finished loading and we actually have a URL
  // we can reason about.
  if (changeInfo.status !== "complete") return;
  if (!tab || !tab.url || !/^https?:/i.test(tab.url)) return;

  var hostname;
  try { hostname = new URL(tab.url).hostname; } catch (e) { return; }
  if (!hostname || UOH_SOURCE_DOMAINS.test(hostname)) return;
  if (UOH_SEARCH_HOSTS.has(hostname) || UOH_SKIP_HOSTS.has(hostname)) return;

  chrome.storage.local.get(["UOH_Database", "UOH_Settings"], function (res) {
    if (chrome.runtime.lastError) return;
    var settings = res.UOH_Settings || {};
    if (settings.notifierOff) return;

    var matches = uohFindMatches(hostname, res.UOH_Database || {});
    if (!matches.length) {
      UOH_shownPerTab.delete(tabId);
      return;
    }

    // Dedup: don't show again for the same (tab, hostname) pair.
    if (UOH_shownPerTab.get(tabId) === hostname) return;
    UOH_shownPerTab.set(tabId, hostname);

    // Drop already-expired offers and sort soonest-expiry first so the most
    // urgent matches appear at the top of the toast. Card labels carry the
    // user's nicknames ("Mom Plat ••52007").
    var now = Date.now();
    var active = matches.filter(function (o) {
      return UOH.isActive(o, now);
    }).map(function (o) {
      // expiresAt() reads "Expires 10/31" as the end of Oct 31, so the toast's
      // own days-left math doesn't count an offer a day short.
      return Object.assign({}, o, { card: UOH.cardLabel(o, settings.cards), expiresTs: UOH.expiresAt(o) });
    });
    if (!active.length) return;
    active.sort(function (a, b) {
      var ae = a.expiresTs == null ? Infinity : a.expiresTs;
      var be = b.expiresTs == null ? Infinity : b.expiresTs;
      return ae - be;
    });

    chrome.scripting.executeScript({
      target: { tabId: tabId },
      func: uohRenderToast,
      args: [{ matches: active }],
      world: "ISOLATED"
    }).catch(function () {
      // Restricted pages (chrome://, store pages, etc) refuse injection.
      // Silently ignore — nothing the user can do about it.
    });
  });
});

chrome.tabs.onRemoved.addListener(function (tabId) {
  UOH_shownPerTab.delete(tabId);
  // A page run's progress, for a tab that's gone.
  uohQueue(function () {
    return chrome.storage.session.get(["UOH_PageRuns"]).then(function (r) {
      var runs = r.UOH_PageRuns || {};
      if (!runs[tabId]) return;
      delete runs[tabId];
      return chrome.storage.session.set({ UOH_PageRuns: runs });
    });
  });
});

/* The function injected into the target tab. Must be self-contained — runs
 * in ISOLATED world with no access to service-worker globals. */
function uohRenderToast(payload) {
  if (document.getElementById("uoh-notifier")) return;
  var matches = (payload && payload.matches) || [];
  if (!matches.length) return;

  var SOURCE_COLORS = {
    Chase: "#1565C0",
    Amex: "#00838F",
    "Capital One": "#558B2F",
    "Capital One Shopping": "#B45309",
    Walgreens: "#6A1B9A",
    Safeway: "#C2185B"
  };

  function esc(s) {
    return String(s == null ? "" : s)
      .replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;").replace(/'/g, "&#39;");
  }

  function expiryLabel(o, now) {
    if (o.expiresTs != null) {
      var d = Math.floor((o.expiresTs - now) / 86400000);
      if (d < 0) return "expired";
      if (d === 0) return "expires today";
      if (d === 1) return "1 day left";
      if (d <= 30) return d + " days left";
      return new Date(o.expiresTs).toLocaleDateString();
    }
    return o.days ? String(o.days) : "";
  }

  // The host element sits on the merchant's page; the content goes in a
  // closed shadow root so the site's scripts (analytics, session recorders)
  // can't read the offers, cards or nicknames.
  var hostEl = document.createElement("div");
  hostEl.id = "uoh-notifier";
  hostEl.style.cssText = "all: initial; position: fixed; top: 20px; right: 20px; z-index: 2147483647;";
  var shadow = hostEl.attachShadow({ mode: "closed" });
  var root = document.createElement("div");
  root.style.cssText = [
    "display: block",
    "width: 340px",
    "background: #1a232f", "color: #f1f5f9",
    "font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif",
    "font-size: 13px", "line-height: 1.4",
    "border: 1px solid #2d3a4c", "border-radius: 10px",
    "box-shadow: 0 12px 36px rgba(0,0,0,0.45)",
    "overflow: hidden", "opacity: 0",
    "transition: opacity 220ms ease"
  ].join(";");

  var headerHtml =
    '<div style="padding:10px 12px;display:flex;align-items:center;justify-content:space-between;background:linear-gradient(135deg,#3b82f6,#8b5cf6);">' +
      '<div style="font-weight:700;font-size:13px;letter-spacing:0.2px;">' +
        '🎯 You have ' + matches.length + ' card offer' + (matches.length === 1 ? '' : 's') + ' for this site' +
      '</div>' +
      '<div id="uoh-notifier-close" role="button" tabindex="0" aria-label="Dismiss" style="cursor:pointer;font-size:18px;line-height:1;opacity:0.85;padding:0 4px;">×</div>' +
    '</div>';

  var now = Date.now();
  var visible = matches.slice(0, 6);
  var rowsHtml = visible.map(function (o) {
    var color = SOURCE_COLORS[o.site] || "#475569";
    var card = o.card ? esc(o.card) : "";
    var expTxt = expiryLabel(o, now);
    return (
      '<div style="padding:9px 10px;margin:2px 4px;border-radius:6px;border-bottom:1px solid rgba(255,255,255,0.04);">' +
        '<div style="display:flex;align-items:center;gap:6px;margin-bottom:4px;flex-wrap:wrap;">' +
          '<span style="background:' + color + ';color:#fff;font-size:9px;font-weight:700;padding:2px 6px;border-radius:4px;text-transform:uppercase;letter-spacing:0.4px;">' + esc(o.site) + '</span>' +
          '<span style="font-weight:700;font-size:13px;">' + esc(o.m) + '</span>' +
        '</div>' +
        '<div style="color:#4ade80;font-size:12px;font-weight:600;margin-bottom:2px;">' + esc(o.v) + '</div>' +
        '<div style="color:#8da0b4;font-size:11px;">' +
          card +
          (card && expTxt ? ' • ' : '') +
          esc(expTxt) +
        '</div>' +
      '</div>'
    );
  }).join("");

  var moreHtml = matches.length > visible.length
    ? '<div style="padding:6px 12px 10px;color:#8da0b4;font-size:11px;text-align:center;">+ ' + (matches.length - visible.length) + ' more in the hub</div>'
    : "";

  root.innerHTML =
    headerHtml +
    '<div style="padding:4px 0;max-height:340px;overflow-y:auto;">' + rowsHtml + moreHtml + '</div>';

  // Attach to <html> instead of <body>. Next.js / React / Vue commonly replace
  // the entire <body> children tree when they hydrate, which used to wipe the
  // toast after 1–3 seconds on sites like oakley.com and ray-ban.com. <html>'s
  // children are virtually never touched by SPA frameworks, so the toast
  // survives hydration there.
  shadow.appendChild(root);
  var host = document.documentElement || document.body;
  host.appendChild(hostEl);

  // Belt-and-suspenders: if a particularly aggressive page DOES remove the
  // toast (e.g., a content-blocker or a rerender that wipes documentElement's
  // children too), re-attach it up to 3 times. Hard cap avoids an infinite
  // loop with hostile pages.
  var reattachBudget = 3;
  var observer = null;
  if (typeof MutationObserver === "function") {
    observer = new MutationObserver(function () {
      if (!hostEl.isConnected && reattachBudget > 0) {
        reattachBudget--;
        try { host.appendChild(hostEl); } catch (e) { /* host may be gone */ }
      }
    });
    try {
      observer.observe(host, { childList: true, subtree: false });
    } catch (e) {}
  }

  // Fade in.
  requestAnimationFrame(function () { root.style.opacity = "1"; });

  var timer = null;
  var dismiss = function () {
    if (observer) { try { observer.disconnect(); } catch (e) {} observer = null; }
    if (timer) { clearTimeout(timer); timer = null; }
    root.style.opacity = "0";
    setTimeout(function () { if (hostEl.parentNode) hostEl.parentNode.removeChild(hostEl); }, 280);
  };
  var schedule = function () { timer = setTimeout(dismiss, 8000); };

  var closeBtn = root.querySelector("#uoh-notifier-close");
  if (closeBtn) {
    closeBtn.addEventListener("click", dismiss);
    closeBtn.addEventListener("keydown", function (e) {
      if (e.key === "Enter" || e.key === " ") { e.preventDefault(); dismiss(); }
    });
  }
  root.addEventListener("mouseenter", function () { if (timer) { clearTimeout(timer); timer = null; } });
  root.addEventListener("mouseleave", schedule);
  schedule();
}

/* ============================================================ */
/*            Hub writes: one queue, one writer                  */
/* ============================================================ */
// Every write to UOH_Database / UOH_Settings goes through this chain, so each
// read-merge-write finishes before the next starts. A failed step is logged
// and doesn't block the ones queued after it.
var uohChain = Promise.resolve();
function uohQueue(fn) {
  var p = uohChain.then(fn);
  uohChain = p.catch(function (e) { console.warn("[UOH] write failed:", e); });
  return p;
}

// Data the live file mirrors changed; lib/livefile.js (when loaded) debounces.
function uohAfterDataChange() {
  if (self.UOH_LIVE && UOH_LIVE.schedule) UOH_LIVE.schedule();
}

function uohSenderHost(sender) {
  try { return new URL((sender && sender.tab && sender.tab.url) || (sender && sender.url) || "").hostname; }
  catch (e) { return ""; }
}

// A page script can post the same {__uoh:true} messages the autopilot does.
// Only accept a record whose `site` belongs to the tab that sent it.
function uohSiteMatchesHost(site, host) {
  if (!host) return true;
  var src = (self.UOH_SOURCES || []).find(function (s) { return s.id === site; });
  if (!src) return false;
  return src.hostPatterns.some(function (p) { return host.indexOf(p) > -1; });
}

function uohApplySave(offers, lastRun, sender) {
  var host = uohSenderHost(sender);
  if (self.UOH_AUTO) UOH_AUTO.noteSave(sender, host);
  return uohQueue(function () {
    return chrome.storage.local.get(["UOH_Database"]).then(function (res) {
      var db = res.UOH_Database || {}, now = Date.now(), saved = 0;
      Object.keys(offers || {}).forEach(function (k) {
        var rec = offers[k];
        if (!rec || !rec.m || !uohSiteMatchesHost(rec.site, host)) return;
        // Keys of the same source this record takes over (an older key
        // scheme, e.g. Capital One Shopping's one rate per store).
        if (Array.isArray(rec.replaces)) {
          rec.replaces.forEach(function (old) { if (old !== k && db[old] && db[old].site === rec.site) delete db[old]; });
          rec = Object.assign({}, rec);
          delete rec.replaces;
        }
        db[k] = UOH.normalizeRecord(rec, db[k], now);
        saved++;
      });
      var write = { UOH_Database: db };
      if (typeof lastRun === "number") { write.UOH_LastRunCount = lastRun; write.UOH_LastRunAt = now; }
      if (!saved && !("UOH_LastRunCount" in write)) return { ok: true, saved: 0 };
      return chrome.storage.local.set(write).then(function () {
        uohAfterDataChange();
        return { ok: true, saved: saved };
      });
    });
  });
}

// "Clean expired": the stale set is worked out here, at write time, so an
// autopilot that refreshed some offers after the popup showed its count
// doesn't lose them. dryRun only counts.
function uohApplyClean(dryRun) {
  return uohQueue(function () {
    return chrome.storage.local.get(["UOH_Database"]).then(function (res) {
      var db = res.UOH_Database || {}, st = UOH.findStale(db, Date.now());
      var out = { expired: st.expired.length, unseen: st.unseen.length };
      if (dryRun || !(out.expired + out.unseen)) return out;
      st.expired.concat(st.unseen).forEach(function (k) { delete db[k]; });
      return chrome.storage.local.set({ UOH_Database: db }).then(function () {
        uohAfterDataChange();
        return out;
      });
    });
  });
}

// "Clear all" always wipes the whole hub, whatever filter is selected, so
// there is one guaranteed way back to a clean slate. UOH_Settings (toggles,
// card nicknames and order) is kept.
var UOH_CLEAR_KEYS = ["UOH_Database", "UOH_LastRunCount", "UOH_LastRunAt", "UOH_UIState", "UOH_Categories"];
function uohApplyClearAll() {
  var stop = self.UOH_AUTO ? UOH_AUTO.abort("Cleared all data") : Promise.resolve();
  return stop.then(function () {
    return uohQueue(function () {
      return chrome.storage.local.get(["UOH_AutoState"]).then(function (r) {
        // Keep each card's run times so the 2-hour gap between Amex runs
        // still holds; drop the run summary.
        var cards = (r.UOH_AutoState || {}).cards;
        var write = cards ? chrome.storage.local.set({ UOH_AutoState: { cards: cards } })
                          : chrome.storage.local.remove("UOH_AutoState");
        return write.then(function () { return chrome.storage.local.remove(UOH_CLEAR_KEYS); });
      });
    });
  }).then(function () {
    // Empty the live file now rather than after the usual debounce, and tell
    // the popup if Chrome wouldn't let us (the old files would still be there).
    if (!self.UOH_LIVE) return { ok: true };
    return UOH_LIVE.exportNow().then(function (st) { return { ok: true, live: st && st.status }; });
  });
}

// Removes one card from the hub: its saved offers, nickname, order and
// auto-add state. Only the dashboard's Cards panel asks, for a card that was
// replaced or closed; nothing changes at the bank. A card still on an Amex
// login comes back as a new card on the next auto-add run.
function uohApplyRemoveCard(key) {
  if (typeof key !== "string" || key.indexOf("|") < 1) return Promise.resolve({ ok: false, error: "no card" });
  return uohQueue(function () {
    return chrome.storage.local.get(["UOH_Database", "UOH_Settings", "UOH_AutoState"]).then(function (r) {
      var db = r.UOH_Database || {}, s = r.UOH_Settings || {}, st = r.UOH_AutoState, removed = 0;
      Object.keys(db).forEach(function (k) { if (UOH.cardKey(db[k]) === key) { delete db[k]; removed++; } });
      if (s.cards) delete s.cards[key];
      var write = { UOH_Database: db, UOH_Settings: s };
      if (st && st.cards && st.cards[key]) { delete st.cards[key]; write.UOH_AutoState = st; }
      return chrome.storage.local.set(write).then(function () {
        uohAfterDataChange();
        return { ok: true, removed: removed };
      });
    });
  });
}

// Settings are written by the popup (toggles, run minutes), the dashboard
// (card nicknames and order) and the auto-run (newly seen cards). Patches
// merge per key; `cards`, `autoAdd` and `runMinutes` merge one level deeper,
// and a null value deletes.
function uohApplySettingsPatch(patch) {
  return uohQueue(function () {
    return chrome.storage.local.get(["UOH_Settings"]).then(function (res) {
      var s = res.UOH_Settings || {};
      Object.keys(patch || {}).forEach(function (k) {
        var v = patch[k];
        if ((k === "cards" || k === "autoAdd" || k === "runMinutes") && v && typeof v === "object") {
          var cur = s[k] || {};
          Object.keys(v).forEach(function (ck) {
            if (v[ck] === null) delete cur[ck];
            else if (k === "cards") cur[ck] = Object.assign({}, cur[ck] || {}, v[ck]);
            else cur[ck] = v[ck];
          });
          s[k] = cur;
        } else if (v === null) {
          delete s[k];
        } else {
          s[k] = v;
        }
      });
      return chrome.storage.local.set({ UOH_Settings: s }).then(function () {
        if (patch && patch.cards) uohAfterDataChange(); // nicknames appear in the live file
        return { ok: true, settings: s };
      });
    });
  });
}

// Categories the on-device model worked out in the dashboard, keyed by
// compact merchant name. Only valid category names are kept.
function uohApplyCategories(map) {
  return uohQueue(function () {
    return chrome.storage.local.get(["UOH_Categories", "UOH_Database"]).then(function (res) {
      var cats = res.UOH_Categories || {}, n = 0, have = {};
      // A batch that finishes after "Clear all" must not bring cleared
      // merchant names back.
      Object.keys(res.UOH_Database || {}).forEach(function (k) { have[UOH.compact(res.UOH_Database[k].m)] = 1; });
      Object.keys(map || {}).forEach(function (k) {
        if (have[k] && self.UOH_CATS && UOH_CATS.LIST.indexOf(map[k]) > -1) { cats[k] = map[k]; n++; }
      });
      if (!n) return { ok: true, saved: 0 };
      return chrome.storage.local.set({ UOH_Categories: cats }).then(function () {
        uohAfterDataChange();
        return { ok: true, saved: n };
      });
    });
  });
}

// A run that keeps nothing on its page while it reads (Capital One Shopping
// stops adding offers once something of ours is on the page): its progress,
// passed on by content/bridge.js, is kept per tab in chrome.storage.session
// UOH_PageRuns for the side panel (sidepanel/run.html) and the popup, and the
// stores read so far show on that tab's toolbar badge. A finished run stays,
// so the side panel keeps its summary, until the tab closes or runs again.
function uohRunProgress(tabId, pr) {
  return uohQueue(function () {
    return chrome.storage.session.get(["UOH_PageRuns"]).then(function (r) {
      var runs = r.UOH_PageRuns || {};
      var src = (self.UOH_SOURCES || []).find(function (s) { return s.id === pr.site; });
      runs[tabId] = Object.assign({}, pr, { at: Date.now() });
      try {
        chrome.action.setBadgeBackgroundColor({ tabId: tabId, color: src ? src.color : "#64748b" }).catch(function () {});
        chrome.action.setBadgeText({ tabId: tabId, text: pr.done ? "" : String(Math.min(+pr.stores || 0, 9999)) }).catch(function () {});
      } catch (e) {}
      return chrome.storage.session.set({ UOH_PageRuns: runs });
    });
  }).then(function () { return { ok: true }; });
}

// A timed run (Capital One Shopping), started by the popup's Run. The popup
// opens the run's side panel, and opening it closes the popup, so the
// service worker puts the autopilot in the tab: the same three steps as
// popup.js's Run. The side panel shows "Starting..." at once, and why if the
// run couldn't start.
function uohStartPageRun(tabId, site, minutes) {
  var exec = function (opts) { return chrome.scripting.executeScript(Object.assign({ target: { tabId: tabId } }, opts)); };
  var now = Date.now();
  return uohRunProgress(tabId, { site: site, status: "Starting...", tone: "ok", done: false, read: 0, stores: 0, timed: 0, bad: 0,
                                 endsAt: now + minutes * 60000 })
    .then(function () {
      return exec({ world: "MAIN", args: [minutes], func: function (m) {
        try { sessionStorage.setItem("UOH_PopupTrigger", String(Date.now())); sessionStorage.removeItem("UOH_AutoTicks"); } catch (e) {}
        if (m) window.__uohRunMinutes = m;
      } });
    })
    .then(function () { return exec({ files: ["content/bridge.js"] }); })
    .then(function () { return exec({ files: ["content/scraper.js"], world: "MAIN" }); })
    .then(function () { return { ok: true }; }, function (e) {
      var why = String((e && e.message) || e);
      return uohRunProgress(tabId, { site: site, status: "Couldn't start the autopilot: " + why, tone: "error", done: true,
                                     read: 0, stores: 0, timed: 0, bad: 0, endsAt: now })
        .then(function () { return { ok: false, error: why }; });
    });
}

chrome.runtime.onMessage.addListener(function (msg, sender, sendResponse) {
  if (!msg || typeof msg.type !== "string") return;
  var p = null;
  if (msg.type === "UOH_SAVE") p = uohApplySave(msg.offers, msg.lastRun, sender);
  else if (msg.type === "UOH_CLEAN") p = uohApplyClean(!!msg.dryRun);
  else if (msg.type === "UOH_CLEAR_ALL") p = uohApplyClearAll();
  else if (msg.type === "UOH_PATCH_SETTINGS") p = uohApplySettingsPatch(msg.patch);
  else if (msg.type === "UOH_REMOVE_CARD") p = uohApplyRemoveCard(msg.key);
  else if (msg.type === "UOH_SET_CATEGORIES") p = uohApplyCategories(msg.map);
  else if (msg.type === "UOH_RUN_PROGRESS" && sender.tab) p = uohRunProgress(sender.tab.id, msg.progress || {});
  else if (msg.type === "UOH_START_PAGE_RUN" && msg.tabId) p = uohStartPageRun(msg.tabId, String(msg.site || ""), +msg.minutes || 5);
  else if (msg.type === "UOH_LIVE_EXPORT" && self.UOH_LIVE) p = UOH_LIVE.exportNow();
  else if (self.UOH_AUTO) p = UOH_AUTO.onMessage(msg, sender);
  if (!p) return;
  p.then(function (r) { sendResponse(r || { ok: true }); },
         function (e) { sendResponse({ ok: false, error: String((e && e.message) || e) }); });
  return true; // reply asynchronously
});

// v3 migration: v2.x rewrote firstSeen on every save, so stored values mean
// "last seen". Push them back once so "New this week" starts empty instead of
// listing the whole hub.
chrome.runtime.onInstalled.addListener(function (details) {
  if (details.reason === "update" && UOH.versionLt(details.previousVersion, "3.0.0")) {
    uohQueue(function () {
      return chrome.storage.local.get(["UOH_Database"]).then(function (res) {
        var db = res.UOH_Database || {};
        var n = UOH.migrateFirstSeen(db, Date.now());
        console.log("[UOH] v3 migration: firstSeen moved back on " + n + " offers");
        return chrome.storage.local.set({ UOH_Database: db, UOH_SchemaVersion: 3 });
      });
    });
  }
});

if (self.UOH_AUTO) {
  UOH_AUTO.init({ save: uohApplySave, patchSettings: uohApplySettingsPatch, afterDataChange: uohAfterDataChange });
}
