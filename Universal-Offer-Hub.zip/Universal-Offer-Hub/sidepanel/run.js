/*
 * Side panel: the progress of the run in one tab (run.html?tab=<id>), from
 * chrome.storage.session UOH_PageRuns[<id>] (background.js keeps it from
 * the autopilot's RUN_PROGRESS messages). Stop and save sends UOH_STOP_RUN
 * to the tab; its bridge passes it to the autopilot, which saves what it read.
 */
(function () {
  "use strict";
  var tabId = +new URLSearchParams(location.search).get("tab");
  var $ = function (id) { return document.getElementById(id); };
  var run = null;

  function clock(ms) {
    var s = Math.max(0, Math.ceil(ms / 1000));
    return Math.floor(s / 60) + ":" + ("0" + (s % 60)).slice(-2);
  }

  function render() {
    var src = run && (self.UOH_SOURCES || []).filter(function (s) { return s.id === run.site; })[0];
    $("title").innerText = src ? src.name + " Autopilot" : "Autopilot";
    if (src) document.body.style.setProperty("--site-color", src.color);
    var status = $("status"), note = $("note");
    // Not heard from in 75 s while running (a background tab still hears
    // from it once a minute): its page was reloaded or closed.
    var gone = run && !run.done && Date.now() - run.at > 75000;
    status.className = "status" + (run && run.tone && run.tone !== "ok" ? " " + run.tone : gone ? " warn" : "");
    if (!run) {
      status.innerText = "No run in this tab yet. Press Run in the toolbar popup to start one.";
    } else if (gone) {
      status.innerText = "The run stopped before it was done: its page was reloaded or closed. What it read wasn't saved.";
    } else {
      // The time left counts down below, so not in the status too.
      status.innerText = String(run.status || "Starting...").replace(/\s*\d+:\d\d left\.$/, "");
    }
    ["read", "stores", "timed", "bad"].forEach(function (k) { $(k).innerText = run ? (+run[k] || 0) : 0; });
    var live = !!(run && !run.done && !gone);
    $("foot").hidden = !live;
    if (live) $("left").innerText = clock(run.endsAt - Date.now()) + " left";
    note.hidden = !(run && run.done);
    note.innerText = "Saved to the hub. You can close this panel.";
  }

  function load() {
    chrome.storage.session.get(["UOH_PageRuns"], function (r) {
      run = (r.UOH_PageRuns || {})[tabId] || null;
      render();
    });
  }

  $("stop").addEventListener("click", function () {
    chrome.tabs.sendMessage(tabId, { type: "UOH_STOP_RUN" }, function () { void chrome.runtime.lastError; });
    $("status").innerText = "Stopping...";
    $("stop").disabled = true;
  });
  chrome.storage.onChanged.addListener(function (changes, area) {
    if (area === "session" && changes.UOH_PageRuns) load();
  });
  // The time left counts down between progress messages.
  setInterval(function () { if (run && !run.done) render(); }, 1000);
  load();
})();
