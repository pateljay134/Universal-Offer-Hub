/*
 * Universal Offer Hub — background-run page core (ISOLATED world)
 * -----------------------------------------------------------------
 * Shared by every issuer's page script (content/<issuer>-auto.js), which
 * loads after this file and calls UOH_AUTO_PAGE.start(adapter). It asks the
 * service worker what this tab is for:
 *
 *   run    the Offer Hub tab (lib/autorun.js). Holds a Web Lock for the
 *          page's life (Chrome doesn't freeze a page that holds one), connects
 *          a port, and does one job at a time, one step per TICK from the
 *          service worker. A hidden tab's timers slow down; port messages
 *          don't.
 *   watch  the user's own tab, with that issuer's auto-add on: reports the
 *          login's accounts (that's what starts a run) and shows a small note
 *          while a run is working, then its result.
 *   none   auto-add is off: nothing else runs.
 *
 * The adapter:
 *   issuer, label  "Amex", "Chase"
 *   spa            the site changes pages without loading one, so the watch
 *                  looks again when the address changes
 *   seen(tries)    called every 250 ms until it returns the login's account
 *                  ids, or watchTries (default 40) polls pass
 *   steps(api)     returns step(job, st), called on every TICK while a job is
 *                  open; st starts as { t0 } for each new job. api has done,
 *                  fail, progress and autopilot (runs the bank's own "Run …
 *                  Autopilot" from content/scraper.js, step by step).
 *
 * Everything here runs in the extension's isolated world. Nothing is posted
 * on the page, so the issuer's own scripts can't see the control traffic.
 * Clicks are plain DOM events, as in content/scraper.js. Text is read with
 * textContent, so reading doesn't depend on the page being painted.
 */
(function () {
  "use strict";
  var P = self.UOH_AUTO_PAGE = {};

  function send(msg, cb) {
    try {
      chrome.runtime.sendMessage(msg, function (r) {
        if (chrome.runtime.lastError) { if (cb) cb(null); return; }
        if (cb) cb(r);
      });
    } catch (e) { if (cb) cb(null); }
  }

  function text(el) { return el ? String(el.textContent || "").replace(/\s+/g, " ").trim() : ""; }

  function whenBody(fn) {
    if (document.body) return fn();
    document.addEventListener("DOMContentLoaded", function () { fn(); }, { once: true });
  }

  function click(el) {
    var o = { bubbles: true, cancelable: true, view: window };
    el.dispatchEvent(new MouseEvent("mousedown", o));
    el.dispatchEvent(new MouseEvent("mouseup", o));
    el.dispatchEvent(new MouseEvent("click", o));
  }

  P.send = send; P.text = text; P.whenBody = whenBody; P.click = click;

  P.start = function (adapter) {
    if (window.__uohAuto) return;
    window.__uohAuto = true;
    if (window.top !== window) return;
    send({ type: "UOH_HELLO", issuer: adapter.issuer, url: location.href }, function (r) {
      if (!r || r.role === "none") return;
      if (r.role === "run") drive(adapter, r.runId);
      else if (r.role === "watch") watch(adapter);
    });
  };

  /* ============================================================ */
  /*                 watch: the user's own tab                     */
  /* ============================================================ */
  function watch(a) {
    watchIssuer = a.issuer;
    chrome.runtime.onMessage.addListener(function (m) {
      if (m && m.type === "UOH_RUN_DONE") note(m.ok ? (m.scanOnly ? "found" : "added") : "stopped", m);
    });
    var sent = false, polling = false;
    function poll() {
      polling = true;
      var tries = 0;
      var iv = setInterval(function () {
        var ids = a.seen(tries);
        if ((ids && ids.length) || ++tries > (a.watchTries || 40)) {
          clearInterval(iv);
          polling = false;
          if (!(ids && ids.length)) return;
          sent = true;
          send({ type: "UOH_SEEN", issuer: a.issuer, ids: ids }, function (r) {
            if (r && r.started) note("start");
            else if (r && r.nextAt && (r.reason === "gap" || r.reason === "retry-wait")) waitNote(r);
          });
        }
      }, 250);
    }
    whenBody(poll);
    // A one-page site moves between its pages without loading one (hash or
    // history changes, e.g. from sign-in to the dashboard): look again when
    // the address changes, until a login was reported.
    if (a.spa) {
      var href = location.href;
      setInterval(function () {
        if (location.href === href) return;
        href = location.href;
        if (!sent && !polling) whenBody(poll);
      }, 1000);
    }
  }

  var noteHost = null, noteTimer = null, watchIssuer = "";
  function clock(ts) { return new Date(ts).toLocaleTimeString([], { hour: "numeric", minute: "2-digit" }); }

  // Inside the 2-hour gap (or the 15-minute retry wait): when this login last
  // ran and when the next automatic run can start. Once per tab until then,
  // so moving between the bank's pages doesn't repeat it.
  function waitNote(r) {
    var seen = "";
    try { seen = sessionStorage.getItem("UOH_WaitNote") || ""; } catch (e) {}
    if (seen === String(r.nextAt)) return;
    try { sessionStorage.setItem("UOH_WaitNote", String(r.nextAt)); } catch (e) {}
    note("wait", r);
  }

  function note(kind, m) {
    whenBody(function () {
      if (!noteHost) {
        noteHost = document.createElement("div");
        noteHost.style.cssText = "all:initial;position:fixed;right:20px;bottom:20px;z-index:2147483647;";
        noteHost.attachShadow({ mode: "open" });
        document.documentElement.appendChild(noteHost);
      }
      if (noteTimer) { clearTimeout(noteTimer); noteTimer = null; }
      var msg, action = null;
      if (kind === "start") msg = "Adding this login's offers in a background tab (the grey Offer Hub group at the end of your tabs). Stay signed in until it finishes.";
      else if (kind === "added") msg = (m.note || "Done.");
      else if (kind === "found") {
        msg = m.note || "Choose which cards get offers in Cards, then press Confirm and add offers.";
        action = { label: "Open Cards", go: function () { send({ type: "UOH_OPEN_DASHBOARD", hash: "cards-" + watchIssuer }); } };
      } else if (kind === "wait") {
        msg = m.reason === "gap"
          ? "Offer Hub ran for this login at " + clock(m.lastAt) + ". The next automatic run can start after " + clock(m.nextAt) + "."
          : "Offer Hub tried at " + clock(m.lastAt) + ", but the offers page didn't load. It tries again after " + clock(m.nextAt) + ".";
        action = { label: "Add offers now", go: function () {
          send({ type: "UOH_RUN_NOW", issuer: watchIssuer }, function (r) { note(r && r.ok ? "start" : "busy", r || {}); });
        } };
      } else if (kind === "busy") {
        msg = m.reason === "running" ? "A run is already working. It finishes on its own." : "Couldn't start a run. Try the popup's Add offers on all cards.";
      } else msg = "Stopped: " + (m.note || "something went wrong") + " It will try again on a later visit.";
      noteHost.shadowRoot.innerHTML =
        '<style>' +
        '.b{width:300px;background:#1a232f;color:#f1f5f9;border:1px solid #2d3a4c;border-radius:10px;' +
        'box-shadow:0 12px 36px rgba(0,0,0,.45);font:13px/1.45 -apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Arial,sans-serif;padding:11px 12px}' +
        '.h{display:flex;justify-content:space-between;align-items:center;font-weight:700;margin-bottom:4px}' +
        '.x{cursor:pointer;opacity:.75;font-size:16px;line-height:1;padding:0 2px;background:none;border:0;color:inherit}' +
        '.a{margin-top:8px;background:#3b82f6;color:#fff;border:0;border-radius:7px;padding:6px 10px;font-weight:600;cursor:pointer}' +
        '</style>' +
        '<div class="b"><div class="h"><span>Offer Hub</span><button class="x" aria-label="Dismiss">×</button></div>' +
        '<div class="t"></div>' + (action ? '<button class="a"></button>' : '') + '</div>';
      var root = noteHost.shadowRoot;
      root.querySelector(".t").textContent = msg;
      root.querySelector(".x").addEventListener("click", function () { noteHost.remove(); noteHost = null; });
      if (action) {
        var b = root.querySelector(".a");
        b.textContent = action.label;
        b.addEventListener("click", action.go);
      }
      var closeIn = kind === "wait" ? 20000 : kind === "added" || kind === "stopped" || kind === "busy" ? 12000 : 0;
      if (closeIn) noteTimer = setTimeout(function () { if (noteHost) { noteHost.remove(); noteHost = null; } }, closeIn);
    });
  }

  /* ============================================================ */
  /*                 run: the Offer Hub tab                        */
  /* ============================================================ */
  function drive(a, runId) {
    var port = null, locked = false, stopped = false, reconnects = 0;
    var job = null, st = null, lastProgress = 0, pilot = null;
    var step = a.steps({ done: done, fail: fail, progress: progress, autopilot: autopilot });

    // The bank's autopilot says it's done (content/scraper.js, page world).
    // Only numbers and text are taken from the message.
    window.addEventListener("message", function (e) {
      var m = e.data;
      if (e.source !== window || !m || m.__uoh !== true || m.type !== "AUTOPILOT_DONE") return;
      if (!pilot || !job || pilot.jobId !== job.id || pilot.result) return;
      pilot.result = { note: String(m.note || "").slice(0, 200), count: +m.added || 0,
                       saved: +m.saved || 0, harvested: +m.history || 0 };
    });

    // Held until this page goes away. The name is unique per page load so the
    // next page's lock never waits on this one.
    try {
      navigator.locks.request("uoh-run-" + runId + "-" + Math.random().toString(36).slice(2), function () {
        locked = true;
        post({ t: "LOCKED" });
        return new Promise(function () {});
      });
    } catch (e) {}

    connect();
    whenBody(function () { banner(a.label); });

    function connect() {
      try { port = chrome.runtime.connect({ name: "uoh-run" }); } catch (e) { return; }
      port.onMessage.addListener(onMsg);
      port.onDisconnect.addListener(function () {
        port = null;
        // The service worker restarted mid-run: reconnect and get the job again.
        if (!stopped && reconnects++ < 3) setTimeout(connect, 1000);
      });
      if (locked) post({ t: "LOCKED" });
    }
    function post(m) { if (port) { try { port.postMessage(m); } catch (e) {} } }

    function onMsg(m) {
      if (!m) return;
      if (m.t === "STOP") { stopped = true; job = null; return; }
      if (m.t === "JOB") {
        if (!job || job.id !== m.job.id) { job = m.job; st = { t0: Date.now() }; }
        return;
      }
      if (m.t === "TICK" && job) {
        try { step(job, st); } catch (e) { fail("error: " + (e && e.message || e)); }
      }
    }

    function done(result) { if (!job) return; post({ t: "DONE", jobId: job.id, result: result }); job = null; }
    function fail(reason) { if (!job) return; post({ t: "FAIL", jobId: job.id, reason: reason }); job = null; }
    function progress(t) {
      var now = Date.now();
      if (now - lastProgress < 1000) return;
      lastProgress = now;
      post({ t: "PROGRESS", jobId: job && job.id, text: t });
    }

    // Runs the bank's own "Run … Autopilot" (content/scraper.js, the code
    // behind the popup's button) on the card on screen. Called on every tick
    // once the card is ready; each call is one of its steps, and the service
    // worker ticks at the pace its own timer keeps. start: ask the service
    // worker to start it here (Amex's Added page gets it from the manifest
    // instead). hold(status): true while its next step should wait. extra():
    // more to report when it's done.
    function autopilot(panelId, start, hold, extra) {
      var t = Date.now(), tick = function () { document.dispatchEvent(new CustomEvent("uoh-autopilot-tick")); };
      if (!pilot || pilot.jobId !== job.id) {
        pilot = { jobId: job.id, at: t, asked: false, seen: false, status: "", statusAt: t, result: null, flushed: false };
        // A panel left by an earlier card's run: remove it, and give one step
        // so that run, if it was still going, sees it gone and stops.
        var old = start && document.getElementById(panelId);
        if (old) { old.remove(); tick(); return; }
      }
      if (pilot.result) {
        // Its last saves may still be in content/bridge.js's batch: send them
        // now, and report on the next tick.
        if (!pilot.flushed) { pilot.flushed = true; window.postMessage({ __uoh: true, type: "FLUSH" }, "*"); return; }
        done(Object.assign({}, pilot.result, extra ? extra() : {}));
        return;
      }
      var panel = document.getElementById(panelId);
      if (!panel) {
        // Its panel went away mid-run (the page redrew): one step, so that
        // run sees it gone and stops before the next card's run starts.
        if (pilot.seen) { tick(); fail("autopilot-stopped"); return; }
        if (start && !pilot.asked) {
          try { sessionStorage.setItem("UOH_AutoTicks", "1"); } catch (e) {}
          pilot.asked = true;
          post({ t: "AUTOPILOT", jobId: job.id });
        }
        if (t - pilot.at > 20000) fail("autopilot-not-started");
        return;
      }
      pilot.seen = true;
      var s = text(panel.querySelector("#cp-status"));
      if (s !== pilot.status) { pilot.status = s; pilot.statusAt = t; progress(s); }
      else if (t - pilot.statusAt > 90000) { fail("autopilot-stuck"); return; }
      if (hold && hold(s)) return;
      tick();
    }
  }

  function banner(label) {
    var host = document.createElement("div");
    host.style.cssText = "all:initial;position:fixed;left:50%;top:10px;transform:translateX(-50%);z-index:2147483647;";
    var box = document.createElement("div");
    box.style.cssText = "background:#1a232f;color:#f1f5f9;border:1px solid #2d3a4c;border-radius:8px;padding:8px 12px;" +
      "font:13px -apple-system,BlinkMacSystemFont,Segoe UI,Roboto,Arial,sans-serif;box-shadow:0 8px 24px rgba(0,0,0,.35)";
    box.textContent = "Offer Hub is adding your " + label + " offers in this tab. It closes itself when it finishes.";
    host.attachShadow({ mode: "open" }).appendChild(box);
    document.documentElement.appendChild(host);
  }
})();
