/*
 * Universal Offer Hub — Per-site Autopilot Router  (MAIN world)
 * --------------------------------------------------------------
 * Injected into the page's MAIN JS context by chrome.scripting.executeScript
 * with `world: "MAIN"`. Running here is intentional and important:
 *
 *   • The Capital One sorter UI renders rows with inline
 *     `onclick="window.c1Clk(...)"` handlers. Inline-onclick attributes run
 *     in the page's MAIN world, so c1Clk MUST be defined there.
 *   • The Capital One "View More Offers" button is wired through React's
 *     synthetic event system + React-fiber props. Reaching those fiber keys
 *     (`__reactProps$xyz`) reliably requires the MAIN world.
 *   • The Chase / Amex / Walgreens autopilots are pure DOM-event clicks and
 *     work in either world, so MAIN is safe for them too.
 *
 * MAIN world has no chrome.* APIs. We persist offers by posting messages to
 * content/bridge.js (ISOLATED), which batches them into chrome.storage.local.
 *
 * Adding a new site:
 *   1. Add a record to lib/sources.js.
 *   2. Add a `host.indexOf("yoursite.com") > -1` branch below that calls
 *      saveOffer(uniqueKey, merchant, value, "Site Display Name", { ... }).
 */
(function () {
  var host = window.location.hostname;

  /* ---------- Hub database write helpers (post to ISOLATED bridge) ---------- */
  var saveOffer = function (key, merchant, value, site, extra) {
    if (!key || !merchant) return;
    var parsed = parseValue(value);
    var cardLabel = (extra && extra.card) || "";
    var record = Object.assign(
      {
        m: merchant,
        v: value || "",
        site: site,
        n: parsed.num,
        t: parsed.type,
        // search haystack — include the card label so users can search e.g.
        // "platinum samsung" and surface only Platinum-card Samsung offers.
        r: (merchant + " " + (value || "") + " " + cardLabel).toLowerCase(),
        // firstSeen is stamped by the service worker the first time it stores
        // this key; sending it from here overwrote it on every run.
        ts: Date.now()
      },
      extra || {}
    );
    // Don't let a blank expiry from one pass wipe a real one captured earlier.
    // The bridge MERGES records (Object.assign over the stored copy), so a later
    // save that carries `days:""`/`expiresTs:null` would otherwise clobber an
    // expiry we already harvested. Amex/Chase only show "Expires M/D/YY" /
    // "13d left" reliably on the Added/Enrolled list — the main Available list
    // usually omits it — so the available-phase re-save must NOT erase it.
    // Omitting these keys when empty makes the merge preserve the prior value.
    if (record.expiresTs == null) delete record.expiresTs;
    if (!record.days) delete record.days;
    try {
      window.postMessage({ __uoh: true, type: "SAVE_OFFER", key: key, record: record }, "*");
    } catch (e) {}
  };

  /* ---------- Per-site active-card detection ----------
   * Same merchant on two different cards under one issuer is two different
   * offers, so the storage key must include a per-card discriminator. Each
   * helper returns { cardId, label } — cardId becomes part of the offer key,
   * label is shown as a chip in the popup. All helpers fall back to "default"
   * so the autopilot still works on cards whose DOM/URL we don't recognise. */
  // Amex's own id for the card on screen (opaqueAccountId): in the address of
  // the card's Added page, and on /offers in the View All link, which shows
  // once the card has an added offer. Unlike the last digits, no two cards
  // share it. "" when the page doesn't show it.
  var amexAccountId = function () {
    var id = "";
    try { id = new URL(window.location.href).searchParams.get("opaqueAccountId") || ""; } catch (e) {}
    if (!id) {
      var a = document.querySelector('a[href*="/offers/enrolled?opaqueAccountId="]');
      var m = a && (a.getAttribute("href") || "").match(/opaqueAccountId=([^&#]+)/);
      if (m) { try { id = decodeURIComponent(m[1]); } catch (e) { id = m[1]; } }
    }
    return /^[A-Za-z0-9_-]{4,64}$/.test(id) ? id : "";
  };

  var amexCardInfo = function () {
    var label = "", last4 = "";
    var nameEl = document.querySelector('[data-testid="simple_switcher_display_name"]');
    if (nameEl) label = (nameEl.innerText || nameEl.textContent || "").replace(/\s+/g, " ").trim();
    var numEl = document.querySelector('[data-testid="simple_switcher_display_number_val"]');
    if (numEl) {
      var t = (numEl.innerText || numEl.textContent || "").trim();
      var m = t.match(/(\d{4,5})\b/);
      if (m) last4 = m[1];
    }
    if (!last4) {
      var sel = document.querySelector('[data-testid="simple_switcher_selected_option_display"]');
      if (sel) {
        var aria = sel.getAttribute("aria-label") || "";
        var m2 = aria.match(/(\d{4,5})\b/);
        if (m2) last4 = m2[1];
      }
    }
    if (!label) label = "Amex";
    // cardId: the card's Amex id once the page shows it (amexAccountId), else
    // its last digits; the hub moves what was saved under the digits to the
    // id (UOH.moveCardId in lib/offers.js). Only the digits are ever shown.
    var id = amexAccountId();
    return { cardId: id || last4 || "default", id: id, label: label + (last4 ? " ••" + last4 : ""), last4: last4 };
  };

  var chaseCardInfo = function () {
    var accountId = "";
    try {
      var hash = window.location.hash || "";
      var qpos = hash.indexOf("?");
      if (qpos > -1) {
        accountId = new URLSearchParams(hash.slice(qpos + 1)).get("accountId") || "";
      }
      if (!accountId) {
        accountId = new URLSearchParams(window.location.search || "").get("accountId") || "";
      }
    } catch (e) {}
    if (!accountId) accountId = "default";
    // The accountId is an internal id, not the card number. The offers page's
    // account selector names the card on screen ("Sapphire Reserve...1234");
    // without it, the first "(...1234)" text on the page (e.g. "Sapphire
    // Preferred (...1234)"). Same name and last 4 as Chase auto-add saves.
    // cardId (the storage key) stays the accountId so existing saved offers
    // keep their keys.
    var last4 = "", name = "";
    var re = /^(.{0,50}?)\s*\(?\s*(?:\.{2,}|…|•+|\*+|x+)\s*(\d{4})\s*\)?\s*$/i;
    try {
      var trig = document.querySelector('[data-testid="account-selector-trigger"]');
      var tm = trig && (trig.textContent || "").replace(/\s+/g, " ").trim().match(re);
      if (tm) { last4 = tm[2]; name = tm[1].trim(); }
    } catch (e) {}
    try {
      var walker = last4 ? null : document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
      var node;
      while (walker && (node = walker.nextNode())) {
        var t = (node.nodeValue || "").replace(/\s+/g, " ").trim();
        if (!t || t.length > 60) continue;
        var m = t.match(re);
        if (m) {
          last4 = m[2];
          name = m[1].trim();
          // "(...1234)" is often its own text node; the card name sits in the
          // previous sibling element.
          if (!name && node.parentElement && node.parentElement.previousElementSibling) {
            name = (node.parentElement.previousElementSibling.innerText || "").trim();
            if (name.length > 40) name = "";
          }
          break;
        }
      }
    } catch (e) {}
    var short = accountId.length > 6 ? accountId.slice(-6) : accountId;
    var label = last4 ? ((name || "Chase") + " ••" + last4) : ("Chase Acct " + short);
    return { cardId: accountId, label: label, last4: last4 };
  };

  var capOneCardInfo = function () {
    var label = "", last4 = "";
    // Header text format: "Venture X...4417" / "Quicksilver•0123" etc.
    var els = Array.from(document.querySelectorAll('p.text-white, button p, header p'));
    for (var i = 0; i < els.length; i++) {
      var t = (els[i].innerText || els[i].textContent || "").trim();
      if (!t || t.length > 60) continue;
      var m = t.match(/(\d{4})\b/);
      if (m) {
        last4 = m[1];
        var name = t.slice(0, m.index).replace(/[\.••\s]+$/, "").trim();
        label = (name || "Capital One") + " ••" + last4;
        break;
      }
    }
    if (!last4) last4 = "default";
    // A card whose ending the header didn't show is named without one.
    if (!label) label = "Capital One" + (last4 === "default" ? "" : " ••" + last4);
    return { cardId: last4, label: label };
  };

  var updateLastRun = function (count) {
    try {
      window.postMessage({ __uoh: true, type: "UPDATE_LAST_RUN", count: count }, "*");
    } catch (e) {}
  };

  /* ---------- The autopilots' clock, and saying they're done ----------
   * Auto-add (lib/autorun.js) runs these same autopilots in a background tab.
   * Chrome slows timers there (to once a second, and to once a minute after
   * the tab has been hidden 5 minutes), so in that tab the extension sends
   * each step instead, at the same pace, as a "uoh-autopilot-tick" event on
   * the document. "UOH_AutoTicks" in that tab's sessionStorage switches this
   * on; the toolbar button never sets it. When a run ends, the autopilot posts
   * AUTOPILOT_DONE so auto-add can move on to the next card. */
  var autoTicks = false;
  try { autoTicks = sessionStorage.getItem("UOH_AutoTicks") === "1"; } catch (e) {}
  var every = function (ms, step) {
    if (!autoTicks) return setInterval(step, ms);
    document.addEventListener("uoh-autopilot-tick", step);
    return { step: step };
  };
  var stopEvery = function (timer) {
    if (timer && timer.step) document.removeEventListener("uoh-autopilot-tick", timer.step);
    else clearInterval(timer);
  };
  // error: what kept the autopilot from doing all of its job, said for the
  // user (Amex: offers on its Added page it couldn't read); "" when none.
  var finished = function (site, note, counts, error) {
    try {
      window.postMessage({ __uoh: true, type: "AUTOPILOT_DONE", site: site, note: note,
                           added: counts.added, saved: counts.saved, history: counts.history, error: error || "" }, "*");
    } catch (e) {}
  };

  /* Light-weight value parser — gives every saved offer a numeric + type so the
   * popup search can rank "best deals" without re-parsing per render.
   *
   * Rule: the offer's TYPE is whatever the user gets back, never what they
   * spend. "Spend $30, earn 1,500 miles" is a MILES offer (you receive miles),
   * not a DOLLAR offer. We strip the spend clause before classifying so the
   * '$30' in the trigger doesn't mislabel the reward. */
  function parseValue(v) {
    if (!v) return { num: 0, type: "OTHER" };
    var s = String(v).trim();

    // If the offer has spend-then-reward shape, classify only the reward
    // portion. We match the LAST occurrence of "earn|get|receive" so any
    // bonuses-on-top phrasing still ends up on the reward side.
    var sg = s.match(/^.*\b(?:earn|get|receive)\s+(.+)$/i);
    if (sg) s = sg[1];

    var m;
    // MULTIPLIER first — "8X miles", "3X points on dining", bare "5X".
    // Must beat the MILES rule below, otherwise "8X miles" reads as MILES=8.
    if ((m = s.match(/(\d+(?:\.\d+)?)\s*[xX]\b/))) {
      return { num: parseFloat(m[1]), type: "MULTI" };
    }
    // MILES / POINTS — number followed by a points-flavoured noun.
    // Covers "1,500 miles", "5,000 Membership Rewards points", "ThankYou points".
    if ((m = s.match(/([\d,]+(?:\.\d+)?)[^\d%$]{0,40}?\b(?:miles|points|MR\b|membership\s*rewards|thank\s*you|ultimate\s*rewards)/i))) {
      return { num: parseFloat(m[1].replace(/,/g, "")), type: "MILES" };
    }
    // PERCENT — "10% cash back"
    if ((m = s.match(/(\d+(?:\.\d+)?)\s*%/))) {
      return { num: parseFloat(m[1]), type: "PERCENT" };
    }
    // DOLLAR — "$200 cash back" / "$10 back". Last because a stray "$30" in
    // the spend clause would otherwise steal a MILES/PERCENT classification.
    if ((m = s.match(/\$\s*([\d,]+(?:\.\d+)?)/))) {
      return { num: parseFloat(m[1].replace(/,/g, "")), type: "DOLLAR" };
    }
    return { num: 0, type: "OTHER" };
  }

  /* Normalize a per-site expiry string ("Expires 5/18/26", "120d left",
   * "5 days left") into a JS timestamp so the popup can sort by soonest. */
  function parseExpiresTs(text) {
    if (!text) return null;
    var s = String(text).trim();
    // Absolute date: "Expires 5/18/26" or "5/18/2026"
    var m = s.match(/(\d{1,2})\/(\d{1,2})\/(\d{2,4})/);
    if (m) {
      var mm = parseInt(m[1], 10), dd = parseInt(m[2], 10), yy = parseInt(m[3], 10);
      if (yy < 100) yy = 2000 + yy;
      var d = new Date(yy, mm - 1, dd);
      return isNaN(d.getTime()) ? null : d.getTime();
    }
    // Month name: "Expires on October 22, 2026" / "Oct 22 2026" (Chase detail page)
    m = s.match(/\b(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)[a-z]*\.?\s+(\d{1,2}),?\s+(\d{4})/i);
    if (m) {
      var mon = "janfebmaraprmayjunjulaugsepoctnovdec".indexOf(m[1].toLowerCase()) / 3;
      var d2 = new Date(parseInt(m[3], 10), mon, parseInt(m[2], 10), 23, 59, 59, 999);
      return isNaN(d2.getTime()) ? null : d2.getTime();
    }
    // "Last day" / "Expires today" (Chase tiles): good through the end of today.
    if (/\b(?:last day|(?:expires|ends) today)\b/i.test(s)) {
      var today = new Date();
      today.setHours(23, 59, 59, 999);
      return today.getTime();
    }
    // Relative: "120d left" / "5 days left" / "1d"
    m = s.match(/(\d+)\s*(?:d|day|days)\b/i);
    if (m) {
      var n = parseInt(m[1], 10);
      // End-of-day for the target date so a "1d left" offer doesn't read
      // as already expired the instant the clock crosses midnight.
      var target = new Date();
      target.setDate(target.getDate() + n);
      target.setHours(23, 59, 59, 999);
      return target.getTime();
    }
    return null;
  }

  /* Fallback expiry finder: scan a tile's visible text for an explicit expiry
   * phrase. Amex only styles an expiry with .color-status-text-critical when it
   * is close (red "Expires in 3 days"); every other tile renders a plain
   * "Expires 10/31/26" in an unstyled span, which the class selector misses.
   * Requires an "expires"/"left" keyword so offer copy like "Spend $50 by 12/31"
   * isn't taken as the expiry. Returns "" when nothing matches. */
  function extractExpiry(el) {
    if (!el) return "";
    var txt = String(el.innerText || el.textContent || "").replace(/\s+/g, " ");
    var m = txt.match(/expires?\s*(?:on|in)?\s*:?\s*(\d{1,2}\/\d{1,2}\/\d{2,4}|(?:jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)[a-z]*\.?\s+\d{1,2},?\s+\d{4}|\d+\s*days?)/i)
         || txt.match(/(\d+\s*d(?:ays?)?\s*left)/i);
    return m ? m[0].trim() : "";
  }

  /* ============================================================ */
  /*                        CHASE  (enhanced)                     */
  /* ============================================================ */
  if (host.indexOf("chase.com") > -1) {
    if (document.getElementById("chase-autopilot-ui")) return;
    var chaseCard = chaseCardInfo();
    // If the user lands directly on Chase's Added Offers page (deep link,
    // back button, bookmark), the available-tile selector returns zero and
    // the original state machine would walk into opening_added, fail to find
    // a "navigate to Added Offers" link (we're already on it!), and exit
    // with no harvest. Detect this case via the added-list-only tile id and
    // jump straight to scraping_added.
    var chaseStartOnAddedPage = !!document.querySelector('[data-testid="added-offer-list-item-container"]')
      && !document.querySelector('[data-cy="commerce-tile"]');
    var ui = document.createElement("div");
    ui.id = "chase-autopilot-ui";
    ui.style.cssText = "position:fixed;bottom:20px;right:20px;width:240px;background:#1c2b36;color:#fff;font-family:sans-serif;font-size:12px;border-radius:8px;box-shadow:0 8px 24px rgba(0,0,0,0.4);z-index:999999;border:1px solid #455a64;overflow:hidden;";
    ui.innerHTML = '<div style="background:#117ACA;padding:10px;font-weight:700;display:flex;justify-content:space-between;align-items:center;"><span>Chase Autopilot</span><span id="cp-close" style="cursor:pointer;font-size:16px;opacity:0.8;">&times;</span></div><div style="padding:12px;"><div style="margin-bottom:8px;color:#90a4ae;">STATUS</div><div id="cp-status" style="color:#4caf50;font-weight:600;margin-bottom:12px;line-height:1.4;">Starting...</div><div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;text-align:center;"><div style="background:#263238;padding:6px;border-radius:4px;"><div id="cp-seen" style="font-weight:700;font-size:14px;">0</div><div style="font-size:10px;color:#78909c;">Visible</div></div><div style="background:#263238;padding:6px;border-radius:4px;"><div id="cp-queue" style="font-weight:700;font-size:14px;color:#ffb74d;">0</div><div style="font-size:10px;color:#78909c;">Queue</div></div><div style="background:#263238;padding:6px;border-radius:4px;"><div id="cp-added" style="font-weight:700;font-size:14px;color:#4caf50;">0</div><div style="font-size:10px;color:#78909c;">Added New</div></div><div style="background:#263238;padding:6px;border-radius:4px;"><div id="cp-pre" style="font-weight:700;font-size:14px;color:#90a4ae;">0</div><div style="font-size:10px;color:#78909c;">Saved</div></div></div></div>';
    document.body.appendChild(ui);

    var state = {
      added: 0, run: true, baselineOld: null,
      phase: chaseStartOnAddedPage ? "scraping_added" : "adding",
      bottomHits: 0, saved: 0, addedPageHits: 0, captureFails: 0,
      waitStart: 0, hashBeforeAdded: "", openAttempts: 0,
      // Carousel tiles pressed (by offer id), numbers seen per carousel ("k
      // of N"), arrow presses per carousel and in all, and the last press.
      pressed: {}, seenSets: {}, slideN: {}, slides: 0, slide: null
    };

    // Chase's SPA occasionally rerenders sub-trees that contain our injected
    // panel. Each stat write goes through setText so a missing child element
    // is a silent no-op instead of "Cannot set properties of null".
    var setText = function (id, val) {
      var el = document.getElementById(id);
      if (el) el.innerText = val;
    };
    var update = function (s, t, q, p) {
      if (s) setText("cp-status", s);
      if (t !== undefined) setText("cp-seen", t);
      if (q !== undefined) setText("cp-queue", q);
      setText("cp-added", state.added);
      if (p !== undefined) setText("cp-pre", p);
      updateLastRun(state.added + state.addedPageHits);
    };

    // Chase uses two completely different DOM layouts:
    //
    //   Available list  (host /offerhub/list/all)
    //     <div data-cy="commerce-tile">
    //       <span class="mds-body-small-heavier">{merchant}</span>
    //       <span class="mds-body-large-heavier">{value}</span>
    //
    //   Added Offers list (host /offerhub/added)
    //     <div data-testid="added-offer-list-item-container"
    //          aria-label="<idx> of <total>\n  {merchant}\n  {constraint?}\n\n  {value}\n  {days} days left">
    //       <span class="listItemLabel ...">{merchant}</span>
    //       <span class="listItemLabel ...">{value}</span>
    //       <div data-testid="days-left-banner">{N}d left</div>
    //
    // captureChaseTile must handle both. We parse aria-label first when present
    // (Added Offers tiles always have a clean newline-delimited aria-label) and
    // fall back to the per-layout CSS selectors otherwise.
    var textOf = function (el) { return el ? (el.innerText || el.textContent || "").trim() : ""; };

    // Offer tiles on the offers page: the grid's (+ opens the offer's page)
    // and the carousels' button tiles (Nov 2026: "Grateful for great deals"),
    // each one offer, pressed to add it.
    var CHASE_TILE = '[data-cy="commerce-tile"], [data-cy="offer"], [data-testid="offer"]';
    var CHASE_BUTTON_TILE = '[data-cy="offer"], [data-testid="offer"]';
    // Already on the card: the grid tile's success alert, the button tile's
    // check or pressed state, or a label ending in "Added".
    var chaseAdded = function (t) {
      return !!t.querySelector('[data-testid="offer-tile-alert-container-success"], [data-testid="offer-accent-checkmark"]') ||
             t.getAttribute("aria-pressed") === "true" || /\bAdded\s*$/i.test(t.getAttribute("aria-label") || "");
    };
    // Pressed on this run. The mark holds the offer's id: a carousel may draw
    // another offer into the same tile. A button tile's offer stays pressed
    // when it's drawn again in a new tile before Chase shows it added.
    var chasePressed = function (t) {
      return t.getAttribute("data-chase-processed") === (t.id || "true") ||
             !!(t.id && state.pressed[t.id] && t.matches(CHASE_BUTTON_TILE));
    };

    var parseAriaLabel = function (tile) {
      var raw = tile.getAttribute("aria-label") || "";
      if (!raw) return null;
      var lines = raw.split("\n").map(function (s) { return s.trim(); }).filter(Boolean);
      if (lines.length < 2) return null;
      // lines[0] = "1 of 156" (positional) — discard if it matches that shape
      var startIdx = /^\d+\s+of\s+\d+$/i.test(lines[0]) ? 1 : 0;
      if (lines.length <= startIdx) return null;
      var merchant = lines[startIdx];
      var value = "", days = "";
      for (var i = startIdx + 1; i < lines.length; i++) {
        var l = lines[i];
        if (/days?\s*left/i.test(l) && !days) days = l;
        else if (/(\d+(?:\.\d+)?\s*%|\$\s*\d|cash\s*back|miles|points|back)/i.test(l) && !value) value = l;
      }
      if (!merchant || !value) return null;
      return { merchant: merchant, value: value, days: days };
    };

    var captureChaseTile = function (tile, forceStatus) {
      try {
        var merchant = "", value = "", days = "";
        var fromAria = parseAriaLabel(tile);
        if (fromAria) {
          merchant = fromAria.merchant;
          value = fromAria.value;
          days = fromAria.days;
        }
        // Available-list layout fallback
        if (!merchant) merchant = textOf(tile.querySelector(".mds-body-small-heavier"));
        if (!value)    value    = textOf(tile.querySelector(".mds-body-large-heavier"));
        // Carousel button tiles: merchant and headline spans.
        if (!merchant) merchant = textOf(tile.querySelector('.offerMerchantName, [data-testid="offer-merchant-name"]'));
        if (!value)    value    = textOf(tile.querySelector('[data-testid="offer-headline"]'));
        // Added-list span fallback (in case aria-label is ever stripped)
        if (!merchant || !value) {
          var spans = tile.querySelectorAll(".listItemLabel.semanticColorTextRegular");
          if (spans.length >= 2) {
            if (!merchant) merchant = textOf(spans[0]);
            if (!value)    value    = textOf(spans[1]);
          }
        }
        // Failing those, the tile's own lines: the first one, and the one that
        // reads like an offer.
        if (!merchant || !value) {
          var looks = function (s) { return /(\d+(?:\.\d+)?\s*%|\$\s*\d|cash\s*back|miles|points|back)/i.test(s); };
          var lines = String(tile.innerText || "").split("\n").map(function (s) { return s.trim(); }).filter(function (s) {
            return s && !/^new$/i.test(s) && !/\d+\s*d(?:ays?)?\s*left\b/i.test(s);
          });
          if (!merchant) merchant = lines.filter(function (s) { return !looks(s); })[0] || "";
          if (!value)    value    = lines.filter(looks)[0] || "";
        }
        if (!days) {
          var daysEl = tile.querySelector('[data-testid="days-left-banner"]');
          days = daysEl ? daysEl.innerText.trim() : "";
        }
        if (!days) days = extractExpiry(tile);
        if (!merchant || !value) { state.captureFails++; return false; }

        var isAddedTile = tile.matches && tile.matches('[data-testid="added-offer-list-item-container"]');
        var isAddedFlag = chaseAdded(tile);
        var status = forceStatus || (isAddedTile || isAddedFlag ? "added" : "available");
        var key = "chase_" + chaseCard.cardId + "_" + merchant.replace(/\W/g, "");
        saveOffer(key, merchant, value, "Chase", {
          days: days, expiresTs: parseExpiresTs(days), status: status,
          card: chaseCard.label, cardId: chaseCard.cardId, last4: chaseCard.last4
        });
        state.saved++;
        return true;
      } catch (e) { state.captureFails++; return false; }
    };

    var queryTiles = function (phase) {
      // The Available and Added pages use different selectors. Query by phase
      // so the queue / waiting / scraping logic doesn't pick up the wrong list.
      if (phase === "adding") {
        return Array.from(document.querySelectorAll(CHASE_TILE));
      }
      return Array.from(document.querySelectorAll('[data-testid="added-offer-list-item-container"]'));
    };

    var chasePress = function (el) {
      var o = { view: window, bubbles: true, cancelable: true };
      el.dispatchEvent(new MouseEvent("mousedown", o));
      el.dispatchEvent(new MouseEvent("mouseup", o));
      el.dispatchEvent(new MouseEvent("click", o));
    };

    // Carousels show a few offers at a time ("1 of 12"), with arrows. A
    // carousel is the nearest box around its right arrow that holds its list
    // (or tiles); what it shows is told apart by its tiles' ids or numbers.
    var CHASE_NEXT = '[data-testid="carouselRightChevron"]';
    var carouselOf = function (arrow, i) {
      var root = arrow.parentElement;
      while (root && root !== document.body && !root.querySelector(CHASE_TILE + ', [role="list"]')) root = root.parentElement;
      if (!root || root === document.body) return null;
      var tiles = Array.from(root.querySelectorAll(CHASE_TILE));
      return { key: arrow.getAttribute("aria-label") || String(i), tiles: tiles, shows: tiles.map(function (t) {
        var label = t.getAttribute("aria-label") || "";
        return t.id || (label.match(/^\s*\d+\s+of\s+\d+/) || [label])[0];
      }).join("|") };
    };

    // Once the offers on screen are done, the first carousel with numbers
    // not seen yet moves to its next set; false when none has any left.
    // Chase may draw a carousel back at its first set (after an offer's
    // page), so the numbers each one has shown are kept.
    var nextSlide = function () {
      if (state.slides >= 80) return false;
      var arrows = Array.from(document.querySelectorAll(CHASE_NEXT));
      for (var i = 0; i < arrows.length; i++) {
        var b = arrows[i], c = carouselOf(b, i);
        if (!c || b.disabled || b.getAttribute("aria-disabled") === "true") continue;
        var seen = state.seenSets[c.key] = state.seenSets[c.key] || {}, total = 0;
        c.tiles.forEach(function (t) {
          var m = (t.getAttribute("aria-label") || "").match(/^\s*(\d+)\s+of\s+(\d+)\b/);
          if (m) { seen[m[1]] = true; total = +m[2]; }
        });
        if (total && Object.keys(seen).length >= total) continue;
        // Unnumbered: move on while its arrow works, at most 30 times.
        if ((state.slideN[c.key] = (state.slideN[c.key] || 0) + 1) > 30) continue;
        state.slides++;
        state.slide = { key: c.key, shows: c.shows, at: Date.now() };
        b.scrollIntoView({ behavior: "auto", block: "center" });
        chasePress(b);
        return true;
      }
      return false;
    };

    // True after an arrow press until that carousel shows other offers, 6 s
    // at most; an arrow that changed nothing in that time isn't pressed again.
    var sliding = function () {
      var s = state.slide;
      if (!s) return false;
      var arrows = Array.from(document.querySelectorAll(CHASE_NEXT));
      for (var i = 0; i < arrows.length; i++) {
        var c = carouselOf(arrows[i], i);
        if (c && c.key === s.key && c.shows && c.shows !== s.shows) { state.slide = null; return false; }
      }
      if (Date.now() - s.at < 6000) return true;
      state.slideN[s.key] = 99;
      state.slide = null;
      return false;
    };

    var stopWith = function (msg, t) {
      update(msg, t === undefined ? 0 : t, 0, state.saved);
      state.run = false;
      stopEvery(loop);
      finished("Chase", msg, { added: state.added, saved: state.saved, history: state.addedPageHits });
    };

    var loop = every(400, function () {
      if (!state.run) return;
      // SPA rerender wiped our panel — there's nothing left to drive or
      // report to. Stop the interval instead of hammering null DOM.
      if (!document.getElementById("chase-autopilot-ui")) {
        state.run = false; stopEvery(loop); return;
      }

      // The 'mds-secondary-back-navbar' Going-back handler ONLY applies during
      // the 'adding' phase — it backs out of accidental offer-detail sub-pages
      // we may have clicked into. After 'opening_added', the Added Offers list
      // itself renders inside the same secondary-back-navbar shell, so auto-
      // clicking Back here would immediately undo our navigation and the
      // harvest would never run.  This was the original bug.
      if (state.phase === "adding") {
        var nav = document.getElementById("mds-secondary-back-navbar");
        if (nav && nav.getBoundingClientRect().width > 0 && nav.shadowRoot) {
          var bb = nav.shadowRoot.getElementById("back-button");
          if (bb) { update("Going back..."); bb.click(); return; }
        }
      }

      if (state.baselineOld === null) {
        var header = document.querySelector('[aria-label$="Added offers"]');
        if (header) {
          var m = header.getAttribute("aria-label").match(/^(\d+)/);
          state.baselineOld = m ? parseInt(m[1]) : 0;
        } else state.baselineOld = 0;
      }

      var tiles = queryTiles(state.phase);

      if (state.phase === "adding") {
        var queue = tiles.filter(function (t) { return !chaseAdded(t) && !chasePressed(t); });
        var totalScanned = state.added + queue.length;
        // A carousel just moved on: wait for it to show its next set.
        var moving = !queue.length && sliding();
        update(queue.length > 0 ? "Adding offers..." : moving ? "Showing more offers..." : "All available added. Loading history...",
               totalScanned, queue.length, state.saved);

        if (queue.length > 0) {
          var target = queue[0];
          state.slide = null;
          target.setAttribute("data-chase-processed", target.id || "true");
          if (target.id) state.pressed[target.id] = true;
          target.scrollIntoView({ behavior: "auto", block: "center" });
          captureChaseTile(target);
          var addBtn = target.querySelector('[data-testid="commerce-tile-button"]') || target;
          state.added++;
          update("Adding...");
          chasePress(addBtn);
        } else if (moving) {
          return;
        } else if (nextSlide()) {
          update("Showing more offers...", totalScanned, 0, state.saved);
        } else {
          state.phase = "opening_added";
        }
      } else if (state.phase === "opening_added") {
        var link = document.querySelector('[data-testid="hub-header-addedoffers"]')
                || document.querySelector('a[href*="addedoffers" i]')
                || document.querySelector('[aria-label*="Added offers" i]');
        if (link) {
          update("Opening Added Offers...", state.added, 0, state.saved);
          // Wipe per-tile markers so recycled DOM tiles re-capture on the next view.
          // Chase's SPA frequently reuses tile nodes for both Available and Added
          // lists; without this, every recycled tile is skipped by 'data-chase-saved'.
          document.querySelectorAll("[data-chase-processed],[data-chase-saved]").forEach(function (n) {
            n.removeAttribute("data-chase-processed");
            n.removeAttribute("data-chase-saved");
          });
          state.hashBeforeAdded = window.location.hash || "";
          var o2 = { view: window, bubbles: true, cancelable: true };
          link.dispatchEvent(new MouseEvent("mousedown", o2));
          link.dispatchEvent(new MouseEvent("mouseup", o2));
          link.dispatchEvent(new MouseEvent("click", o2));
          // Fallback in case dispatched events were intercepted
          try { link.click(); } catch (e) {}
          state.phase = "wait_added";
          state.waitStart = Date.now();
          state.openAttempts++;
        } else {
          stopWith("Done. " + state.saved + " saved.", state.added);
        }
      } else if (state.phase === "wait_added") {
        // `tiles` is queried with the added-offer-list-item-container selector
        // (queryTiles returns that for any non-'adding' phase). Its presence is
        // a definitive signal that the Added Offers view has rendered — the hash
        // route doesn't change on this navigation, so we rely on DOM only.
        var elapsed = Date.now() - state.waitStart;
        if (tiles.length > 0 && elapsed > 600) {
          state.phase = "scraping_added";
          state.bottomHits = 0;
        } else if (tiles.length === 0 && elapsed > 2500 && state.openAttempts < 2) {
          // Click was swallowed (no Added Offers tiles appeared). Retry once.
          state.phase = "opening_added";
        } else if (elapsed > 12000) {
          stopWith("Added Offers did not load. " + state.saved + " saved.", tiles.length);
        } else {
          update("Loading Added Offers... (" + tiles.length + " tiles)", tiles.length, 0, state.saved);
        }
      } else if (state.phase === "scraping_added") {
        // Pure text-scrape — we never click these tiles, so pace it like one.
        // Jump straight to the bottom of the page on every tick (cheap; no-op
        // if already there). If Chase virtualizes the list, the new tiles
        // render under the existing ones and we sweep them on the next tick.
        // Stop when a sweep produces no new saves twice in a row.
        window.scrollTo(0, document.body.scrollHeight);
        var newSaves = 0;
        tiles.forEach(function (tile) {
          if (!tile.hasAttribute("data-chase-saved")) {
            tile.setAttribute("data-chase-saved", "true");
            if (captureChaseTile(tile, "added")) { state.addedPageHits++; newSaves++; }
          }
        });
        update("Harvested " + state.addedPageHits + " of " + tiles.length + " added offers...",
               tiles.length, 0, state.saved);
        if (newSaves === 0) {
          state.bottomHits++;
          if (state.bottomHits >= 2) {
            var msg = "Done. " + state.added + " added, " + state.addedPageHits + " from history.";
            if (state.captureFails > 0) msg += " (" + state.captureFails + " skipped)";
            stopWith(msg, tiles.length);
          }
        } else {
          state.bottomHits = 0;
        }
      }
    });

    document.getElementById("cp-close").onclick = function () {
      state.run = false; stopEvery(loop); ui.remove();
    };
    return;
  }

  /* ============================================================ */
  /*                        AMEX  (enhanced)                      */
  /* ============================================================ */
  //
  // Amex flow (two physically distinct pages, joined by a hard navigation):
  //
  //   /offers (main hub)         Available offer tiles render with
  //                              <button data-testid="merchantOfferListAddButton">.
  //                              The "Added to Card" strip has a "View All" anchor
  //                                <a id="added-view-more-header"
  //                                   href="/offers/enrolled?opaqueAccountId=...">
  //                              that links to the full Added Offers page.
  //
  //   /offers/enrolled           Server-rendered full list of every added offer,
  //                              under "Added to Card (N)". Each row carries
  //                                [data-testid="merchantOfferSuccessIcon"]
  //                              with merchant in its title (an h3 whose class
  //                              Amex renames: heading-sans-small-medium, then
  //                              _headingSansSmallMedium_1uvwt_43) and value in
  //                              the second
  //                                [data-testid="overflowTextContainer"] span.
  //                              Rows are read without classes (amexRowFinder,
  //                              amexReadRow below).
  //
  // Clicking View All performs a hard navigation. To survive the reload and
  // continue harvesting on the enrolled page, the extension auto-injects this
  // file on `/offers/enrolled*` via manifest content_scripts and we hand off
  // state through sessionStorage:
  //
  //   UOH_PopupTrigger  set by popup.js right before chrome.scripting.execute.
  //                     Distinguishes "user pressed Run" from a passive content-
  //                     script auto-inject during normal browsing. Consumed on
  //                     first scraper entry.
  //
  //   UOH_AmexResume    set (to Date.now()) by the autopilot just before
  //                     navigating from /offers to /offers/enrolled. The
  //                     auto-injected scraper on the new page reads it to know
  //                     "we're resuming a run, jump straight to harvest", and
  //                     honours it for 2 minutes only, so a run that died
  //                     mid-navigation can't start the autopilot on a later
  //                     visit. Cleared once harvest finishes.
  //
  //   UOH_AmexAddedRun  carry-over count of offers added on the previous page,
  //                     so the harvest-page UI can still display it.
  //
  if (host.indexOf("americanexpress.com") > -1) {
    // Detect the enrolled / Added-Offers page via DOM markers, not just URL —
    // the user may land here through a non-canonical route (deep link, bookmark
    // with extra params, search-result click) and the URL form isn't a stable
    // contract. merchantOfferSuccessIcon appears once per added offer and
    // never on the main /offers hub, so it's our authoritative signal.
    var amexPath = window.location.pathname;
    var isEnrolledPage = /\/offers\/enrolled/i.test(amexPath)
      || !!document.querySelector('[data-testid="merchantOfferSuccessIcon"], [data-testid="addedToCardViewAllContainer"]');

    // Tell a real popup-triggered run apart from passive auto-inject.
    var popupTriggerTs = 0;
    try { popupTriggerTs = parseInt(sessionStorage.getItem("UOH_PopupTrigger") || "0", 10); } catch (e) {}
    var hasPopupTrigger = popupTriggerTs && (Date.now() - popupTriggerTs) < 15000;
    if (hasPopupTrigger) { try { sessionStorage.removeItem("UOH_PopupTrigger"); } catch (e) {} }

    // A v2 flag holds "1", which parses as 1 and so reads as stale.
    var hasResumeFlag = false;
    try {
      var resumeTs = parseInt(sessionStorage.getItem("UOH_AmexResume") || "0", 10);
      hasResumeFlag = resumeTs > 1 && (Date.now() - resumeTs) < 120000;
    } catch (e) {}

    // Auto-inject (no trigger, no resume) on the enrolled page = a normal user
    // browsing their added offers. Don't pop the autopilot UI for that.
    if (isEnrolledPage && !hasPopupTrigger && !hasResumeFlag) return;

    if (document.getElementById("amex-autopilot-ui")) return;
    var amexCard = amexCardInfo();
    var aui = document.createElement("div");
    aui.id = "amex-autopilot-ui";
    aui.style.cssText = "position:fixed;bottom:20px;right:20px;width:240px;background:#1c2b36;color:#fff;font-family:sans-serif;font-size:12px;border-radius:8px;box-shadow:0 8px 24px rgba(0,0,0,0.4);z-index:999999;border:1px solid #455a64;overflow:hidden;";
    aui.innerHTML = '<div style="background:#006FCF;padding:10px;font-weight:700;display:flex;justify-content:space-between;align-items:center;"><span>Amex Autopilot</span><span id="cp-close" style="cursor:pointer;font-size:16px;opacity:0.8;">&times;</span></div><div style="padding:12px;"><div style="margin-bottom:8px;color:#90a4ae;">STATUS</div><div id="cp-status" style="color:#4caf50;font-weight:600;margin-bottom:12px;line-height:1.4;">Starting...</div><div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;text-align:center;"><div style="background:#263238;padding:6px;border-radius:4px;"><div id="cp-seen" style="font-weight:700;font-size:14px;">0</div><div style="font-size:10px;color:#78909c;">Scanned</div></div><div style="background:#263238;padding:6px;border-radius:4px;"><div id="cp-queue" style="font-weight:700;font-size:14px;color:#ffb74d;">0</div><div style="font-size:10px;color:#78909c;">Queue</div></div><div style="background:#263238;padding:6px;border-radius:4px;"><div id="cp-added" style="font-weight:700;font-size:14px;color:#4caf50;">0</div><div style="font-size:10px;color:#78909c;">Added New</div></div><div style="background:#263238;padding:6px;border-radius:4px;"><div id="cp-pre" style="font-weight:700;font-size:14px;color:#90a4ae;">0</div><div style="font-size:10px;color:#78909c;">Saved</div></div></div></div>';
    document.body.appendChild(aui);

    // Restore "added" count across the page navigation so the right-side UI
    // still shows what we did on the previous page after auto-resume.
    var carriedAdded = 0;
    try { carriedAdded = parseInt(sessionStorage.getItem("UOH_AmexAddedRun") || "0", 10) || 0; } catch (e) {}

    var astate = {
      added: carriedAdded, run: true, baselineOld: null, saved: 0,
      phase: isEnrolledPage ? "scraping_added" : "adding",
      addedPageHits: 0, bottomHits: 0, navStart: 0, lastRows: -1, sameTicks: 0,
      // ACK-wait state for the adding phase. AMEX's Add-to-Card API runs
      // serially (~2s/offer); a fast-fire dispatch puts dozens of calls in
      // flight while the DOM still shows the original "+" buttons until each
      // one ACKs. We keep firing clicks fast (current behaviour) but, once
      // the per-tile queue is exhausted, we sit in the adding phase polling
      // two signals before navigating to /offers/enrolled:
      //   (1) every `button[data-testid="merchantOfferListAddButton"]` has
      //       been removed from the DOM, AND
      //   (2) the success-icon count
      //       `[data-testid="merchantOfferSuccessIcon"][data-dls-icon-color="success"]`
      //       has grown by `astate.added` (= initialSuccess + clicks).
      // settleProgress + settleStallStart implement a 30s no-progress timeout
      // so a stalled offer (rate-limit, network error) can't deadlock the loop.
      initialSuccess: null, settleProgress: -1, settleStallStart: 0
    };

    var setAText = function (id, val) {
      var el = document.getElementById(id);
      if (el) el.innerText = val;
    };
    var aupdate = function (s, t, q, p) {
      if (s) setAText("cp-status", s);
      if (t !== undefined) setAText("cp-seen", t);
      if (q !== undefined) setAText("cp-queue", q);
      setAText("cp-added", astate.added);
      if (p !== undefined) setAText("cp-pre", p);
      updateLastRun(astate.added + astate.addedPageHits);
    };

    var amexOldCount = function () {
      var container = document.querySelector('[data-testid="addedToCardContainer"]');
      if (container) {
        var spans = Array.from(container.querySelectorAll("span"));
        var target = spans.find(function (s) { return s.innerText.indexOf("Added to Card") > -1; });
        if (target) {
          var m = target.innerText.match(/\((\d+)\)/);
          if (m) return parseInt(m[1]);
        }
      }
      return null;
    };

    var amexTextOf = function (el) { return el ? (el.innerText || el.textContent || "").trim() : ""; };

    var findViewAll = function () {
      return document.getElementById("added-view-more-header")
          || document.querySelector('a[aria-label="View All"][href*="/offers/enrolled"]')
          || document.querySelector('a[href*="/offers/enrolled"]');
    };

    // Amex renames its CSS classes (Nov 2026: an offer's title went from
    // h3.heading-sans-small-medium to h3._headingSansSmallMedium_1uvwt_43 and
    // nothing was saved after), so offers are read without them: a row is
    // found from the page's structure, around one thing each row has once,
    // and its fields from Amex's test ids, its title, its logo's alt text or
    // its text.
    var AMEX_ADD = 'button[data-testid="merchantOfferListAddButton"]';
    var AMEX_ADDED = '[data-testid="merchantOfferSuccessIcon"]';
    // What marks an added offer's row, in the order tried: its check, View
    // Details, Terms, then its "Expires 12/31/26" line (tagged by amexMarks).
    var AMEX_MARKS = [AMEX_ADDED, '[data-testid="merchantOfferDetailsLink"]', '[data-testid="merchantOfferTermsLink"]', "[data-uoh-expiry]"];
    var AMEX_EXPIRY = /^(?:expires?\s*(?:on|in)?\s*:?\s*(?:\d{1,2}\/\d{1,2}\/\d{2,4}|(?:jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)[a-z]*\.?\s+\d{1,2},?\s+\d{4}|\d+\s*days?)|\d+\s*d(?:ays?)?\s*left)\b/i;
    var AMEX_TERMS = /\b(?:spend|earn|back|points?|miles|credit|off|cash|purchases?)\b|\$\s?\d|\d\s?%/i;

    // Each kind of mark on the page with its matches, in the order tried.
    var amexMarks = function () {
      Array.prototype.forEach.call(document.querySelectorAll("body *:not([data-uoh-expiry])"), function (el) {
        if (!el.children.length && AMEX_EXPIRY.test((el.textContent || "").trim())) el.setAttribute("data-uoh-expiry", "");
      });
      return AMEX_MARKS.map(function (sel) { return { sel: sel, nodes: Array.from(document.querySelectorAll(sel)) }; })
        .filter(function (k) { return k.nodes.length; });
    };

    // An offer's row: the biggest box around a mark that holds no other
    // match of sel, none of the page's headings (h1, h2) and at most one
    // title, however Amex nests and names it. Every row shares the boxes
    // above it, so each box is checked once.
    var amexRowFinder = function (sel) {
      var ends = new Map();
      var stop = function (n) {
        if (!ends.has(n)) {
          ends.set(n, n.querySelectorAll(sel).length > 1 || !!n.querySelector("h1, h2") ||
                      n.querySelectorAll("h3, h4, h5, h6").length > 1);
        }
        return ends.get(n);
      };
      return function (el) {
        var row = el;
        for (var n = el.parentElement, i = 0; n && n !== document.body && i < 30 && !stop(n); n = n.parentElement, i++) row = n;
        return row;
      };
    };

    // A row's text, piece by piece in page order, without its buttons'
    // labels ("View Details", "Terms apply"), its check or a "NEW" badge.
    var amexPieces = function (row) {
      var out = [], walk = document.createTreeWalker(row, NodeFilter.SHOW_TEXT), t;
      while ((t = walk.nextNode())) {
        var s = t.nodeValue.replace(/\s+/g, " ").trim(), p = t.parentElement;
        if (s && !/^new$/i.test(s) && !(p && p.closest("button, script, style, " + AMEX_ADDED))) out.push(s);
      }
      return out;
    };

    // An offer's merchant, terms and expiry from its row, each with fallbacks.
    var amexReadRow = function (row) {
      var boxes = row.querySelectorAll('[data-testid="overflowTextContainer"]'), logo = row.querySelector("img[alt]");
      var pieces = amexPieces(row).filter(function (s) { return !AMEX_EXPIRY.test(s); });
      var merchant = amexTextOf(row.querySelector("h1, h2, h3, h4, h5, h6, [role=heading]")) || amexTextOf(boxes[0]) ||
                     (logo ? String(logo.getAttribute("alt") || "").trim() : "") ||
                     pieces.filter(function (s) { return !AMEX_TERMS.test(s); })[0] || "";
      var value = (boxes.length > 1 ? amexTextOf(boxes[1]) : "") ||
                  pieces.filter(function (s) { return s !== merchant && AMEX_TERMS.test(s); })[0] || "";
      return { merchant: merchant, value: value, days: extractExpiry(row) };
    };

    // The Added page's own count, "Added to Card (120)"; null without one.
    // On /offers, the strip's.
    var amexListed = function () {
      var m = String(document.body ? document.body.textContent : "").match(/Added to Card\s*\(\s*(\d[\d,]*)\s*\)/i);
      return m ? parseInt(m[1].replace(/,/g, ""), 10) : null;
    };

    // Each offer is saved under the card's Amex id (amexCard.cardId). On /offers
    // a card with no added offer doesn't show its id yet, so the available
    // offers read before its first add wait here (amexHeld) for the View All
    // link that add brings.
    var amexHeld = [];
    var amexLearnId = function () {
      if (amexCard.id) return;
      var id = amexAccountId();
      if (id) { amexCard.id = id; amexCard.cardId = id; }
    };
    var amexSave = function (o, status) {
      saveOffer(
        "amex_" + amexCard.cardId + "_" + o.merchant.replace(/\W/g, ""),
        o.merchant, o.value, "Amex",
        {
          status: status, days: o.days, expiresTs: parseExpiresTs(o.days),
          card: amexCard.label, cardId: amexCard.cardId, last4: amexCard.last4
        }
      );
    };
    // Saves the offers that waited, once the page shows the card's id; with
    // anyway, now, under its last digits if it still doesn't. Returns how many.
    var amexSaveHeld = function (anyway) {
      amexLearnId();
      if (!amexHeld.length || (!amexCard.id && !anyway)) return 0;
      var held = amexHeld;
      amexHeld = [];
      held.forEach(function (o) { amexSave(o, "available"); });
      return held.length;
    };

    // Reads the Added page once, with the kind of mark whose rows read best
    // (a test id Amex dropped or doubled loses to the next kind), and saves
    // each offer read. rows: how many offers the page shows.
    var harvestAdded = function (kinds) {
      var best = { rows: 0, offers: [] };
      kinds.forEach(function (k) {
        var rowOf = amexRowFinder(k.sel), rows = new Set();
        k.nodes.forEach(function (n) { rows.add(rowOf(n)); });
        var offers = Array.from(rows).map(amexReadRow).filter(function (o) { return o.merchant && o.value; });
        if (offers.length > best.offers.length || (!best.rows && rows.size)) best = { rows: rows.size, offers: offers };
      });
      best.offers.forEach(function (o) {
        amexSave(o, "added");
        astate.saved++;
        astate.addedPageHits++;
      });
      return { rows: best.rows, read: best.offers.length };
    };

    // failed: the run couldn't do all of its job; it says why (msg), in red,
    // and the card's result carries it (content/auto-core.js).
    var stopAmex = function (msg, failed) {
      amexSaveHeld(true);
      try { sessionStorage.removeItem("UOH_AmexResume"); } catch (e) {}
      try { sessionStorage.removeItem("UOH_AmexAddedRun"); } catch (e) {}
      aupdate(msg, undefined, 0, astate.saved);
      if (failed) { var st = document.getElementById("cp-status"); if (st) st.style.color = "#ff8a80"; }
      astate.run = false; stopEvery(aloop);
      finished("Amex", msg, { added: astate.added, saved: astate.saved, history: astate.addedPageHits }, failed ? msg : "");
    };

    // Fewer offers read than the Added page shows means Amex changed it:
    // the run fails and says so instead of passing with nothing saved.
    var amexHarvestDone = function (listed, got) {
      var want = listed == null ? got.rows : listed;
      if (!want && listed == null) {
        stopAmex("Found no offers on this card's Added page. Amex may have changed that page.", true);
      } else if (got.read < want) {
        stopAmex("Read " + got.read + " of the " + want + " offers on this card's Added page. Amex may have changed that page.", true);
      } else {
        stopAmex("Done. " + astate.added + " added, " + astate.addedPageHits + " from history.");
      }
    };

    var aloop = every(250, function () {
      if (!astate.run) return;
      if (!document.getElementById("amex-autopilot-ui")) {
        astate.run = false; stopEvery(aloop); return;
      }

      if (astate.phase === "adding") {
        if (amexHeld.length) amexSaveHeld();
        if (astate.baselineOld === null) {
          astate.baselineOld = amexOldCount();
          if (astate.baselineOld === null) astate.baselineOld = 0;
        }
        // Capture the page's pre-existing success-icon count exactly once so
        // we can compute "new icons appeared since we started".
        var successSel = '[data-testid="merchantOfferSuccessIcon"][data-dls-icon-color="success"]';
        if (astate.initialSuccess === null) {
          astate.initialSuccess = document.querySelectorAll(successSel).length;
        }

        var buttons = Array.from(document.querySelectorAll('button[data-testid="merchantOfferListAddButton"]'));
        var queue = buttons.filter(function (b) { return !b.hasAttribute("data-amex-processed"); });

        if (queue.length > 0) {
          // Fast-fire click — same as before. AMEX queues the API call.
          var totalScanned = astate.added + queue.length;
          aupdate("Adding offers...", totalScanned, queue.length, astate.saved);

          var btn = queue[0];
          btn.setAttribute("data-amex-processed", "true");
          btn.scrollIntoView({ behavior: "auto", block: "center" });
          try {
            var avail = amexReadRow(amexRowFinder(AMEX_ADD + ", " + AMEX_ADDED)(btn));
            if (avail.merchant && avail.value) {
              amexLearnId();
              if (amexCard.id) amexSave(avail, "available"); else amexHeld.push(avail);
            }
          } catch (e) {}
          astate.added++;
          var o2 = { view: window, bubbles: true, cancelable: true };
          btn.dispatchEvent(new MouseEvent("mousedown", o2));
          btn.dispatchEvent(new MouseEvent("mouseup", o2));
          btn.dispatchEvent(new MouseEvent("click", o2));
        } else {
          // Queue is empty — every visible "+" has been clicked. Now poll for
          // AMEX's API ACKs: only navigate when (a) no add buttons remain in
          // the DOM AND (b) the success-icon count has grown by astate.added.
          var newSuccess = document.querySelectorAll(successSel).length - astate.initialSuccess;
          var allButtonsGone = buttons.length === 0;
          var allIconsShowing = newSuccess >= astate.added;

          if (allButtonsGone && allIconsShowing) {
            aupdate("All available added. Loading history...", astate.added, 0, astate.saved);
            astate.phase = "opening_added";
          } else {
            // Track progress so the 30s stall timer only fires after real
            // inactivity (count not changing for 30 consecutive seconds).
            // Progress = (buttons cleared) + (icons confirmed) — increases
            // monotonically while AMEX is still ACKing.
            var progress = (astate.added - buttons.length) + newSuccess;
            if (progress !== astate.settleProgress) {
              astate.settleProgress = progress;
              astate.settleStallStart = Date.now();
            }
            aupdate(
              "Waiting for AMEX confirms — " + newSuccess + "/" + astate.added +
              " icons, " + buttons.length + " btns left...",
              astate.added, buttons.length, astate.saved
            );
            if (astate.settleStallStart && Date.now() - astate.settleStallStart > 30000) {
              // 30s of no progress — most likely a stalled / failed offer.
              // Move on so the Added Offers harvest still runs.
              aupdate("Settle timed out, moving on...", astate.added, buttons.length, astate.saved);
              astate.phase = "opening_added";
            }
          }
        }
      } else if (astate.phase === "opening_added") {
        var link = findViewAll();
        if (!link) {
          // Offers on the card and no way to their page: Amex changed /offers.
          if (astate.added || amexListed()) stopAmex("Found no View All link to this card's Added offers. Amex may have changed the page.", true);
          else stopAmex("Done. No View All link found.");
          return;
        }
        // Offers still waiting for the card's id are saved a step before the
        // page changes (the link names the id).
        if (amexSaveHeld(true)) return;
        aupdate("Opening Added Offers...", astate.added, 0, astate.saved);
        try { sessionStorage.setItem("UOH_AmexResume", String(Date.now())); } catch (e) {}
        try { sessionStorage.setItem("UOH_AmexAddedRun", String(astate.added)); } catch (e) {}
        astate.navStart = Date.now();
        astate.phase = "wait_enrolled";
        // The click below is a hard navigation; send the bridge's pending
        // batch now rather than relying on its 250 ms timer.
        try { window.postMessage({ __uoh: true, type: "FLUSH" }, "*"); } catch (e) {}
        try {
          link.scrollIntoView({ behavior: "auto", block: "center" });
          var o3 = { view: window, bubbles: true, cancelable: true };
          link.dispatchEvent(new MouseEvent("mousedown", o3));
          link.dispatchEvent(new MouseEvent("mouseup", o3));
          link.dispatchEvent(new MouseEvent("click", o3));
        } catch (e) {}
      } else if (astate.phase === "wait_enrolled") {
        // SPA route: URL switches but this script stays alive. Hard nav: script
        // dies and the content_scripts auto-inject revives us on /offers/enrolled
        // — that fresh instance starts in scraping_added directly. This branch
        // only fires if the click was a soft SPA route or the navigation stalled.
        var elapsed = Date.now() - astate.navStart;
        if (/\/offers\/enrolled/i.test(window.location.pathname)) {
          astate.phase = "scraping_added";
          astate.bottomHits = 0;
        } else if (elapsed > 4000) {
          // Click was swallowed (overlay, etc.) — force the navigation.
          var lk = findViewAll();
          if (lk && lk.href) {
            try { window.location.href = lk.href; } catch (e) {}
            astate.navStart = Date.now() + 60000; // suppress retry
          } else {
            stopAmex("Could not open Added Offers page.", true);
          }
        } else {
          aupdate("Waiting for Added Offers page...", astate.added, 0, astate.saved);
        }
      } else if (astate.phase === "scraping_added") {
        // The enrolled page server-renders every tile in one go (no pagination,
        // no virtualization), so it is read in one pass once the rows are all
        // there: as many as its "Added to Card (N)" says, or a count that
        // holds for a step when it says none.
        var listed = amexListed(), kinds = amexMarks(), rowsNow = kinds.length ? kinds[0].nodes.length : 0;
        if (!rowsNow && listed !== 0) {
          if (++astate.bottomHits > 30) { amexHarvestDone(listed, { rows: 0, read: 0 }); return; }
          aupdate("Loading Added Offers list...", 0, 0, astate.saved);
          return;
        }
        astate.sameTicks = rowsNow === astate.lastRows ? astate.sameTicks + 1 : 0;
        astate.lastRows = rowsNow;
        // Fewer rows than it says: wait up to 5 s for the rest.
        if (listed == null ? astate.sameTicks < 1 : rowsNow < listed && astate.sameTicks < 20) {
          aupdate("Loading Added Offers list (" + rowsNow + (listed == null ? "" : " of " + listed) + ")...", rowsNow, 0, astate.saved);
          return;
        }
        amexHarvestDone(listed, harvestAdded(kinds));
      }
    });

    document.getElementById("cp-close").onclick = function () {
      try { sessionStorage.removeItem("UOH_AmexResume"); } catch (e) {}
      try { sessionStorage.removeItem("UOH_AmexAddedRun"); } catch (e) {}
      astate.run = false; stopEvery(aloop); aui.remove();
    };
    return;
  }

  /* ============================================================ */
  /*                       CAPITAL ONE                            */
  /* ============================================================ */
  if (host.indexOf("capitalone.com") > -1 || host.indexOf("capitaloneoffers.com") > -1) {
    var c1Card = capOneCardInfo();
    var C1_STYLES = "#c1-scraper-root{font-family:'Segoe UI',Roboto,Helvetica,Arial,sans-serif;position:fixed;z-index:2147483647;top:10px;left:10px;background:#fff;box-shadow:0 10px 40px rgba(0,0,0,0.3);border-radius:12px;display:flex;flex-direction:column;overflow:hidden;border:1px solid #ddd;transition:all .3s ease;right:10px;bottom:10px;max-width:1000px;max-height:850px;margin:auto}#c1-scraper-root.minimized{width:180px;height:40px;top:auto;left:auto;bottom:20px;right:20px;border-radius:20px;cursor:pointer;background:#004879;box-shadow:0 4px 10px rgba(0,0,0,0.3);border:2px solid #fff}#c1-scraper-root.minimized *{display:none}#c1-scraper-root.minimized .min-label{display:flex!important;color:#fff;font-weight:700;width:100%;height:100%;align-items:center;justify-content:center;font-size:14px;text-transform:uppercase;letter-spacing:0.5px}.c1-header{background:#004879;color:#fff;padding:12px 16px;display:flex;justify-content:space-between;align-items:center;flex-shrink:0;cursor:grab}.c1-controls{display:flex;gap:8px}.c1-btn-icon{background:rgba(255,255,255,.2);border:none;color:#fff;border-radius:4px;cursor:pointer;padding:2px 8px;font-size:14px}.c1-stats{background:#f4f4f4;padding:8px 12px;font-size:12px;border-bottom:1px solid #e0e0e0;display:flex;flex-wrap:wrap;gap:10px;justify-content:space-around;flex-shrink:0}.c1-stat-item b{color:#004879}.c1-toolbar{padding:10px;border-bottom:1px solid #eee;background:#fff;flex-shrink:0;display:flex;flex-direction:column;gap:10px}.c1-search{width:100%;padding:8px;border:1px solid #ccc;border-radius:6px;font-size:14px;box-sizing:border-box}.c1-filter-group{display:flex;flex-wrap:wrap;gap:6px;max-height:80px;overflow-y:auto;padding-bottom:4px}.c1-chip{padding:4px 10px;font-size:11px;border:1px solid #ccc;background:#f9f9f9;color:#555;border-radius:12px;cursor:pointer;transition:all .2s;user-select:none}.c1-chip:hover{background:#eee;border-color:#bbb}.c1-chip.active{background:#004879;color:#fff;border-color:#004879;font-weight:600;box-shadow:0 2px 4px rgba(0,72,121,0.2)}.c1-chip.tag-new.active{background:#FF8C00;border-color:#FF8C00;color:#000}.c1-chip.tag-excl.active{background:#4CAF50;border-color:#4CAF50}.c1-chip.tag-bonus.active{background:#7C3AED;border-color:#7C3AED;color:#fff}.c1-sort-group{display:flex;gap:5px;justify-content:space-between;margin-top:4px}.c1-sort-btn{flex:1;padding:6px 2px;font-size:11px;border:1px solid #004879;background:#fff;color:#004879;border-radius:4px;cursor:pointer;transition:all .2s;text-align:center}.c1-sort-btn.active{background:#004879;color:#fff}.c1-export-btn{padding:6px 12px;font-size:12px;border:1px solid #2e7d32;background:#fff;color:#2e7d32;border-radius:4px;cursor:pointer;font-weight:bold;transition:all .2s;white-space:nowrap}.c1-export-btn:hover{background:#2e7d32;color:#fff}.c1-table-wrapper{flex-grow:1;overflow-y:auto;position:relative}table{width:100%;border-collapse:collapse;font-size:13px}thead{position:sticky;top:0;background:#fff;z-index:10;box-shadow:0 1px 2px rgba(0,0,0,.1)}th{text-align:center;padding:10px 8px;color:#555;font-weight:600;border-bottom:2px solid #eee;cursor:pointer;user-select:none}th:first-child{text-align:left}th#th-v{text-align:center}th:hover{background:#f9f9f9}td{padding:8px;border-bottom:1px solid #f0f0f0;color:#333;vertical-align:middle}tr:hover{background-color:#f0f8ff;cursor:pointer}.col-val{font-weight:700;color:#2e7d32;text-align:center}.val-container{display:flex;align-items:center;justify-content:center;gap:8px}.col-chan{text-align:center;font-size:11px;color:#666}.tag-badge{font-size:10px;padding:2px 6px;border-radius:4px;text-transform:uppercase;color:#fff;font-weight:bold;white-space:nowrap;box-shadow:0 1px 2px rgba(0,0,0,0.1)}.tag-new{background-color:#FF8C0020;color:#000}.ltag-new{background-color:#FF8C00;color:#000}.tag-excl{background-color:#4CAF5020}.ltag-excl{background-color:#4CAF50}.tag-bonus{background-color:#7C3AED20}.ltag-bonus{background-color:#7C3AED}.min-label{display:none}";
    var s = document.createElement("style"); s.textContent = C1_STYLES; document.head.appendChild(s);

    var st = { offers: new Map(), sortMode: "MILES", valSortDir: "DESC", search: "", isLoading: true, uiMinimized: false, activeFilters: new Set(["ALL"]) };
    var FILTERS = [
      { id: "ALL", label: "All" },
      { id: "NEW", label: "New", isTag: true },
      { id: "EXCLUSIVE", label: "Exclusive", isTag: true },
      { id: "BONUS", label: "Bonus", isTag: true }
    ];

    var el = function (t, p, c) {
      p = p || {}; c = c || [];
      var e = document.createElement(t);
      Object.entries(p).forEach(function (kv) {
        var k = kv[0], v = kv[1];
        if (k.startsWith("on")) e.addEventListener(k.substring(2).toLowerCase(), v);
        else if (k === "style") e.style.cssText = v;
        else e.setAttribute(k, v);
      });
      c.forEach(function (n) { typeof n === "string" ? e.appendChild(document.createTextNode(n)) : e.appendChild(n); });
      return e;
    };

    // The autopilot's clock (every() above). With UOH_AutoTicks (auto-add's
    // background tab) a wait ends on the first "uoh-autopilot-tick" at or
    // after its time, and a run whose panel was removed or replaced stops at
    // its next wait, so it can't save the next card's offers under this one.
    // The toolbar button's run keeps setTimeout.
    var c1Root = null;
    var c1Wait = function (ms) {
      if (!autoTicks) return new Promise(function (r) { setTimeout(r, ms); });
      var end = Date.now() + ms;
      return new Promise(function (r) {
        var on = function () {
          var gone = c1Root !== document.getElementById("c1-scraper-root");
          if (!gone && Date.now() < end) return;
          document.removeEventListener("uoh-autopilot-tick", on);
          if (!gone) r();
        };
        document.addEventListener("uoh-autopilot-tick", on);
      });
    };

    var reactClick = async function (e) {
      if (!e) return;
      e.scrollIntoView({ behavior: "smooth", block: "center", inline: "center" });
      await c1Wait(100);
      ["mouseover", "mousedown", "mouseup", "click"].forEach(function (t) {
        e.dispatchEvent(new MouseEvent(t, { bubbles: true, cancelable: true, view: window, buttons: 1 }));
      });
      var k = Object.keys(e).find(function (k) { return k.startsWith("__reactProps") || k.startsWith("__reactFiber"); });
      if (k && e[k]) {
        var p = e[k].memoizedProps || e[k].props;
        if (p && p.onClick) p.onClick({ stopPropagation: function () {}, preventDefault: function () {} });
        else if (p && p.children && p.children.props && p.children.props.onClick)
          p.children.props.onClick({ stopPropagation: function () {}, preventDefault: function () {} });
      }
    };

    var parse = function (n) {
      var img = n.querySelector("img"), m = "Unknown";
      if (img) {
        if (img.alt && img.alt.indexOf("logo") === -1) m = img.alt;
        else if (img.src && img.src.indexOf("domain=") > -1) {
          try { m = new URL(img.src).searchParams.get("domain").split(".").slice(0, -1).join(" "); } catch (e) {}
        }
      }
      m = m.charAt(0).toUpperCase() + m.slice(1);
      var rawTxt = n.innerText || n.textContent || "";
      var vEl = n.querySelector('[style*="color: rgb(37, 129, 14)"]');
      if (!vEl) {
        var cands = Array.from(n.querySelectorAll(".font-semibold"));
        vEl = cands.find(function (el) {
          var t = el.innerText.toLowerCase();
          return t.indexOf("miles") > -1 || t.indexOf("points") > -1 || t.indexOf("back") > -1 || t.indexOf("spend") > -1;
        });
      }
      var vStr = vEl ? vEl.innerText : rawTxt;
      var reS = /Spend\s*\$([\d,]+).*?(?:earn|get)\s*([\d,]+)/is,
          reM = /([\d,.]+)\s*(X|%)/i,
          reMi = /(?:Up to\s*)?([\d,.]+)\s*(?:miles|points|cash)/i;
      if (!vEl) {
        var lines = rawTxt.split("\n");
        vStr = lines.find(function (l) { return reM.test(l) || reMi.test(l) || reS.test(l); }) || "Check Offer";
      }
      var type = "OTHER", num = 0, clean = vStr.replace(/\n/g, " ").trim(), ma;
      if (reS.test(vStr)) { type = "SPEND_GET"; ma = vStr.match(reS); if (ma) num = parseFloat(ma[2].replace(/,/g, "")); }
      else if (reM.test(vStr)) { type = "MULTI"; ma = vStr.match(reM); if (ma) num = parseFloat(ma[1].replace(/,/g, "")); }
      else if (reMi.test(vStr)) { type = "MILES"; ma = vStr.match(reMi); if (ma) num = parseFloat(ma[1].replace(/,/g, ""));
        if (rawTxt.toLowerCase().indexOf("up to") > -1 && clean.toLowerCase().indexOf("up to") === -1) clean = "Up to " + clean; }
      var ch = "Online";
      if (rawTxt.toLowerCase().indexOf("in-store") > -1) ch = "In-Store";
      if (rawTxt.toLowerCase().indexOf("in-store") > -1 && (rawTxt.toLowerCase().indexOf("online") > -1 || rawTxt.toLowerCase().indexOf("web") > -1)) ch = "Both";
      var badgeEl = n.querySelector(".absolute.-top-\\[5px\\]"), badge = "";
      if (badgeEl) {
        var bTxt = badgeEl.innerText.toLowerCase();
        if (bTxt.indexOf("new") > -1) badge = "NEW";
        else if (bTxt.indexOf("exclusive") > -1) badge = "EXCLUSIVE";
        else if (bTxt.indexOf("bonus") > -1) badge = "BONUS";
      }
      var sig = m.toLowerCase() + "_" + clean.replace(/[^a-z0-9]/gi, "");
      if (!n.dataset.sid) n.dataset.sid = "o-" + Math.random().toString(36).substr(2, 9);
      // Best-effort expiry. Capital One tiles usually DON'T surface one, so this
      // only fires on an explicit "Expires / Ends / Valid through M/D/YY" phrase
      // — that keyword guard keeps a stray date elsewhere in the tile (e.g. a
      // "since 2019" footnote) from being mistaken for an expiry. No keyword ⇒
      // exp stays null and saveOffer's omit-empty guard drops it cleanly.
      var expM = rawTxt.match(/(?:expires?|ends?|valid (?:through|thru|until))\s*:?\s*(\d{1,2}\/\d{1,2}\/\d{2,4})/i);
      var exp = expM ? parseExpiresTs(expM[1]) : null;
      return { id: n.dataset.sid, sig: sig, m: m, v: clean, t: type, n: num, c: ch, r: rawTxt.toLowerCase(), b: badge, exp: exp, el: n };
    };

    var getRoot = function () { return document.getElementById("c1-scraper-root"); };
    var minimizeUI = function () { var r = getRoot(); if (r) r.classList.add("minimized"); st.uiMinimized = true; };
    var maximizeUI = function () { var r = getRoot(); if (r) r.classList.remove("minimized"); st.uiMinimized = false; };

    var scrape = function () {
      document.querySelectorAll('div[class*="tile"], div[data-testid^="feed-tile"], div.standard-tile').forEach(function (n) {
        var d = parse(n);
        if (d.v && d.v !== "Check Offer") {
          if (st.offers.has(d.sig)) {
            var ex = st.offers.get(d.sig);
            if (d.c === "Both" || (d.c === "In-Store" && ex.c === "Online") || (d.c === "Online" && ex.c === "In-Store")) ex.c = "Both";
          } else {
            st.offers.set(d.sig, d);
            saveOffer(
              "cap1_" + c1Card.cardId + "_" + d.m.replace(/\W/g, ""),
              d.m, d.v, "Capital One",
              {
                channel: d.c, badge: d.b, status: "available",
                card: c1Card.label, cardId: c1Card.cardId,
                expiresTs: d.exp,
                days: d.exp ? ("Expires " + new Date(d.exp).toLocaleDateString()) : ""
              }
            );
          }
        }
      });
      render(); upStats();
    };

    var render = function () {
      var b = document.getElementById("c1-tbody"); if (!b) return;
      var i = Array.from(st.offers.values());
      if (st.search) i = i.filter(function (o) {
        return o.m.toLowerCase().indexOf(st.search.toLowerCase()) > -1
            || o.r.indexOf(st.search.toLowerCase()) > -1
            || o.b.toLowerCase().indexOf(st.search.toLowerCase()) > -1;
      });
      if (!st.activeFilters.has("ALL")) i = i.filter(function (o) { return o.b && st.activeFilters.has(o.b); });
      var rank = function (t) {
        var order = { MILES: ["MILES","MULTI","SPEND_GET"], MULTI: ["MULTI","MILES","SPEND_GET"], SPEND_GET: ["SPEND_GET","MILES","MULTI"] }[st.sortMode];
        if (!order) return 0;
        var idx = order.indexOf(t);
        return idx === -1 ? 3 : idx;
      };
      i.sort(function (a, b) {
        if (st.sortMode === "AZ") return a.m.localeCompare(b.m);
        var ra = rank(a.t), rb = b.t ? rank(b.t) : 9;
        if (ra !== rb) return ra - rb;
        if (st.valSortDir && a.t === b.t) {
          if (st.valSortDir === "DESC") return b.n - a.n;
          if (st.valSortDir === "ASC") return a.n - b.n;
        }
        return a.m.localeCompare(b.m);
      });
      var arrow = st.valSortDir === "DESC" ? " ↓" : st.valSortDir === "ASC" ? " ↑" : "";
      var hv = document.getElementById("th-v");
      if (hv) hv.innerHTML = "Value" + (st.sortMode === "AZ" ? "" : arrow);
      b.innerHTML = i.map(function (o) {
        var bg = o.b === "NEW" ? '<span class="tag-badge ltag-new">NEW</span>'
               : o.b === "EXCLUSIVE" ? '<span class="tag-badge ltag-excl">EXCLUSIVE</span>'
               : o.b === "BONUS" ? '<span class="tag-badge ltag-bonus">BONUS</span>' : "";
        return '<tr onclick="window.c1Clk(\'' + o.id + '\')"><td><b>' + o.m + "</b></td><td class=\"col-val\"><div class=\"val-container\">" + bg + "<span>" + o.v + "</span></div></td><td class=\"col-chan\">" + o.c + "</td></tr>";
      }).join("");
    };

    var upStats = function () {
      var a = Array.from(st.offers.values());
      document.getElementById("st-t").innerText = a.length;
      document.getElementById("st-m").innerText = a.filter(function (x) { return x.t === "MILES"; }).length;
      document.getElementById("st-x").innerText = a.filter(function (x) { return x.t === "MULTI"; }).length;
      document.getElementById("st-s").innerText = a.filter(function (x) { return x.t === "SPEND_GET"; }).length;
      document.getElementById("st-o").innerText = a.filter(function (x) { return x.t === "OTHER"; }).length;
      updateLastRun(a.length);
    };

    var loader = async function () {
      // Capital One's offers API is noticeably slower than the other issuers and
      // sometimes rate-limits / hangs on rapid "View More Offers" clicks, which
      // used to make the page look "stuck" and the loader give up early with
      // offers still unloaded. These waits are bumped up so a slow response has
      // time to paint before we click again or decide the list is exhausted.
      var txt = "View More Offers", att = 0, lastCount = 0;
      var CLICK_SETTLE_MS = 700;    // pause before clicking View More (was 500)
      var LOAD_WAIT_MS    = 2600;   // wait after a click for new tiles  (was 1000)
      var SCROLL_WAIT_MS  = 1100;   // wait after a scroll-to-bottom      (was 750)
      var MAX_EMPTY_TICKS = 7;      // consecutive no-button + no-growth ticks before stopping (was 3)
      var sleep = c1Wait;
      while (st.isLoading) {
        scrape();
        var btn = Array.from(document.querySelectorAll("button")).find(function (b) { return b.innerText.indexOf(txt) > -1; });
        if (btn) {
          document.getElementById("c1-ti").innerText = "Loading... (" + st.offers.size + ")";
          btn.scrollIntoView({ block: "center" });
          await sleep(CLICK_SETTLE_MS);
          await reactClick(btn);
          await sleep(LOAD_WAIT_MS);
          att = 0;
        } else {
          // No "View More" button this tick — could be genuinely the end, or the
          // button is briefly swapped for a loading spinner while a slow API call
          // is in flight. Scroll (some offers lazy-load on scroll) and wait. Only
          // count this as an "empty" tick if NOTHING new appeared; if the offer
          // count is still growing we keep going regardless of the button.
          document.getElementById("c1-ti").innerText = "Loading... (" + st.offers.size + ")";
          window.scrollTo(0, document.body.scrollHeight);
          await sleep(SCROLL_WAIT_MS);
          scrape();
          if (st.offers.size > lastCount) att = 0; else att++;
          if (att > MAX_EMPTY_TICKS) { st.isLoading = false; document.getElementById("c1-ti").innerText = "Done (" + st.offers.size + ")"; }
        }
        lastCount = st.offers.size;
      }
      finished("Capital One", "Done (" + st.offers.size + ")", { added: 0, saved: st.offers.size, history: 0 });
    };

    var exportCSV = function () {
      if (st.offers.size === 0) { alert("No data to export"); return; }
      var h = ["Merchant","Value","Type","Channel","Badge"];
      var rows = [h.join(",")];
      st.offers.forEach(function (o) {
        var f = [o.m, o.v, o.t, o.c, o.b].map(function (x) { return '"' + String(x || "").replace(/"/g, '""') + '"'; });
        rows.push(f.join(","));
      });
      var blob = new Blob(["﻿" + rows.join("\n")], { type: "text/csv;charset=utf-8" });
      var u = URL.createObjectURL(blob);
      var a = document.createElement("a");
      a.href = u; a.download = "capitalone_offers.csv"; a.style.display = "none";
      document.body.appendChild(a); a.dispatchEvent(new MouseEvent("click"));
      setTimeout(function () { document.body.removeChild(a); URL.revokeObjectURL(u); }, 200);
    };

    window.c1Clk = function (id) {
      var el = document.querySelector('[data-sid="' + id + '"]');
      if (el) { reactClick(el); minimizeUI(); } else { alert("Offer element lost. Try scrolling to it."); }
    };
    window.c1Sort = function (m) {
      st.sortMode = m;
      document.querySelectorAll(".c1-sort-btn").forEach(function (b) { b.classList.toggle("active", b.dataset.m === m); });
      render();
    };
    window.c1ValSort = function () {
      st.valSortDir = st.valSortDir === null ? "DESC" : st.valSortDir === "DESC" ? "ASC" : null;
      render();
    };
    window.c1ToggleFilter = function (fid) {
      if (fid === "ALL") { st.activeFilters.clear(); st.activeFilters.add("ALL"); }
      else {
        st.activeFilters.delete("ALL");
        st.activeFilters.has(fid) ? st.activeFilters.delete(fid) : st.activeFilters.add(fid);
        if (st.activeFilters.size === 0) st.activeFilters.add("ALL");
      }
      document.querySelectorAll(".c1-chip").forEach(function (c) { c.classList.toggle("active", st.activeFilters.has(c.dataset.fid)); });
      render();
    };

    var initC1 = function () {
      var old = document.getElementById("c1-scraper-root"); if (old) old.remove();
      var root = el("div", { id: "c1-scraper-root" });
      c1Root = root;
      var h = el("div", { class: "c1-header" }, [
        el("span", { id: "c1-ti", style: "font-weight:bold" }, ["Capital One Sorter"]),
        el("div", { class: "c1-controls" }, [
          el("button", { class: "c1-btn-icon", onclick: function () { minimizeUI(); } }, ["_"]),
          el("button", { class: "c1-btn-icon", onclick: function () { root.remove(); st.isLoading = false; } }, ["X"])
        ])
      ]);
      root.appendChild(el("div", { class: "min-label", onclick: function () { maximizeUI(); } }, ["CapitalOne Offers"]));
      var sBox = el("div", { class: "c1-stats" });
      sBox.innerHTML = '<span class="c1-stat-item">Total: <b id="st-t">0</b></span> <span class="c1-stat-item">Miles: <b id="st-m">0</b></span> <span class="c1-stat-item">% / X: <b id="st-x">0</b></span> <span class="c1-stat-item">Spend/Get: <b id="st-s">0</b></span> <span class="c1-stat-item">Other: <b id="st-o">0</b></span>';
      var tb = el("div", { class: "c1-toolbar" });
      var topRow = el("div", { style: "display:flex;gap:8px;align-items:center" }, [
        el("input", { class: "c1-search", style: "flex-grow:1", placeholder: "Search merchant...", oninput: function (e) { st.search = e.target.value; render(); } }),
        el("button", { class: "c1-export-btn", onclick: function () { exportCSV(); } }, ["Export CSV"])
      ]);
      var fg = el("div", { class: "c1-filter-group" });
      FILTERS.forEach(function (f) {
        var cls = "c1-chip";
        if (f.id === "ALL") cls += " active";
        if (f.id === "NEW") cls += " tag-new";
        if (f.id === "EXCLUSIVE") cls += " tag-excl";
        if (f.id === "BONUS") cls += " tag-bonus";
        fg.appendChild(el("div", { class: cls, "data-fid": f.id, onclick: function () { window.c1ToggleFilter(f.id); } }, [f.label]));
      });
      var sg = el("div", { class: "c1-sort-group" });
      [{ l: "Miles", m: "MILES" }, { l: "% / X", m: "MULTI" }, { l: "Spend/Get", m: "SPEND_GET" }, { l: "A-Z", m: "AZ" }].forEach(function (o, i) {
        sg.appendChild(el("button", { class: "c1-sort-btn " + (i === 0 ? "active" : ""), "data-m": o.m, onclick: function () { window.c1Sort(o.m); } }, [o.l]));
      });
      tb.appendChild(topRow); tb.appendChild(fg); tb.appendChild(sg);
      var tw = el("div", { class: "c1-table-wrapper" });
      tw.innerHTML = '<table><thead><tr><th width="40%">Merchant</th><th width="40%" id="th-v" onclick="window.c1ValSort()">Value</th><th width="20%">Channel</th></tr></thead><tbody id="c1-tbody"></tbody></table>';
      root.appendChild(h); root.appendChild(sBox); root.appendChild(tb); root.appendChild(tw);
      document.body.appendChild(root);
      var d = false, sx, sy, ix, iy;
      h.onmousedown = function (e) {
        if (e.target.tagName === "BUTTON") return;
        d = true; sx = e.clientX; sy = e.clientY; ix = root.offsetLeft; iy = root.offsetTop; root.style.right = "auto";
      };
      document.onmousemove = function (e) { if (!d) return; root.style.left = (ix + e.clientX - sx) + "px"; root.style.top = (iy + e.clientY - sy) + "px"; };
      document.onmouseup = function () { d = false; };
      loader();
    };
    initC1();
    return;
  }

  /* ============================================================ */
  /*                    CAPITAL ONE SHOPPING                      */
  /* ============================================================ */
  //
  // capitaloneshopping.com is Capital One's shopping rewards site, separate
  // from the card offers on capitaloneoffers.com above. Its offers are store
  // rates ("2% back", "Up to $150 back") with nothing to clip or add, so this
  // autopilot presses nothing: it reads the offers on the page, scrolling
  // down for the minutes picked beside Run while the site adds more, and
  // saves one entry per store.
  //
  // The home page (Nov 2026), read by its test attributes and wording, not
  // by class names:
  //   - offer tiles: data-test-merchant-name="Walmart" and
  //     data-test-category-name ("Rewards Offers", "Exclusive Deals",
  //     "Events", "Today's Featured Offers", "Price Drops"...). The reward is
  //     a green "+ 2% back" line; an event tile has none and puts it in its
  //     title, "Now 11% back ($1,000 Max)", with "Exclusive rates for next
  //     1 day" beside its button. Every carousel's tiles are in the page.
  //   - Today's Top Offers: buttons with aria-label="View <store> offer - Earn 25% back".
  //   - left out: mobile game bonuses ("Mobile Game Offers"), event banners
  //     (no store, they open a list of stores), the referral card and the
  //     strip of upcoming offers (no reward).
  //
  // A store often shows up more than once. Its best rate without an end date
  // is saved as "c1s_<store>"; a rate with an end date goes under
  // "c1s_<store>_event", and only when it beats that one or the store has
  // none. A saved end date is never cleared by a later save (the hub keeps
  // expiries, lib/offers.js normalizeRecord), so it mustn't sit on the
  // store's regular entry. Saving waits until the page is read, so a store
  // seen on an event tile first and a regular tile later isn't saved twice.
  if (host.indexOf("capitaloneshopping.com") > -1) {
    // How long this run reads: the minutes picked beside Run in the popup
    // (popup.js, background.js and auto-load's lib/autorun.js set
    // window.__uohRunMinutes right before they inject this file), else 5,
    // the default in lib/sources.js.
    var c1sAsked = +window.__uohRunMinutes;
    try { delete window.__uohRunMinutes; } catch (e) {}
    if (window.__uohC1sRunning) return;
    var oldC1s = document.getElementById("c1s-autopilot-ui");
    if (oldC1s) oldC1s.remove();
    window.__uohC1sRunning = true;

    var C1S_SITE = "Capital One Shopping";
    // Nothing of the run goes on the page, not even its panel: with anything
    // of ours on the page, the site stops adding offers within a minute or
    // two (a request fails and the page treats that as the end). On Jay's
    // page, Nov 2026, runs with the panel ended after 88 to 598 offers; the
    // same run without it read to the page's own end, 1,020. The panel shows
    // in Chrome's side panel instead (sidepanel/run.html), from the progress
    // this run sends (c1sShow), with Stop and save.

    var cText = function (el) { return el ? String(el.textContent || "").replace(/\s+/g, " ").trim() : ""; };
    // A tile's lines inside its hover notes ("Rewards by Categories",
    // "Exclusions Apply"), which stay in the page with visibility:hidden.
    var c1sInTip = function (el, tile) {
      for (var n = el; n && n !== tile; n = n.parentElement) {
        if (/visibility/i.test(n.getAttribute("style") || "")) return true;
      }
      return false;
    };
    var c1sGreen = function (el) {
      var m = String(getComputedStyle(el).color || "").match(/(\d+),\s*(\d+),\s*(\d+)/);
      return !!m && +m[2] >= 90 && +m[2] > 1.5 * +m[1] && +m[2] > 1.5 * +m[3];
    };
    // "+ 2% back", "earn up to 1% back", "Now up to $150 back ($1,000 Max)", "25% back".
    // It must start the line, so "Up to 70% off sale styles" doesn't count.
    var C1S_REWARD = /^(?:\+\s*)?(?:now\s+|earn\s+)?(?:up\s+to\s+)?(?:\$\s?\d[\d,]*(?:\.\d+)?|\d+(?:\.\d+)?\s*%)\s+back\b/i;
    var c1sValue = function (t) {
      var s = String(t || "").replace(/\s+/g, " ")
        .replace(/\(\s*\$1,000\s+max\s*\)/i, "") // on every offer; any other cap stays
        .trim().replace(/^\+\s*/, "").replace(/^(?:now|earn)\s+/i, "").trim();
      return s.charAt(0).toUpperCase() + s.slice(1);
    };
    // The tile's reward: a green line saying "... back", else the first line
    // that starts that way (an event tile's title). A regular tile puts its
    // cap beside the green line ("<green>+ 2% back</green> ($1,000 max)").
    var c1sReward = function (tile) {
      var lines = Array.prototype.filter.call(tile.querySelectorAll("p, span"), function (e) {
        return C1S_REWARD.test(cText(e)) && !c1sInTip(e, tile);
      });
      var line = lines.filter(c1sGreen)[0] || lines[0];
      if (line) {
        var v = c1sValue(cText(line)), up = line.parentElement;
        var cap = !/\bmax\b/i.test(v) && up && up !== tile ? cText(up).match(/\(\s*\$\s?[\d,]+(?:\.\d+)?\s+max\s*\)/i) : null;
        return cap ? c1sValue(v + " " + cap[0]) : v;
      }
      var a = (tile.getAttribute("aria-label") || "").match(/\boffer\s+-\s+(.+)$/i);
      return a && C1S_REWARD.test(a[1].trim()) ? c1sValue(a[1]) : "";
    };
    var c1sMerchant = function (tile) {
      var m = tile.getAttribute("data-test-merchant-name") || cText(tile.querySelector('[data-testid="deal-item-merchant-name"]'));
      if (!m) {
        var a = (tile.getAttribute("aria-label") || "").match(/^View\s+(.+?)\s+offer\s+-/i);
        if (a) m = a[1];
      }
      if (!m) {
        var img = tile.querySelector('img[alt^="Merchant image for "]');
        if (img) m = img.getAttribute("alt").replace(/^Merchant image for\s+/, "");
      }
      return String(m || "").replace(/\s+/g, " ").trim();
    };
    // The store's own site, from its logo's address (".../logos?domain=walmart.com").
    var c1sDomain = function (tile) {
      var imgs = tile.querySelectorAll("img");
      for (var i = 0; i < imgs.length; i++) {
        try {
          var d = new URL(imgs[i].getAttribute("src") || "", location.href).searchParams.get("domain");
          if (d) return d.toLowerCase();
        } catch (e) {}
      }
      return "";
    };
    // The label in the tile's corner ("Exclusive Deal", "Limited Time Event"),
    // without its hover note.
    var c1sBadge = function (tile) {
      if (tile.tagName === "BUTTON") return "Top Offer";
      var pill = tile.querySelector('[class*="CornerPill"]');
      return pill ? cText(pill.querySelector("p") || pill).slice(0, 40) : "";
    };
    // "Exclusive rates for next 1 day" -> the end of tomorrow. Hours and
    // minutes end today (or the day they run into); "ends today/tomorrow" too.
    var C1S_ENDS = /\bnext\s+(\d+)\s*(minutes?|mins?|hours?|hrs?|days?)\b|\bends?\s+(today|tonight|tomorrow)\b/i;
    var c1sTimer = function (tile) {
      var lines = [tile.querySelector('[class*="Timer"]')].concat(Array.prototype.slice.call(tile.querySelectorAll("p, span")));
      for (var i = 0; i < lines.length; i++) {
        var t = cText(lines[i]);
        if (!t || t.length > 60 || c1sInTip(lines[i], tile)) continue;
        if ((i === 0 || /\brates?\b/i.test(t)) && C1S_ENDS.test(t)) return t;
      }
      return "";
    };
    var c1sEnds = function (t, now) {
      var m = String(t).match(C1S_ENDS);
      if (!m) return null;
      var d = new Date(now);
      if (m[1]) {
        var n = parseInt(m[1], 10), unit = m[2].charAt(0).toLowerCase();
        if (unit === "d") d.setDate(d.getDate() + n);
        else d = new Date(now + n * (unit === "h" ? 3600000 : 60000));
      } else if (m[3].toLowerCase() === "tomorrow") {
        d.setDate(d.getDate() + 1);
      }
      d.setHours(23, 59, 59, 999);
      return d.getTime();
    };
    var c1sTiles = function () {
      var out = [], seen = new Set();
      var add = function (t) { if (t && !seen.has(t)) { seen.add(t); out.push(t); } };
      document.querySelectorAll("[data-test-merchant-name]").forEach(add);
      document.querySelectorAll('[data-testid="deal-item-merchant-name"]').forEach(function (n) {
        add(n.closest('[data-test-merchant-name], [role="button"], .deal-list-item'));
      });
      document.querySelectorAll("button[aria-label]").forEach(function (b) {
        if (/^View\s+.+?\s+offer\s+-\s+/i.test(b.getAttribute("aria-label")) && !b.closest("[data-test-merchant-name]")) add(b);
      });
      // In page order, so "the first one seen" is the one higher on the page.
      return out.sort(function (a, b) { return a.compareDocumentPosition(b) & Node.DOCUMENT_POSITION_FOLLOWING ? -1 : 1; });
    };
    // The offer's own words: its heading ("Save at Walmart", "Up to 30% off
    // your purchase"), an event's name, or a Top Offer's line under its
    // reward. Not the store's name, the reward itself or a hover note.
    var c1sTitle = function (tile, m, v) {
      var lines = tile.tagName === "BUTTON" ? Array.prototype.slice.call(tile.querySelectorAll("p")).reverse()
                                            : tile.querySelectorAll('p[class*="font-semibold"], [class*="EventInfo"] span');
      for (var i = 0; i < lines.length; i++) {
        var t = cText(lines[i]);
        if (!t || c1sInTip(lines[i], tile) || t === m || /^•/.test(t) || c1sValue(t) === v) continue;
        if (tile.tagName === "BUTTON" && /^[A-Z0-9 &'’-]+$/.test(t)) continue; // its category, in capitals
        return t.slice(0, 160);
      }
      return "";
    };
    // The offer's own link: the site's redirect (/api/v3/r?d=...&t=...) that
    // a click on the tile opens, from the props React gave the tile.
    var c1sLink = function (tile) {
      var k = Object.keys(tile).filter(function (x) { return x.indexOf("__reactFiber$") === 0; })[0];
      for (var f = k ? tile[k] : null, d = 0; f && d < 12; d++, f = f.return) {
        var p = f.memoizedProps;
        if (!p || typeof p !== "object" || typeof p.href !== "string" || !p.href) continue;
        try {
          var u = new URL(p.href, location.origin);
          return u.pathname === "/api/v3/r" ? u.href : "";
        } catch (e) { return ""; }
      }
      return "";
    };
    // A product (a Price Drop, Back In Stock): its rate is the store's, but
    // the product itself isn't saved.
    var C1S_PRODUCT = /price drop|back in stock|products? you viewed|product/i;
    var c1sParse = function (tile, now) {
      var cat = tile.getAttribute("data-test-category-name") || "";
      if (/mobile game/i.test(cat)) return null;
      var m = c1sMerchant(tile);
      if (!m) return null; // an event banner: no store
      var v = c1sReward(tile);
      if (!v) return { m: m };
      var timer = c1sTimer(tile), ends = timer ? c1sEnds(timer, now) : null, p = parseValue(v), product = C1S_PRODUCT.test(cat);
      return { m: m, v: v, n: p.num, t: p.type, badge: c1sBadge(tile), domain: c1sDomain(tile),
               timer: ends == null ? "" : timer, ends: ends, product: product,
               title: product ? "" : c1sTitle(tile, m, v), link: product ? "" : c1sLink(tile) };
    };

    // tiles: the most seen at once; grewAt: when the page last gained one (or
    // showed a batch on its way), for the waits; addedAt and grew: the page
    // adding tiles after the first look; hidden: ms in a background tab.
    var c1sT0 = Date.now();
    var cst = { rates: {}, bad: {}, domains: {}, parsed: new WeakSet(), done: false,
                t0: c1sT0, runMs: (c1sAsked > 0 ? Math.min(c1sAsked, 120) : 5) * 60000, tickAt: c1sT0,
                tiles: 0, grewAt: c1sT0, addedAt: 0, grew: 0, looks: 0, look: [], upTo: null, restUntil: 0, sawMark: false, emptyFrom: c1sT0, askedAt: 0, wasLoading: false,
                hidden: 0, hiddenAt: null, y0: window.scrollY };
    // Every rate a store shows, once: by store and reward ("2% back" and "4%
    // back" are two). A rate also shown without an end date has none; one
    // shown only with end dates keeps the latest. The first tile seen gives
    // the rate its label, and its words and link when it has them, but a
    // store's own tile beats a product's.
    var c1sAdd = function (mk, d) {
      var rates = cst.rates[mk] || (cst.rates[mk] = {}), id = d.v.toLowerCase(), r = rates[id];
      if (!r) { rates[id] = d; return; }
      var keep = r.product && !d.product ? d : r, other = keep === r ? d : r;
      var open = r.ends == null || d.ends == null, ends = open ? null : Math.max(r.ends, d.ends);
      rates[id] = Object.assign({}, keep, {
        title: keep.title || other.title, link: keep.link || other.link,
        ends: ends, timer: open ? "" : ends === r.ends ? r.timer : d.timer
      });
    };
    // Reads the tiles on the page; returns them all, in page order. A tile
    // whose reward was read isn't read again (a long run sees thousands).
    var c1sScan = function () {
      var now = Date.now(), tiles = c1sTiles();
      tiles.forEach(function (tile) {
        if (cst.parsed.has(tile)) return;
        try {
          var d = c1sParse(tile, now);
          if (!d) return;
          var mk = d.m.replace(/\W/g, "");
          if (!mk) return;
          if (!d.v) { cst.bad[mk] = d.m; return; }
          cst.parsed.add(tile);
          // A Top Offer button has no logo address; another tile of the store may.
          if (d.domain && !cst.domains[mk]) cst.domains[mk] = d.domain;
          c1sAdd(mk, d);
        } catch (e) {}
      });
      return tiles;
    };
    // One entry per store and rate: "c1s_<store>__<rate>", with "__event"
    // for a rate shown only with an end date (a saved end date is never
    // cleared, lib/offers.js normalizeRecord, so it keeps a key of its own).
    var c1sSlug = function (v) {
      return v.toLowerCase().replace(/%/g, "pct").replace(/\$/g, "usd").replace(/[^a-z0-9.]+/g, "").replace(/\./g, "_");
    };
    var c1sPlan = function () {
      var out = [];
      Object.keys(cst.rates).forEach(function (mk) {
        Object.keys(cst.rates[mk]).forEach(function (id) {
          var d = cst.rates[mk][id];
          out.push({ key: "c1s_" + mk + "__" + c1sSlug(d.v) + (d.ends == null ? "" : "__event"), mk: mk, d: d });
        });
      });
      return out;
    };
    var c1sUnread = function () {
      return Object.keys(cst.bad).filter(function (mk) { return !cst.rates[mk]; }).length;
    };
    // How the run is going, for the side panel, the popup and the toolbar
    // badge (content/bridge.js passes it to background.js): every second at
    // most, and when it's done. tone "warn" or "error" colors the status.
    var c1sTold = 0;
    var c1sShow = function (status, tone, done) {
      var now = Date.now();
      if (!done && now - c1sTold < 1000) return;
      c1sTold = now;
      var plan = c1sPlan();
      try {
        window.postMessage({ __uoh: true, type: "RUN_PROGRESS", site: C1S_SITE, status: status, tone: tone || "ok", done: !!done,
                             read: plan.length, stores: Object.keys(cst.rates).length,
                             timed: plan.filter(function (r) { return r.d.ends != null; }).length, bad: c1sUnread(),
                             endsAt: cst.t0 + cst.runMs }, "*");
      } catch (e) {}
    };
    // Stop and save, from the side panel or the popup (content/bridge.js
    // passes it on).
    var c1sStop = function (e) {
      var d = e.data;
      if (e.source === window && d && d.__uoh === true && d.type === "STOP_RUN") c1sFinish();
    };
    window.addEventListener("message", c1sStop);

    var cloop = null;
    // why: "time" when the run's minutes ran out, "end" when the site had no
    // more offers to add; else Stop was pressed or the page had nothing to
    // read.
    var c1sFinish = function (why) {
      if (cst.done) return;
      cst.done = true;
      stopEvery(cloop);
      c1sSeen();
      document.removeEventListener("visibilitychange", c1sSeen);
      window.removeEventListener("message", c1sStop);
      window.__uohC1sRunning = false;
      var plan = c1sPlan(), unread = c1sUnread();
      var timed = plan.filter(function (r) { return r.d.ends != null; }).length;
      plan.forEach(function (r) {
        var d = r.d;
        saveOffer(r.key, d.m, d.v, C1S_SITE, {
          status: "available", badge: d.badge, domain: cst.domains[r.mk] || "", title: d.title || "", link: d.link || "",
          expiresTs: d.ends, days: d.timer,
          // The store's keys from when the hub kept one rate per store.
          replaces: ["c1s_" + r.mk, "c1s_" + r.mk + "_event"]
        });
      });
      updateLastRun(plan.length);
      var note, error = "";
      if (!plan.length && !unread) {
        note = "No offers on this page. Open capitaloneshopping.com (its home page) and press Run again.";
        c1sShow(note, "warn", true);
      } else if (!plan.length) {
        error = "Couldn't read the reward on any of the " + unread + " offers on this page.";
        note = error + " Capital One Shopping may have changed its page.";
        c1sShow(note, "error", true);
      } else {
        note = "Done. " + plan.length + (plan.length === 1 ? " offer" : " offers") + " saved" +
               (timed ? " (" + timed + " with an end date)" : "") + "." + (unread ? " " + unread + " couldn't be read." : "");
        // Whether more minutes would find more: offers arrived in the run's
        // last seconds, or a batch was on its way.
        if (why === "time" && ((cst.grew && Date.now() - cst.addedAt < C1S_FRESH) || c1sLoading())) {
          note += " The page was still adding offers when the " + c1sSpan(cst.runMs) + " ran out. Choose more minutes beside Run to read more.";
        }
        if (why === "end") note += " The page had no more offers to add.";
        if (cst.hidden >= 30000 && !autoTicks) note += " The tab was in the background for " + c1sSpan(cst.hidden) + ", and offers load only while it's in front.";
        if (unread) error = "Couldn't read the reward on " + unread + " of the " + (unread + Object.keys(cst.rates).length) + " stores.";
        c1sShow(note, "ok", true);
      }
      finished(C1S_SITE, note, { added: 0, saved: plan.length, history: 0 }, error);
      try { window.scrollTo(0, cst.y0); } catch (e) {}
    };

    // Read the page as a person reads a feed: scroll quickly to where the
    // offers end, not to the bottom of the page (the "Popular Brands" list
    // and the footer are below them), wait there while the next batch loads,
    // and pause a moment once it's in before scrolling on. The site (Nov
    // 2026) loads its next batch, 25 offers, when a mark ten offers before
    // the end scrolls into view or is scrolled past: a react-waypoint, which
    // does nothing while a batch is on its way (data-testid=
    // "next-page-spinner" shows then, about 2 s). Each batch goes after the
    // last offer, so the run reads it, scrolls on to the new end and passes
    // the new mark on the way. A run that waits below the offers never sees
    // the mark again, since each batch lands above it. The rhythm: as soon as
    // a batch is in, a quick swipe down, to just above the next mark until
    // C1S_SPACING_MS has passed since the page last asked for a batch, then
    // on to the end, which asks for the next; wait while the spinner shows.
    // When nothing comes for a while, it looks around as a person would, at
    // most twice: down to the bottom of the page, back up until the last 11
    // offers are below the screen, and down to the end again. It reads for
    // the minutes picked beside Run (cst.runMs); Stop and save in the side
    // panel or the popup ends it sooner.
    // C1S_SPACING_MS: the most often a run lets the page ask for a batch. On
    // Jay's page a run that asked every 2.5 s was cut off at 398 offers; one
    // asking every 4 s read to the page's own end (981, 1,020).
    var C1S_HOLD = 0.8, C1S_SWIPE_MS = 300, C1S_MOVE_MS = 400, C1S_SETTLE_MS = 300, C1S_SPACING_MS = 3800,
        C1S_LOOKS = [5000, 20000], C1S_FRESH = 15000, C1S_EMPTY = 15000;
    var c1sLoading = function () { return !!document.querySelector('[data-testid="next-page-spinner"]'); };
    var c1sPage = function () { return Math.max(document.body.scrollHeight, document.documentElement.scrollHeight); };
    // The list the last offer sits in (the feed: the first box up from it
    // with 10 or more children), or null.
    var c1sList = function (tiles) {
      for (var n = tiles[tiles.length - 1]; n && n.parentElement; n = n.parentElement) {
        if (n.parentElement.childElementCount >= 10) return n.parentElement;
      }
      return null;
    };
    // Where the offers end on screen, in px from the window's top: the bottom
    // of the list's last item (often an ad or the referral card, which a
    // person scrolls to as well), else the lowest of the last few tiles in
    // page order; null when there are none.
    var c1sEnd = function (tiles, list) {
      if (list && list.lastElementChild) return list.lastElementChild.getBoundingClientRect().bottom;
      var end = null;
      for (var i = Math.max(0, tiles.length - 8); i < tiles.length; i++) {
        var r = tiles[i].getBoundingClientRect();
        if (r.height && (end == null || r.bottom > end)) end = r.bottom;
      }
      return end;
    };
    // The site's load mark in the list (react-waypoint's empty <span
    // style="font-size: 0px">, a child of the list itself), or null. The site
    // drops it once it has no more offers to add, or a request for them
    // failed: either way the page adds no more.
    var c1sMark = function (list) {
      for (var c = list ? list.firstElementChild : null; c; c = c.nextElementSibling) {
        if (c.tagName === "SPAN" && /font-size:\s*0/.test(c.getAttribute("style") || "")) return c;
      }
      return null;
    };
    // A quick swipe: the page moves dy px in C1S_SWIPE_MS, easing out like a
    // flick, a frame at a time (small moves, so the page's own adjustments
    // when a batch lands still work), then rests C1S_MOVE_MS. Timed from its
    // first frame: a frame's time can be a little before the swipe began,
    // which made the first step go the wrong way. In auto-load's background
    // tab (autoTicks) no frames come and the page sends itself no scroll
    // events, so the move is made at once and the scroll event sent with it:
    // the site's load mark listens for those. That loads its batches there
    // too (Nov 2026, a hidden tab: 76 to 401 offers in 65 s).
    var c1sSwipe = null;
    var c1sGo = function (dy) {
      cst.restUntil = Date.now() + C1S_SWIPE_MS + C1S_MOVE_MS;
      if (autoTicks) {
        window.scrollBy({ top: dy, behavior: "instant" });
        window.dispatchEvent(new Event("scroll"));
        return;
      }
      var t0 = null, done = 0, me = c1sSwipe = {};
      var frame = function (t) {
        if (c1sSwipe !== me || cst.done) return;
        if (t0 == null) t0 = t;
        var p = Math.max(0, Math.min(1, (t - t0) / C1S_SWIPE_MS)), want = Math.round(dy * (1 - Math.pow(1 - p, 3)));
        if (want !== done) { window.scrollBy({ top: want - done, behavior: "instant" }); done = want; }
        if (p < 1) requestAnimationFrame(frame); else c1sSwipe = null;
      };
      requestAnimationFrame(frame);
    };
    var c1sClock = function (ms) {
      var s = Math.max(0, Math.ceil(ms / 1000));
      return Math.floor(s / 60) + ":" + ("0" + (s % 60)).slice(-2);
    };
    var c1sSpan = function (ms) {
      if (ms < 60000) { var s = Math.round(ms / 1000); return s + (s === 1 ? " second" : " seconds"); }
      var m = Math.round(ms / 6000) / 10;
      return m + (m === 1 ? " minute" : " minutes");
    };
    // Time in a background tab, where the page loads nothing.
    var c1sSeen = function () {
      var now = Date.now();
      if (cst.hiddenAt != null) { cst.hidden += now - cst.hiddenAt; cst.hiddenAt = null; }
      if (document.hidden && !cst.done) cst.hiddenAt = now;
    };
    document.addEventListener("visibilitychange", c1sSeen);
    c1sSeen();

    cloop = every(250, function () {
      if (cst.done) return;
      var tiles = c1sScan(), now = Date.now(), since = now - cst.tickAt;
      cst.tickAt = now;
      if (tiles.length > cst.tiles) {
        if (cst.tiles) { cst.grew++; cst.addedAt = now; cst.restUntil = Math.max(cst.restUntil, now + C1S_SETTLE_MS); }
        cst.tiles = tiles.length;
        cst.grewAt = now;
        cst.looks = 0;
        cst.look = [];
        cst.upTo = null;
      }
      var left = cst.t0 + cst.runMs - now;
      if (left <= 0) { c1sFinish("time"); return; }
      // Another page of the site, or one that changed: nothing to read. Not
      // while the site still shows a spinner (its offers can take a while).
      if (document.querySelector(".spinner")) cst.emptyFrom = now;
      if (now - cst.emptyFrom >= C1S_EMPTY && !Object.keys(cst.rates).length) { c1sFinish(); return; }
      var clock = " " + c1sClock(left) + " left.";
      // A background tab the user put there loads nothing; auto-load's own
      // tab does (c1sGo).
      if (document.hidden && !autoTicks) {
        cst.grewAt += since; // nothing loads in a background tab, so this wait doesn't count
        c1sShow("Paused while this tab is in the background." + clock);
        return;
      }
      var h = window.innerHeight, list = tiles.length ? c1sList(tiles) : null, end = c1sEnd(tiles, list);
      var atBottom = h + window.scrollY >= c1sPage() - 2;
      var mark = c1sMark(list), marked = !!mark;
      if (marked) cst.sawMark = true;
      // A batch on its way: wait, and a moment more once it's in.
      var loading = c1sLoading();
      if (loading && !cst.wasLoading) cst.askedAt = now;
      cst.wasLoading = loading;
      if (loading) {
        cst.grewAt = now;
        cst.restUntil = now + C1S_SETTLE_MS;
        c1sShow("Loading more offers..." + clock);
        return;
      }
      if (now < cst.restUntil) {
        c1sShow((cst.look.length ? "Looking around the page..." : "Reading offers...") + clock);
        return;
      }
      var quiet = now - cst.grewAt;
      if (cst.look.length) {
        if (cst.look[0] === "down") {
          if (atBottom) cst.look.shift(); else c1sGo(c1sPage() - h - window.scrollY);
        } else {
          if (cst.upTo == null) {
            var t11 = tiles[Math.max(0, tiles.length - 11)];
            cst.upTo = Math.max(0, window.scrollY + (t11 ? t11.getBoundingClientRect().top : 0) - h - 40);
          }
          if (window.scrollY <= cst.upTo + 2) { cst.look.shift(); cst.upTo = null; }
          else c1sGo(cst.upTo - window.scrollY);
        }
        c1sShow("No new offers for " + c1sClock(quiet) + ". Looking around the page..." + clock);
        return;
      }
      if (end == null) {
        if (!atBottom) c1sGo(c1sPage() - h - window.scrollY);
        c1sShow("Reading offers..." + clock);
        return;
      }
      // off > 0: the end of the offers is below its spot on screen.
      var off = end - h * C1S_HOLD;
      if ((off > h * 0.1 && !atBottom) || (off < -h * 0.3 && window.scrollY > 0)) {
        // Scrolling past the mark asks for the next batch. Within
        // C1S_SPACING_MS of the last one, scroll down to just above it.
        var dy = off, below = mark ? mark.getBoundingClientRect().top - h : -1;
        if (dy > 0 && below > 0 && now - cst.askedAt < C1S_SPACING_MS) dy = Math.max(0, Math.min(dy, below - 40));
        if (dy > 4 || dy < -4) c1sGo(dy);
        c1sShow("Reading offers..." + clock);
        return;
      }
      // The site had its load mark and took it away: no more offers to come.
      if (cst.sawMark && !marked && quiet >= C1S_LOOKS[0]) { c1sFinish("end"); return; }
      if (cst.looks < C1S_LOOKS.length && quiet >= C1S_LOOKS[cst.looks]) {
        cst.looks++;
        cst.look = ["down", "up"];
        return;
      }
      c1sShow((quiet < 10000 ? "Waiting for more offers to load..." :
               "No new offers for " + c1sClock(quiet) + ". Waiting for more, or press Stop in the toolbar popup to save now.") + clock);
    });
    return;
  }

  /* ============================================================ */
  /*                         WALGREENS                            */
  /* ============================================================ */
  if (host.indexOf("walgreens.com") > -1) {
    if (document.getElementById("walg-autopilot-ui")) return;
    var wui = document.createElement("div");
    wui.id = "walg-autopilot-ui";
    wui.style.cssText = "position:fixed;bottom:20px;right:20px;width:240px;background:#1c2b36;color:#fff;font-family:sans-serif;font-size:12px;border-radius:8px;box-shadow:0 8px 24px rgba(0,0,0,0.4);z-index:999999;border:1px solid #455a64;overflow:hidden;";
    wui.innerHTML = '<div style="background:#E31837;padding:10px;font-weight:700;display:flex;justify-content:space-between;align-items:center;"><span>Walgreens Autopilot</span><span id="cp-close" style="cursor:pointer;font-size:16px;opacity:0.8;">&times;</span></div><div style="padding:12px;"><div style="margin-bottom:8px;color:#90a4ae;">STATUS</div><div id="cp-status" style="color:#4caf50;font-weight:600;margin-bottom:12px;line-height:1.4;">Starting...</div><div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;text-align:center;"><div style="background:#263238;padding:6px;border-radius:4px;"><div id="cp-seen" style="font-weight:700;font-size:14px;">0</div><div style="font-size:10px;color:#78909c;">Visible</div></div><div style="background:#263238;padding:6px;border-radius:4px;"><div id="cp-queue" style="font-weight:700;font-size:14px;color:#ffb74d;">0</div><div style="font-size:10px;color:#78909c;">Queue</div></div><div style="background:#263238;padding:6px;border-radius:4px;"><div id="cp-added" style="font-weight:700;font-size:14px;color:#4caf50;">0</div><div style="font-size:10px;color:#78909c;">Clipped</div></div><div style="background:#263238;padding:6px;border-radius:4px;"><div id="cp-pre" style="font-weight:700;font-size:14px;color:#90a4ae;">0</div><div style="font-size:10px;color:#78909c;">Pre-Clipped</div></div></div></div>';
    document.body.appendChild(wui);
    var wstate = { clipped: 0, run: true, bottomHits: 0 };
    var setWText = function (id, val) {
      var el = document.getElementById(id);
      if (el) el.innerText = val;
    };
    var wupdate = function (s, t, q, p) {
      if (s) setWText("cp-status", s);
      if (t !== undefined) setWText("cp-seen", t);
      if (q !== undefined) setWText("cp-queue", q);
      setWText("cp-added", wstate.clipped);
      if (p !== undefined) setWText("cp-pre", p);
      updateLastRun(wstate.clipped);
    };
    var wstop = function () { wstate.run = false; clearInterval(wloop); wupdate("Done. Script stopped."); };
    var wloop = setInterval(function () {
      if (!wstate.run) return;
      if (!document.getElementById("walg-autopilot-ui")) { wstop(); return; }
      var allButtons = Array.from(document.querySelectorAll('button[id^="clip"]'));
      var preClipped = document.querySelectorAll(".icon__check").length;
      var queue = allButtons.filter(function (btn) {
        return !btn.hasAttribute("data-walg-processed") && btn.innerText.trim() === "Clip" && btn.offsetParent !== null;
      });
      var total = allButtons.length + preClipped;
      wupdate(queue.length > 0 ? "Clipping..." : "Scrolling for more...", total, queue.length, preClipped);
      if (queue.length > 0) {
        wstate.bottomHits = 0;
        var target = queue[0];
        target.setAttribute("data-walg-processed", "true");
        target.scrollIntoView({ behavior: "auto", block: "center" });
        try {
          var card = target.closest(".wag-do-couponlist-box");
          var merchant = card.querySelector('[id^="brand"] strong').innerText.trim();
          var value = card.querySelector('[id^="summary"] strong').innerText.trim();
          saveOffer("walg_" + merchant.replace(/\W/g, ""), merchant, value, "Walgreens", { status: "clipped" });
        } catch (e) {}
        wstate.clipped++;
        var o3 = { view: window, bubbles: true, cancelable: true };
        target.dispatchEvent(new MouseEvent("mousedown", o3));
        target.dispatchEvent(new MouseEvent("mouseup", o3));
        target.dispatchEvent(new MouseEvent("click", o3));
      } else {
        var max = document.body.scrollHeight;
        var cur = window.innerHeight + window.scrollY;
        if (cur >= max - 100) { wstate.bottomHits++; if (wstate.bottomHits > 3) wstop(); }
        else { wstate.bottomHits = 0; window.scrollBy(0, 500); }
      }
    }, 400);
    document.getElementById("cp-close").onclick = function () { wstop(); wui.remove(); };
    return;
  }

  /* ============================================================ */
  /*                          SAFEWAY                             */
  /* ============================================================ */
  //
  // Safeway for U (Albertsons AEM + Angular SPA). Each clippable offer renders
  // as an Angular <point-reward-card> whose clip control is
  //   <button class="rewards-redeem-button">Clip Coupon</button>
  // (the markup also carries a duplicated id="clipbtn" and
  //  aria-label="Clip coupon for <merchant>"). The SAME button class is reused
  // on the All-deals page, so we never trust the id; we match by class/aria and
  // use the visible label to tell state apart: an actionable coupon reads
  // exactly "Clip Coupon" (or "Clip"), and once clipped Safeway swaps the label
  // to "Clipped". This is a pure scroll-and-click clip loop, same shape as
  // Walgreens.
  //
  if (host.indexOf("safeway.com") > -1) {
    if (document.getElementById("sfwy-autopilot-ui")) return;
    var sui = document.createElement("div");
    sui.id = "sfwy-autopilot-ui";
    sui.style.cssText = "position:fixed;bottom:20px;right:20px;width:240px;background:#1c2b36;color:#fff;font-family:sans-serif;font-size:12px;border-radius:8px;box-shadow:0 8px 24px rgba(0,0,0,0.4);z-index:999999;border:1px solid #455a64;overflow:hidden;";
    sui.innerHTML = '<div style="background:#C2185B;padding:10px;font-weight:700;display:flex;justify-content:space-between;align-items:center;"><span>Safeway Autopilot</span><span id="cp-close" style="cursor:pointer;font-size:16px;opacity:0.8;">&times;</span></div><div style="padding:12px;"><div style="margin-bottom:8px;color:#90a4ae;">STATUS</div><div id="cp-status" style="color:#4caf50;font-weight:600;margin-bottom:12px;line-height:1.4;">Starting...</div><div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;text-align:center;"><div style="background:#263238;padding:6px;border-radius:4px;"><div id="cp-seen" style="font-weight:700;font-size:14px;">0</div><div style="font-size:10px;color:#78909c;">Visible</div></div><div style="background:#263238;padding:6px;border-radius:4px;"><div id="cp-queue" style="font-weight:700;font-size:14px;color:#ffb74d;">0</div><div style="font-size:10px;color:#78909c;">Queue</div></div><div style="background:#263238;padding:6px;border-radius:4px;"><div id="cp-added" style="font-weight:700;font-size:14px;color:#4caf50;">0</div><div style="font-size:10px;color:#78909c;">Clipped</div></div><div style="background:#263238;padding:6px;border-radius:4px;"><div id="cp-pre" style="font-weight:700;font-size:14px;color:#90a4ae;">0</div><div style="font-size:10px;color:#78909c;">Pre-Clipped</div></div></div></div>';
    document.body.appendChild(sui);

    var sstate = { clipped: 0, run: true, bottomHits: 0, saved: 0 };
    var setSText = function (id, val) {
      var el = document.getElementById(id);
      if (el) el.innerText = val;
    };
    var supdate = function (s, t, q, p) {
      if (s) setSText("cp-status", s);
      if (t !== undefined) setSText("cp-seen", t);
      if (q !== undefined) setSText("cp-queue", q);
      setSText("cp-added", sstate.clipped);
      if (p !== undefined) setSText("cp-pre", p);
      updateLastRun(sstate.clipped);
    };
    var sTextOf = function (el) { return el ? (el.innerText || el.textContent || "").trim() : ""; };

    // Actionable (not-yet-clipped) clip buttons currently visible on the page.
    var sfwyClipButtons = function () {
      var btns = Array.from(document.querySelectorAll(
        'button.rewards-redeem-button, button[aria-label^="Clip coupon"], button[aria-label^="Clip Coupon"]'
      ));
      return btns.filter(function (b) {
        var t = sTextOf(b).toLowerCase();
        // "Clipped" also contains "clip", so require an exact actionable label.
        return (t === "clip coupon" || t === "clip") && b.offsetParent !== null;
      });
    };

    var sfwyCapture = function (btn) {
      try {
        var card = btn.closest("point-reward-card")
                || btn.closest(".reward-card-container")
                || btn.closest(".reward-card");
        if (!card) return;
        var merchant = sTextOf(card.querySelector(".reward-title"));
        // Headline points/value, e.g. "Earn 12X Points*".
        var value = sTextOf(card.querySelector(".reward-card__card-body__card-title__price"))
                 || sTextOf(card.querySelector(".reward-carousel-title"));
        // Fall back to the merchant embedded in aria-label ("Clip coupon for X").
        if (!merchant) {
          var al = btn.getAttribute("aria-label") || "";
          var m = al.match(/clip coupon for\s+(.+)$/i);
          if (m) merchant = m[1].trim();
        }
        if (!merchant) return;
        var detail = sTextOf(card.querySelector(".reward-lmiit"));
        var exp = sTextOf(card.querySelector(".expiration")); // "One time use   Expires 8/25/2026"
        saveOffer("sfwy_" + merchant.replace(/\W/g, ""), merchant, value || detail || "Clip Coupon", "Safeway", {
          status: "clipped", days: exp, expiresTs: parseExpiresTs(exp)
        });
        sstate.saved++;
      } catch (e) {}
    };

    var sloop = setInterval(function () {
      if (!sstate.run) return;
      if (!document.getElementById("sfwy-autopilot-ui")) { sstate.run = false; clearInterval(sloop); return; }

      var queue = sfwyClipButtons().filter(function (b) { return !b.hasAttribute("data-sfwy-processed"); });
      var preClipped = Array.from(document.querySelectorAll("button.rewards-redeem-button")).filter(function (b) {
        return sTextOf(b).toLowerCase().indexOf("clipped") > -1;
      }).length;
      var total = sstate.clipped + queue.length + preClipped;
      supdate(queue.length > 0 ? "Clipping..." : "Scrolling for more...", total, queue.length, preClipped);

      if (queue.length > 0) {
        sstate.bottomHits = 0;
        var target = queue[0];
        target.setAttribute("data-sfwy-processed", "true");
        target.scrollIntoView({ behavior: "auto", block: "center" });
        sfwyCapture(target);
        sstate.clipped++;
        // Angular binds (click) via addEventListener — a bubbling MouseEvent
        // triggers it; native click() is the belt-and-suspenders fallback.
        var o = { view: window, bubbles: true, cancelable: true };
        target.dispatchEvent(new MouseEvent("mousedown", o));
        target.dispatchEvent(new MouseEvent("mouseup", o));
        target.dispatchEvent(new MouseEvent("click", o));
        try { target.click(); } catch (e) {}
      } else {
        var max = document.body.scrollHeight;
        var cur = window.innerHeight + window.scrollY;
        if (cur >= max - 100) {
          sstate.bottomHits++;
          if (sstate.bottomHits > 3) {
            sstate.run = false; clearInterval(sloop);
            supdate("Done. " + sstate.clipped + " clipped.", undefined, 0, preClipped);
          }
        } else {
          sstate.bottomHits = 0;
          window.scrollBy(0, 600);
        }
      }
    }, 450);

    document.getElementById("cp-close").onclick = function () { sstate.run = false; clearInterval(sloop); sui.remove(); };
    return;
  }

  /* ---- No site matched ---- */
  alert("Universal Offer Hub: this site isn't a registered offer source.\nOpen Chase, Amex, Capital One, Capital One Shopping, Walgreens, or Safeway and try again.");
})();
