/*
 * Universal Offer Hub — Capital One page helpers (MAIN world)
 * -------------------------------------------------------------
 * Loaded on Capital One's home page (myaccounts.capitalone.com) and on Capital
 * One Offers (capitaloneoffers.com) in the page's own world, for
 * content/capitalone-auto.js (isolated world), which can't reach the page's
 * own functions. It does nothing until that script asks:
 *
 *   uoh-c1-same-tab  (home page) the run is about to press "View all offers".
 *             A new tab opened by a click a script sent is blocked as a
 *             pop-up, so from then on the page's window.open goes to its
 *             address in this tab, and gives the page this window back (a page
 *             that sets the new window's address then moves this tab too).
 *             window.open is wrapped as the page starts, in case the page
 *             keeps its own reference to it; until this event the wrapper
 *             only calls the real one. It sets data-uoh-same-tab on <html>.
 *   uoh-c1-pick  (offers page) Capital One's card menu ignores a pick made
 *             with events a script sends, as its "View More Offers" button
 *             does (content/scraper.js reactClick calls that button's React
 *             handler for the same reason). React keeps a node's handlers on
 *             the node itself, where only the page's world can see them, so
 *             content/capitalone-auto.js marks the card's row with
 *             data-uoh-pick and sends "uoh-c1-pick"; this plays a click
 *             through React's own handlers: pointerdown, mousedown, pointerup,
 *             mouseup, click, each from the card's name up to the row, as a
 *             real click travels. It writes what it called to data-uoh-picked
 *             on <html>.
 */
(function () {
  "use strict";
  if (window.__uohC1Pick) return;
  window.__uohC1Pick = true;

  if (/^myaccounts\./i.test(location.hostname)) {
    var open = window.open, sameTab = false;
    window.open = function (url) {
      var to = url == null ? "" : String(url);
      if (!sameTab) return open.apply(window, arguments);
      if (to && !/^about:blank$/i.test(to)) {
        try { location.assign(to); } catch (e) { return open.apply(window, arguments); }
      }
      return window;
    };
    document.addEventListener("uoh-c1-same-tab", function () {
      sameTab = true;
      document.documentElement.setAttribute("data-uoh-same-tab", "1");
    });
  }

  var TYPES = ["pointerdown", "mousedown", "pointerup", "mouseup", "click"];
  var HANDLER = { pointerdown: "onPointerDown", mousedown: "onMouseDown", pointerup: "onPointerUp",
                  mouseup: "onMouseUp", click: "onClick" };

  function propsOf(el) {
    for (var k in el) if (k.indexOf("__reactProps$") === 0) return el[k];
    return null;
  }
  // One event object per type, shared on its way up, as React's are.
  function event(type, target) {
    var e = {
      type: type, target: target, currentTarget: target, isTrusted: true, bubbles: true, cancelable: true,
      button: 0, buttons: type === "pointerdown" || type === "mousedown" ? 1 : 0, detail: 1,
      pointerId: 1, pointerType: "mouse", isPrimary: true, clientX: 0, clientY: 0,
      ctrlKey: false, metaKey: false, shiftKey: false, altKey: false, defaultPrevented: false, stopped: false,
      timeStamp: Date.now()
    };
    e.preventDefault = function () { e.defaultPrevented = true; };
    e.stopPropagation = function () { e.stopped = true; };
    e.stopImmediatePropagation = function () { e.stopped = true; };
    e.isDefaultPrevented = function () { return e.defaultPrevented; };
    e.isPropagationStopped = function () { return e.stopped; };
    e.persist = function () {};
    e.nativeEvent = e;
    return e;
  }

  document.addEventListener("uoh-c1-pick", function () {
    var row = document.querySelector("[data-uoh-pick]"), called = [];
    if (!row) return;
    row.removeAttribute("data-uoh-pick");
    var start = row.querySelector("p") || row, path = [];
    for (var el = start; el; el = el.parentElement) { path.push(el); if (el === row) break; }
    TYPES.forEach(function (type) {
      var e = event(type, start);
      for (var i = 0; i < path.length && !e.stopped; i++) {
        var p = propsOf(path[i]), fn = p && p[HANDLER[type]];
        if (typeof fn !== "function") continue;
        e.currentTarget = path[i];
        try { fn(e); called.push((path[i] === row ? "row" : "name") + "." + HANDLER[type]); }
        catch (x) { called.push(HANDLER[type] + " threw"); }
      }
    });
    document.documentElement.setAttribute("data-uoh-picked", called.length ? called.join(",").slice(0, 160) : "no React handlers");
  });
})();
