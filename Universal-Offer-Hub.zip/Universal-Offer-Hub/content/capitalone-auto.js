/*
 * Universal Offer Hub — Capital One background-run steps (ISOLATED world)
 * -------------------------------------------------------------------------
 * Loaded at document_start on myaccounts.capitalone.com and on Capital One
 * Offers (capitaloneoffers.com), after lib/issuers/capitalone.js (the
 * parsers) and content/auto-core.js (roles, Web Lock, port, notes, running
 * the bank's autopilot; see there).
 *
 *   seen      on myaccounts.capitalone.com: the account tiles' endings. The
 *             offers site itself never starts a run.
 *   discover  the card menu in the offers page's header ("Apply my offer
 *             to:"), read and closed again
 *   add       pick the card in that menu, wait until the header names it and
 *             its offers have replaced the last card's, then run "Run
 *             CapitalOne Autopilot" (content/scraper.js), the popup button's
 *             own code. It reads the card from the header once, as it
 *             starts, so the header is checked the same way first.
 *
 * The menu is Radix, and the run's tab is in the background:
 *   - it opens on a pointerdown, ArrowDown or Enter on the card button, not on
 *     a click, so the run tries those in turn;
 *   - a closed menu stays in the page until its closing animation ends, which
 *     a background tab never plays, and while it's there Radix takes any
 *     pointerdown outside it, the card button included, as a click away and
 *     closes the menu again. The run ends that animation itself;
 *   - picking a card: Capital One ignores a pick made with events a script
 *     sends (its first live runs: every way below but the first left the page
 *     on the old card), as its "View More Offers" button does. So the first
 *     way plays a click through React's own handlers, from the page's world
 *     (content/capitalone-main.js), as content/scraper.js reactClick does for
 *     that button; then a full click sequence on the card's name; then its
 *     radio button. One way per try.
 * Before the next card the page is loaded again (the last card's run left it
 * heavy, its menu used), and once more if picking fails; a card that still
 * won't show fails with what each try did, for the run's notes.
 */
(function () {
  "use strict";
  var PAGE = self.UOH_AUTO_PAGE, C = self.UOH_ISSUERS["Capital One"];
  var text = PAGE.text;

  var SEL = {
    account: ".primary-detail__identity__account-number",
    accountSr: ".primary-detail__identity .sr-only",
    trigger: 'button[aria-haspopup="menu"]',
    menu: '[role="menu"][data-state="open"]',
    closedMenu: '[role="menu"][data-state="closed"]',
    item: '[role="menuitem"]',
    header: "p.text-white, button p, header p",      // as content/scraper.js capOneCardInfo() reads it
    tile: 'div[role="button"][data-testid^="feed-tile-"]',
    panel: "c1-scraper-root"
  };
  // Ways to open the menu, and to pick a card in it (one per try).
  var OPEN_WAYS = ["pointer", "key", "enter"], PICK_WAYS = ["react", "pointer", "radio"];

  // The open job and its state, set on every tick (content/auto-core.js).
  // reloading: this page asked to be loaded again and waits to go.
  var job = null, st = null, reloading = false;
  var done, fail, progress, autopilot;

  function all(sel, root) { return Array.prototype.slice.call((root || document).querySelectorAll(sel)); }
  function onOffers() { return /capitaloneoffers\.com/i.test(location.hostname); }

  // The card the header names, read exactly as the autopilot reads it.
  function headerCard() {
    return C.headerCard(all(SEL.header).map(function (el) { return el.innerText || el.textContent || ""; }));
  }

  /* ---------- the card menu ---------- */

  // The header's card button: the menu button whose text names a card.
  function trigger() {
    return all(SEL.trigger).filter(function (b) { return /\d{4}/.test(text(b)); })[0] || null;
  }
  function openMenu(trig) {
    var menus = all(SEL.menu);
    return menus.filter(function (m) { return trig && trig.id && m.getAttribute("aria-labelledby") === trig.id; })[0] ||
           menus[0] || null;
  }
  function isOpen(trig) { return trig.getAttribute("aria-expanded") === "true" || !!openMenu(trig); }
  function items(menu) {
    return all(SEL.item, menu).filter(function (it) { return !it.hasAttribute("data-disabled"); });
  }
  function itemLabel(it) { return text(it.querySelector("p")) || text(it); }
  function itemSelected(it) {
    var r = it.querySelector('input[type="radio"]');
    return !!(r && (r.checked || r.hasAttribute("checked"))) ||
           it.getAttribute("aria-checked") === "true" || it.getAttribute("data-state") === "checked";
  }
  function findItem(card, trig) {
    var menu = openMenu(trig), hits = [];
    if (!menu) return null;
    items(menu).forEach(function (it) {
      var p = C.parseCardLabel(itemLabel(it));
      if (p.last4 === card.digits) hits.push({ el: it, name: p.name.toLowerCase() });
    });
    if (hits.length < 2) return hits[0] ? hits[0].el : null;
    var n = String(card.name || "").toLowerCase();
    return (hits.filter(function (h) { return h.name === n; })[0] || hits[0]).el;
  }

  function key(el, k) {
    try { el.focus(); } catch (e) {}
    el.dispatchEvent(new KeyboardEvent("keydown", { key: k, code: k, keyCode: k === "Enter" ? 13 : k === "Escape" ? 27 : 40,
                                                    bubbles: true, cancelable: true }));
  }
  // A closed menu still in the page: end its closing animation, as a tab you
  // can see would, so Radix takes it out of the page.
  function settleClosedMenus() {
    all(SEL.closedMenu).forEach(function (m) {
      var names = "";
      try { names = getComputedStyle(m).animationName || ""; } catch (e) {}
      names.split(",").forEach(function (n) {
        n = n.trim();
        if (n && n !== "none") m.dispatchEvent(new AnimationEvent("animationend", { animationName: n, bubbles: true }));
      });
    });
  }
  function openTrigger(trig, way) {
    settleClosedMenus();
    if (way === "pointer") {
      var o = { bubbles: true, cancelable: true, composed: true, view: window, button: 0, buttons: 1,
                pointerId: 1, pointerType: "mouse", isPrimary: true };
      try { trig.dispatchEvent(new PointerEvent("pointerdown", o)); }
      catch (e) { trig.dispatchEvent(new MouseEvent("mousedown", o)); }
    } else key(trig, way === "key" ? "ArrowDown" : "Enter");
  }
  // One step of opening the menu (o: { ways, at } for this attempt): the open
  // menu, or null while the next way is tried, 1.5 s apart; o.failed once
  // every way was tried, or the menu stayed open without a card for 3 s.
  function opening(trig, o) {
    var menu = openMenu(trig), t = Date.now();
    if (menu && items(menu).length) return menu;
    if (menu) {                                // open, its rows still coming: no other way now
      if (!o.emptyAt) o.emptyAt = t;
      if (t - o.emptyAt > 3000) o.failed = true;
      return null;
    }
    if (o.at && t - o.at < 1500) return null;
    if (o.ways >= OPEN_WAYS.length) { o.failed = true; return null; }
    openTrigger(trig, OPEN_WAYS[o.ways++]);
    o.at = t;
    return null;
  }
  // Picks the row's card one way; returns what happened, for the notes.
  function pickItem(it, way) {
    var name = it.querySelector("p") || it;
    if (way === "react") {
      // content/capitalone-main.js answers synchronously, on <html>.
      document.documentElement.removeAttribute("data-uoh-picked");
      it.setAttribute("data-uoh-pick", "1");
      document.dispatchEvent(new CustomEvent("uoh-c1-pick"));
      it.removeAttribute("data-uoh-pick");
      return document.documentElement.getAttribute("data-uoh-picked") || "no page helper";
    }
    if (way === "radio") {
      var radio = it.querySelector('input[type="radio"]');
      if (!radio) return "no radio";
      radio.click();
      return "";
    }
    // The whole sequence a mouse click sends.
    var o = { bubbles: true, cancelable: true, composed: true, view: window, button: 0, detail: 1,
              pointerId: 1, pointerType: "mouse", isPrimary: true };
    [["pointerdown", 1], ["mousedown", 1], ["pointerup", 0], ["mouseup", 0], ["click", 0]].forEach(function (s) {
      o.buttons = s[1];
      var E = /^pointer/.test(s[0]) && typeof PointerEvent === "function" ? PointerEvent : MouseEvent;
      name.dispatchEvent(new E(s[0], o));
    });
    return "";
  }
  function closeMenu(trig) {
    var menu = openMenu(trig);
    var esc = { key: "Escape", code: "Escape", keyCode: 27, bubbles: true, cancelable: true };
    (menu || document.body).dispatchEvent(new KeyboardEvent("keydown", esc));
    document.dispatchEvent(new KeyboardEvent("keydown", esc));
  }

  /* ---------- discover ---------- */

  function waitForHeader(t) {
    if (t - st.t0 > 30000) fail("no-offers-page");
    else progress("Waiting for Capital One Offers");
  }

  function stepDiscover() {
    if (!onOffers()) { fail("no-offers-page"); return; }
    var t = Date.now(), shown = headerCard();
    if (!shown.last4) { waitForHeader(t); return; }
    var trig = trigger();
    if (!trig) {
      // A login with one card may have no card menu; its offers show.
      if (t - st.t0 > 8000) done({ options: [], shown: shown.text });
      return;
    }
    if (!st.op) { st.op = { ways: 0, at: 0 }; progress("Reading your cards"); }
    var menu = opening(trig, st.op), list = menu ? items(menu) : [];
    if (!list.length) {
      if (st.op.failed) fail("card-list-empty: the card menu didn't open");
      return;
    }
    // The menu fills in: wait until it holds still.
    if (st.nItems !== list.length) { st.nItems = list.length; st.itemsAt = t; return; }
    if (t - st.itemsAt < 800) return;
    var options = list.map(function (it) { return { label: itemLabel(it), selected: itemSelected(it) }; });
    closeMenu(trig);
    done({ options: options, shown: shown.text });
  }

  /* ---------- the card on screen ---------- */

  // The first offers in the feed, to see the last card's replaced.
  function tileSig() { return all(SEL.tile).slice(0, 6).map(function (el) { return text(el); }).join("|"); }

  // Loads the page again for this job, at most once for each reason ("p": a
  // fresh page before switching, "f": after a failed switch). The run sends
  // the same job to the new page.
  function reloads() {
    try { return JSON.parse(sessionStorage.getItem("UOH_C1Reloads") || "{}")[job.id] || {}; } catch (e) { return {}; }
  }
  function reload(why, note) {
    var mine = reloads(), book = {};
    if (mine[why]) return false;
    mine[why] = 1;
    book[job.id] = mine;                       // only this job's are kept
    try { sessionStorage.setItem("UOH_C1Reloads", JSON.stringify(book)); } catch (e) { return false; }
    progress(note);
    // The page goes on ticking until it unloads; it does nothing more.
    reloading = true;
    location.reload();
    return true;
  }
  // What a failed switch tried, for the run's notes: each try's way and what
  // the menu did, e.g. "react (row.onClick; menu closed), pointer (menu stayed
  // open), radio (menu closed)".
  function tried(sw, shown) {
    return (sw.opened ? "menu opened " + sw.opened + " of " + sw.tries + " tries" : "menu never opened") +
      (sw.missing ? ", card not in the menu" : "") +
      (sw.log.length ? "; " + sw.log.join(", ") : "") +
      "; the page kept ••" + shown.last4 + (reloads().f ? ", also after loading it again" : "");
  }

  // The header must name `card`; if Capital One shows another card, pick it
  // in the menu as you would. True once it does and the menu is closed.
  function ensureCard(card, shown) {
    var t = Date.now(), trig = trigger();
    if (shown.last4 === card.digits) {
      if (trig && isOpen(trig)) { closeMenu(trig); return false; }
      settleClosedMenus();
      if (!st.cardAt) {
        st.cardAt = t;
        if (st.sw) { st.switched = true; st.sw = null; }
      }
      return true;
    }
    st.cardAt = 0;
    if (!trig) { if (t - st.t0 > 20000) fail("switch-failed: no card menu"); return false; }
    // The last card's run left this page heavy and its menu used: switch on
    // a fresh page, as the card list was read on one.
    if (!st.sw && document.getElementById(SEL.panel) && reload("p", "Opening Capital One Offers again for ••" + card.digits)) return false;
    if (st.sig == null) st.sig = tileSig();
    var sw = st.sw = st.sw || { phase: "try", tries: 0, opened: 0, log: [] };
    if (sw.phase === "try") {
      if (sw.tries >= PICK_WAYS.length) {
        if (reload("f", "Opening Capital One Offers again to pick ••" + card.digits)) return false;
        fail("switch-failed: " + tried(sw, shown));
        return false;
      }
      sw.tries++; sw.phase = "open"; sw.op = { ways: 0, at: 0 };
      progress("Switching to " + (card.name || "card") + " ••" + card.digits);
    }
    if (sw.phase === "open") {
      if (opening(trig, sw.op)) { sw.opened++; sw.phase = "pick"; sw.at = t; }
      else if (sw.op.failed) { sw.log.push("menu didn't open"); sw.phase = "try"; }
      return false;
    }
    if (sw.phase === "pick") {
      var it = findItem(card, trig);
      if (it) {
        sw.way = PICK_WAYS[sw.tries - 1];
        sw.did = pickItem(it, sw.way); sw.phase = "wait"; sw.at = t;
      } else if (t - sw.at > 3000) { sw.missing = true; closeMenu(trig); sw.phase = "try"; }
      return false;
    }
    // Waiting for the header to name the card (checked above). A pick that
    // left the menu open didn't register; one that closed it may still be
    // loading the card's offers, or be waiting for the menu to leave the page.
    var stillOpen = !!openMenu(trig);
    if (!stillOpen) settleClosedMenus();
    if (t - sw.at > (stillOpen ? 2500 : 12000)) {
      sw.log.push(sw.way + " (" + (sw.did ? sw.did + "; " : "") + (stillOpen ? "menu stayed open" : "menu closed") + ")");
      if (stillOpen) closeMenu(trig);
      sw.phase = "try";
    }
    return false;
  }

  // The card's offers have held still for 1.5 s. After a switch: at least
  // 2.5 s, and the last card's offers gone (8 s at most: two cards can show
  // the same offers). No offers after 10 s: start anyway; never still after
  // 30 s: start anyway.
  function tilesSettled() {
    var t = Date.now(), n = document.querySelectorAll(SEL.tile).length, sig = tileSig();
    if (st.nTiles !== n || st.lastSig !== sig) { st.nTiles = n; st.lastSig = sig; st.tilesAt = t; }
    var since = t - st.cardAt;
    if (since > 30000) return true;
    if (st.switched) {
      if (since < 2500) return false;
      if (st.sig != null && sig === st.sig && since < 8000) return false;
    }
    return n ? t - st.tilesAt >= 1500 : since > 10000;
  }

  /* ---------- add: run the autopilot on each card ---------- */

  function stepAdd() {
    if (st.go) { autopilot(SEL.panel, true); return; }
    if (!onOffers()) { fail("no-offers-page"); return; }
    var t = Date.now(), shown = headerCard();
    if (!shown.last4) { waitForHeader(t); return; }
    // A card from another login on screen: the browser signed in elsewhere.
    var login = job.loginDigits || [];
    if (login.length > 1 && login.indexOf(shown.last4) < 0) { fail("login-changed"); return; }
    if (!ensureCard(job.card, shown)) return;
    if (!tilesSettled()) { progress("Loading offers on ••" + job.card.digits); return; }
    // The autopilot saves every offer under the card the header names as it
    // starts: never start it on another card.
    if (headerCard().last4 !== job.card.digits) { fail("card-unverified"); return; }
    st.go = true;
    autopilot(SEL.panel, true);
  }

  PAGE.start({
    issuer: "Capital One",
    label: "Capital One",
    spa: true,
    watchTries: 80,          // the account tiles can take a while
    status: "#c1-ti",        // the autopilot's status line ("Loading... (N)")
    verb: "load",            // it loads and saves offers; it adds none
    // The account tiles' endings start a run; the offers site never does.
    seen: function () {
      if (onOffers()) return null;
      var ids = [];
      var add = function (el) { var d = C.parseCardLabel(text(el)).last4; if (d && ids.indexOf(d) < 0) ids.push(d); };
      all(SEL.account).forEach(add);
      if (!ids.length) all(SEL.accountSr).forEach(add);
      return ids.length ? ids : null;
    },
    steps: function (api) {
      done = api.done; fail = api.fail; progress = api.progress; autopilot = api.autopilot;
      return function (j, s) {
        if (reloading) return;
        job = j; st = s;
        if (job.kind === "discover") return stepDiscover();
        if (job.kind === "add") return stepAdd();
        fail("unknown-job");
      };
    }
  });
})();
