/*
 * Universal Offer Hub — Capital One Shopping background-run steps (ISOLATED world)
 * ---------------------------------------------------------------------------------
 * Loaded at document_start on capitaloneshopping.com, after content/auto-core.js
 * (roles, Web Lock, port, running the autopilot; see there).
 *
 *   seen      the user's tab shows the site's offers (tiles named by
 *             data-test-merchant-name, as content/scraper.js reads them). The
 *             site names no card or login, so the run's login is the site.
 *   discover  the run's tab shows offers too
 *   add       run "Run CapitalOne Shopping Autopilot" (content/scraper.js),
 *             the popup button's own code, for the minutes picked beside Run
 *
 * Nothing goes on either page (quiet): no note in the user's tab, no banner
 * in the run's. With anything of ours on the page the site stops adding
 * offers, so the autopilot has no panel either; it says how it's going in
 * its progress messages (RUN_PROGRESS), which content/auto-core.js reads.
 */
(function () {
  "use strict";
  var PAGE = self.UOH_AUTO_PAGE;
  var TILE = "[data-test-merchant-name]";
  var LOGIN = "c1s";        // lib/issuers/capitaloneshopping.js

  function hasOffers() { return !!document.querySelector(TILE); }

  PAGE.start({
    issuer: "Capital One Shopping",
    label: "Capital One Shopping",
    spa: true,
    watchTries: 120,         // 30 s: the offers fill in after the page
    verb: "load",
    quiet: true,
    seen: function () { return hasOffers() ? [LOGIN] : null; },
    steps: function (api) {
      return function (job, st) {
        if (job.kind === "discover") {
          if (hasOffers()) api.done({});
          else if (Date.now() - st.t0 > 30000) api.fail("no-offers");
          else api.progress("Waiting for Capital One Shopping's offers");
          return;
        }
        if (job.kind === "add") { api.autopilot(null, true); return; }
        api.fail("unknown-job");
      };
    }
  });
})();
