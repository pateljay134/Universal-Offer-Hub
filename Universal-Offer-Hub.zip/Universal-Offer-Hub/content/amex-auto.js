/*
 * Universal Offer Hub — Amex background-run driver (ISOLATED world)
 * ------------------------------------------------------------------
 * Loaded at document_start on every global.americanexpress.com page, after
 * lib/offers.js. It asks the service worker what this tab is for:
 *
 *   run    the Offer Hub window (lib/autorun.js). Holds a Web Lock for the
 *          page's life (Chrome doesn't freeze a page that holds one), connects
 *          a port, and does one job at a time, one step per TICK from the
 *          service worker. If the window ends up behind others, its timers
 *          slow down; port messages don't.
 *   watch  the user's own Amex tab, with auto-add on: reports the card on
 *          screen (that's what starts a run) and shows a small note while a
 *          run is working, then its result.
 *   none   auto-add is off: nothing else runs.
 *
 * Everything here runs in the extension's isolated world. Nothing is posted
 * on the page, so Amex's own scripts can't see the control traffic. Clicks
 * are plain DOM events, as in content/scraper.js. Text is read with
 * textContent, so reading doesn't depend on the page being painted.
 */
(function () {
  "use strict";
  if (window.__uohAuto) return;
  window.__uohAuto = true;
  if (window.top !== window) return;
  var UOH = self.UOH;

  var SEL = {
    combo: '[data-testid="simple_switcher_combobox"]',
    num: '[data-testid="simple_switcher_display_number_val"]',
    name: '[data-testid="simple_switcher_display_name"]',
    selected: '[data-testid="simple_switcher_selected_option_display"]',
    listbox: '[data-testid="simple_switcher_listbox"]',
    addBtn: 'button[data-testid="merchantOfferListAddButton"]',
    success: '[data-testid="merchantOfferSuccessIcon"]',
    successOk: '[data-testid="merchantOfferSuccessIcon"][data-dls-icon-color="success"]',
    offersReady: '[data-testid="recommendedOffersContainer"], [data-testid="addedToCardContainer"], [data-testid="listViewContainer"]'
  };

  function send(msg, cb) {
    try {
      chrome.runtime.sendMessage(msg, function (r) {
        if (chrome.runtime.lastError) { if (cb) cb(null); return; }
        if (cb) cb(r);
      });
    } catch (e) { if (cb) cb(null); }
  }

  function text(el) { return el ? String(el.textContent || "").replace(/\s+/g, " ").trim() : ""; }

  function whenBody(fn) {
    if (document.body) return fn();
    document.addEventListener("DOMContentLoaded", function () { fn(); }, { once: true });
  }

  function click(el) {
    var o = { bubbles: true, cancelable: true, view: window };
    el.dispatchEvent(new MouseEvent("mousedown", o));
    el.dispatchEvent(new MouseEvent("mouseup", o));
    el.dispatchEvent(new MouseEvent("click", o));
  }

  // The card shown in the account switcher (the closed combobox).
  function readDisplayed() {
    var combo = document.querySelector(SEL.combo);
    var scope = combo || document;
    var digits = (text(scope.querySelector(SEL.num)).match(/(\d{4,5})\b/) || [])[1] || "";
    if (!digits) {
      var sel = document.querySelector(SEL.selected);
      digits = ((sel && sel.getAttribute("aria-label")) || "").match(/(\d{4,5})\b/);
      digits = digits ? digits[1] : "";
    }
    return { digits: digits, name: text(scope.querySelector(SEL.name)) };
  }

  function listbox() {
    return document.querySelector(SEL.listbox) || document.getElementById("simple-switcher-listbox");
  }

  send({ type: "UOH_HELLO", url: location.href }, function (r) {
    if (!r || r.role === "none") return;
    if (r.role === "run") drive(r.runId);
    else if (r.role === "watch") watch();
  });

  /* ============================================================ */
  /*                 watch: the user's own Amex tab                */
  /* ============================================================ */
  function watch() {
    chrome.runtime.onMessage.addListener(function (m) {
      if (m && m.type === "UOH_RUN_DONE") note(m.ok ? (m.scanOnly ? "found" : "added") : "stopped", m);
    });
    whenBody(function () {
      var tries = 0;
      var iv = setInterval(function () {
        var d = readDisplayed();
        // Some sign-in landing pages show "Overview" instead of a card; fall
        // back to the first 5-digit card ending on the page.
        if (!d.digits && tries > 12) {
          var m = String(document.body && document.body.textContent || "").match(/•{2,}\s*(\d{5})\b/);
          if (m) d.digits = m[1];
        }
        if (d.digits || ++tries > 40) {
          clearInterval(iv);
          if (!d.digits) return;
          send({ type: "UOH_AMEX_SEEN", digits: d.digits, name: d.name }, function (r) {
            if (r && r.started) note("start");
          });
        }
      }, 250);
    });
  }

  var noteHost = null, noteTimer = null;
  function note(kind, m) {
    whenBody(function () {
      if (!noteHost) {
        noteHost = document.createElement("div");
        noteHost.style.cssText = "all:initial;position:fixed;right:20px;bottom:20px;z-index:2147483647;";
        noteHost.attachShadow({ mode: "open" });
        document.documentElement.appendChild(noteHost);
      }
      if (noteTimer) { clearTimeout(noteTimer); noteTimer = null; }
      var msg, action = "";
      if (kind === "start") msg = "Offer Hub opened a new window to add this login's offers. Keep it open and stay signed in; it closes itself when it finishes.";
      else if (kind === "added") msg = (m.note || "Done.");
      else if (kind === "found") { msg = m.note || "Choose which cards get offers and their order in Cards, then press Confirm and add offers."; action = "Open Cards"; }
      else msg = "Stopped: " + (m.note || "something went wrong") + " It will try again on a later visit.";
      noteHost.shadowRoot.innerHTML =
        '<style>' +
        '.b{width:300px;background:#1a232f;color:#f1f5f9;border:1px solid #2d3a4c;border-radius:10px;' +
        'box-shadow:0 12px 36px rgba(0,0,0,.45);font:13px/1.45 -apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Arial,sans-serif;padding:11px 12px}' +
        '.h{display:flex;justify-content:space-between;align-items:center;font-weight:700;margin-bottom:4px}' +
        '.x{cursor:pointer;opacity:.75;font-size:16px;line-height:1;padding:0 2px;background:none;border:0;color:inherit}' +
        '.a{margin-top:8px;background:#3b82f6;color:#fff;border:0;border-radius:7px;padding:6px 10px;font-weight:600;cursor:pointer}' +
        '</style>' +
        '<div class="b"><div class="h"><span>Offer Hub</span><button class="x" aria-label="Dismiss">×</button></div>' +
        '<div class="t"></div>' + (action ? '<button class="a"></button>' : '') + '</div>';
      var root = noteHost.shadowRoot;
      root.querySelector(".t").textContent = msg;
      root.querySelector(".x").addEventListener("click", function () { noteHost.remove(); noteHost = null; });
      if (action) {
        var a = root.querySelector(".a");
        a.textContent = action;
        a.addEventListener("click", function () { send({ type: "UOH_OPEN_DASHBOARD", hash: "cards" }); });
      }
      if (kind === "added" || kind === "stopped") {
        noteTimer = setTimeout(function () { if (noteHost) { noteHost.remove(); noteHost = null; } }, 12000);
      }
    });
  }

  /* ============================================================ */
  /*                 run: the Offer Hub window                     */
  /* ============================================================ */
  function drive(runId) {
    var port = null, locked = false, stopped = false, reconnects = 0;
    var job = null, st = null, lastProgress = 0, rafCount = 0;

    // Held until this page goes away. The name is unique per page load so the
    // next page's lock never waits on this one.
    try {
      navigator.locks.request("uoh-run-" + runId + "-" + Math.random().toString(36).slice(2), function () {
        locked = true;
        post({ t: "LOCKED" });
        return new Promise(function () {});
      });
    } catch (e) {}

    connect();
    whenBody(banner);

    function connect() {
      try { port = chrome.runtime.connect({ name: "uoh-run" }); } catch (e) { return; }
      port.onMessage.addListener(onMsg);
      port.onDisconnect.addListener(function () {
        port = null;
        // The service worker restarted mid-run: reconnect and get the job again.
        if (!stopped && reconnects++ < 3) setTimeout(connect, 1000);
      });
      if (locked) post({ t: "LOCKED" });
    }
    function post(m) { if (port) { try { port.postMessage(m); } catch (e) {} } }

    function onMsg(m) {
      if (!m) return;
      if (m.t === "STOP") { stopped = true; job = null; return; }
      if (m.t === "JOB") {
        if (!job || job.id !== m.job.id) { job = m.job; st = { t0: Date.now() }; }
        return;
      }
      if (m.t === "TICK" && job) {
        try { step(); } catch (e) { fail("error: " + (e && e.message || e)); }
      }
    }

    function done(result) { if (!job) return; post({ t: "DONE", jobId: job.id, result: result }); job = null; }
    function fail(reason) { if (!job) return; post({ t: "FAIL", jobId: job.id, reason: reason }); job = null; }
    function progress(t) {
      var now = Date.now();
      if (now - lastProgress < 1000) return;
      lastProgress = now;
      post({ t: "PROGRESS", jobId: job && job.id, text: t });
    }

    function step() {
      if (job.kind === "discover") return stepDiscover();
      if (job.kind === "probe") return stepProbe();
      if (job.kind === "scan") return stepScan();
      if (job.kind === "add") return stepAdd();
      if (job.kind === "harvest") return stepHarvest();
      fail("unknown-job");
    }

    /* ---------- shared steps ---------- */

    function offersReady() {
      if (document.querySelector(SEL.offersReady) || document.querySelector(SEL.addBtn) || document.querySelector(SEL.success)) {
        if (!st.readyAt) st.readyAt = Date.now();
        return true;
      }
      if (Date.now() - st.t0 > 20000) fail("not-ready");
      return false;
    }

    // After discover, every page must show one of this login's cards; any
    // other card means the browser signed into a different login.
    function sameLogin() {
      var d = readDisplayed().digits;
      if (d && job.loginDigits && job.loginDigits.length > 1 && job.loginDigits.indexOf(d) < 0) {
        fail("login-changed");
        return false;
      }
      return true;
    }

    function findOption(card) {
      var lb = listbox();
      if (!lb) return null;
      var byId = card.optId ? lb.querySelector('[id="combo-' + card.optId + '"]') : null;
      if (byId) return byId;
      var opts = lb.querySelectorAll('[role="option"]');
      for (var i = 0; i < opts.length; i++) {
        if ((opts[i].getAttribute("aria-label") || "").indexOf("ending in " + card.digits) > -1) return opts[i];
      }
      return null;
    }

    // Make the switcher show `card`. Returns true once it does. If picking
    // the card reloads the page, the service worker resends the same job and
    // the new page finds the card already selected.
    function ensureCard(card) {
      if (readDisplayed().digits === card.digits) {
        if (!st.cardAt) st.cardAt = Date.now();
        return true;
      }
      var t = Date.now(), sw = st.sw = st.sw || { phase: "open", at: t, tries: 0 };
      var retry = function () {
        if (++sw.tries >= 2) fail("switch-failed");
        else { sw.phase = "open"; sw.at = t; }
      };
      if (sw.phase === "open") {
        var combo = document.querySelector(SEL.combo);
        if (!combo) { fail("switch-failed"); return false; }
        progress("Switching to " + (card.name || "card") + " ••" + card.digits);
        click(combo);
        sw.phase = "pick"; sw.at = t;
      } else if (sw.phase === "pick") {
        var opt = findOption(card);
        if (opt) { click(opt); sw.phase = "confirm"; sw.at = t; }
        else if (t - sw.at > 5000) retry();
      } else if (t - sw.at > 15000) {
        retry();
      }
      return false;
    }

    // True once the count of `sel` has held for stableMs, at least minMs after
    // the card was on screen. Gives up waiting (true) after maxMs.
    function settled(sel, stableMs, minMs, maxMs) {
      var n = document.querySelectorAll(sel).length, t = Date.now();
      if (st.cnt !== n) { st.cnt = n; st.cntAt = t; }
      var base = st.cardAt || st.readyAt || st.t0;
      if (t - base > maxMs) return true;
      return t - st.cntAt >= stableMs && t - base >= minMs;
    }

    function tileOf(el) {
      return el.closest(".flex-justify-between.flex-item-grow") || el.closest(".row") || null;
    }
    // Merchant / offer / expiry from an offer tile; same selectors as the
    // adding phase in content/scraper.js.
    function tileInfo(btn) {
      var tile = tileOf(btn);
      if (!tile) return null;
      var h = tile.querySelector("h3.heading-sans-small-medium span") || tile.querySelector("h3 span") || tile.querySelector("h3");
      var vEl = tile.querySelector(".body.color-text-regular span");
      if (!vEl) {
        var oc = tile.querySelectorAll('[data-testid="overflowTextContainer"]');
        if (oc.length >= 2) vEl = oc[1].querySelector("span") || oc[1];
      }
      var m = text(h);
      if (!m) return null;
      var exp = text(tile.querySelector(".color-status-text-critical")) || UOH.expiryText(tile.textContent);
      return { mk: UOH.compact(m), m: m, v: text(vEl), exp: exp, tile: tile };
    }
    function addButtons() { return Array.prototype.slice.call(document.querySelectorAll(SEL.addBtn)); }

    /* ---------- jobs ---------- */

    function stepDiscover() {
      if (!offersReady()) return;
      var t = Date.now();
      if (!st.step) {
        st.displayed = readDisplayed();
        var combo = document.querySelector(SEL.combo);
        if (!combo) { done({ displayed: st.displayed, options: [], optId: viewAllOptId() }); return; }
        progress("Reading your cards");
        click(combo);
        st.step = "list"; st.at = t;
        return;
      }
      var lb = listbox();
      var opts = lb ? lb.querySelectorAll('[role="option"]') : [];
      if (opts.length) {
        var out = Array.prototype.map.call(opts, function (o) {
          return { testid: o.getAttribute("data-testid") || "", id: o.id || "", aria: o.getAttribute("aria-label") || "",
                   name: text(o.querySelector(SEL.name)), digits: text(o.querySelector(SEL.num)), text: text(o) };
        });
        closeSwitcher();
        done({ displayed: st.displayed, options: out, optId: viewAllOptId() });
        return;
      }
      if (t - st.at > 5000) {
        if (!st.retried) { st.retried = true; st.step = null; return; }
        fail("switcher-empty");
      }
    }

    function closeSwitcher() {
      var combo = document.querySelector(SEL.combo);
      if (!combo) return;
      combo.dispatchEvent(new KeyboardEvent("keydown", { key: "Escape", code: "Escape", keyCode: 27, bubbles: true }));
      if (combo.getAttribute("aria-expanded") === "true") click(combo);
    }

    // The "View All" link on /offers names the displayed card's account id.
    function viewAllOptId() {
      var a = document.querySelector('a[href*="/offers/enrolled?opaqueAccountId="]');
      var m = a && (a.getAttribute("href") || "").match(/opaqueAccountId=([^&#]+)/);
      return m ? decodeURIComponent(m[1]) : null;
    }

    // Spike diagnostics: is this hidden page rendering, and what does it see?
    function stepProbe() {
      var t = Date.now();
      if (!st.rafStarted) {
        st.rafStarted = true;
        var loop = function () { rafCount++; requestAnimationFrame(loop); };
        requestAnimationFrame(loop);
      }
      if (!st.lastProbe || t - st.lastProbe >= 2000) {
        st.lastProbe = t;
        post({ t: "PROBE", data: {
          s: Math.round((t - st.t0) / 1000), vis: document.visibilityState, focus: document.hasFocus(),
          raf: rafCount, addButtons: document.querySelectorAll(SEL.addBtn).length,
          success: document.querySelectorAll(SEL.success).length, card: readDisplayed().digits,
          path: location.pathname
        } });
      }
      if (t - st.t0 >= (job.seconds || 60) * 1000) done({});
    }

    function stepScan() {
      if (!offersReady() || !sameLogin() || !ensureCard(job.card)) return;
      // Scrolling loads more tiles on a visible page; in a hidden tab it's harmless.
      try { window.scrollTo(0, document.body.scrollHeight); } catch (e) {}
      if (!settled(SEL.addBtn, 2000, 3000, 20000)) { progress("Reading offers on ••" + job.card.digits); return; }
      var items = [], seen = {};
      addButtons().forEach(function (b) {
        var i = tileInfo(b);
        if (!i || seen[i.mk + "|" + i.v]) return;
        seen[i.mk + "|" + i.v] = true;
        items.push({ mk: i.mk, m: i.m, v: i.v, exp: i.exp });
      });
      done({ items: items, buttons: addButtons().length });
    }

    // The manual "Run Amex Autopilot" loop (content/scraper.js, adding phase):
    // one add button per tick, scrolled into view (which makes Amex load the
    // next tiles) and clicked; once none are left unclicked, wait until Amex
    // has confirmed them. Every offer the card shows is added: Amex keeps an
    // offer on one card per login, so the next card gets what's left.
    function stepAdd() {
      if (!offersReady() || !sameLogin() || !ensureCard(job.card)) return;
      var t = Date.now();
      if (!st.adding) {
        if (!settled(SEL.addBtn, 1500, 2000, 20000)) { progress("Loading offers on ••" + job.card.digits); return; }
        st.adding = true;
        st.clicked = []; st.items = {}; st.recs = {}; st.nrecs = 0;
        st.icons0 = document.querySelectorAll(SEL.successOk).length;
        st.prog = -1; st.progAt = t;
      }
      var btns = addButtons(), next = null;
      for (var i = 0; i < btns.length; i++) {
        if (!btns[i].hasAttribute("data-uoh-clicked")) { next = btns[i]; break; }
      }
      if (next) {
        next.setAttribute("data-uoh-clicked", "1");
        try { next.scrollIntoView({ block: "center" }); } catch (e) {}
        var info = tileInfo(next);
        st.clicked.push({ btn: next, tile: info ? info.tile : tileOf(next), mk: info ? info.mk : null });
        if (info) {
          st.items[info.mk] = { mk: info.mk, m: info.m, v: info.v, exp: info.exp };
          keep(info, "available");
        }
        click(next);
        progress("Adding offers on ••" + job.card.digits + ": " + st.clicked.length + " clicked");
        return;
      }
      flushSaves();
      if (!st.clicked.length) { finishAdd(false); return; }
      var icons = document.querySelectorAll(SEL.successOk).length - st.icons0;
      if (!btns.length && icons >= st.clicked.length) { finishAdd(false); return; }
      // Still waiting: progress is buttons cleared plus checks shown; 30 s with
      // neither moving means an offer stalled (rate limit, error), so move on.
      var prog = (st.clicked.length - btns.length) + icons;
      if (prog !== st.prog) { st.prog = prog; st.progAt = t; }
      progress("Waiting for Amex to confirm " + st.clicked.length + " offers on ••" + job.card.digits);
      if (t - st.progAt > 30000) finishAdd(true);
    }

    // The card's label for saved rows: the switcher's name for it if the job
    // has none, never just the digits.
    function cardLabel() {
      return (job.card.name || readDisplayed().name || "Amex") + " ••" + job.card.digits;
    }
    // Same row shape and key as the manual autopilot, so both update one row.
    function keep(info, status) {
      st.recs["amex_" + job.card.digits + "_" + info.m.replace(/\W/g, "")] = {
        m: info.m, v: info.v, site: "Amex", status: status, days: info.exp, expiresTs: UOH.parseExpiresTs(info.exp),
        card: cardLabel(), cardId: job.card.digits, last4: job.card.digits
      };
      if (++st.nrecs >= 20) flushSaves();
    }
    function flushSaves() {
      if (!st.nrecs) return;
      post({ t: "SAVE", records: st.recs });
      st.recs = {}; st.nrecs = 0;
    }

    // timedOut: confirmations stopped coming. Then a clicked offer counts as
    // added if its button is gone or its tile shows the check.
    function finishAdd(timedOut) {
      var added = [], failed = [], items = [];
      st.clicked.forEach(function (c) {
        if (!c.mk) return;
        var ok = !timedOut || !c.btn.isConnected || (c.tile && c.tile.isConnected && c.tile.querySelector(SEL.success));
        if (ok) { added.push(c.mk); if (st.items[c.mk]) items.push(st.items[c.mk]); }
        else failed.push(c.mk);
      });
      done({ added: added, failed: failed, gone: [], items: items, clicked: st.clicked.length,
             stalled: !!timedOut && !added.length });
    }

    function stepHarvest() {
      var t = Date.now();
      var shown = readDisplayed().digits;
      if (!(document.querySelector(SEL.success) || document.querySelector('[data-testid="listViewContainer"]') || shown)) {
        if (t - st.t0 > 20000) fail("not-ready");
        return;
      }
      if (!st.readyAt) st.readyAt = t;
      if (!settled(SEL.success, 1000, 2000, 15000)) { progress("Reading added offers on ••" + job.card.digits); return; }
      if (!sameLogin()) return;
      // A card on screen must be the job's card. The id in the URL is the one
      // the service worker put there, so it only counts when no card shows.
      var idm = location.search.match(/opaqueAccountId=([^&#]+)/);
      var urlOk = idm && job.card.optId && decodeURIComponent(idm[1]) === job.card.optId;
      if (shown ? shown !== job.card.digits : !urlOk) { fail("card-unverified"); return; }
      var card = job.card, recs = {}, n = 0, batch = 0;
      var flush = function () { if (batch) { post({ t: "SAVE", records: recs }); recs = {}; batch = 0; } };
      Array.prototype.forEach.call(document.querySelectorAll(SEL.success), function (icon) {
        var tile = icon;
        for (var i = 0; i < 14 && tile; i++) {
          tile = tile.parentElement;
          if (tile && tile.querySelector("h3.heading-sans-small-medium span")) break;
        }
        if (!tile) return;
        var m = text(tile.querySelector("h3.heading-sans-small-medium span") || tile.querySelector("h3 span"));
        var oc = tile.querySelectorAll('[data-testid="overflowTextContainer"]');
        var v = oc.length >= 2 ? text(oc[1].querySelector("span") || oc[1]) : text(tile.querySelector(".body-1.text-truncate span"));
        if (!m || !v) return;
        var days = text(tile.querySelector(".color-status-text-critical")) || UOH.expiryText(tile.textContent);
        recs["amex_" + card.digits + "_" + m.replace(/\W/g, "")] = {
          m: m, v: v, site: "Amex", status: "added", days: days,
          card: (card.name || "Amex") + " ••" + card.digits, cardId: card.digits, last4: card.digits
        };
        n++;
        if (++batch >= 100) flush();
      });
      flush();
      done({ harvested: n });
    }

    function banner() {
      var host = document.createElement("div");
      host.style.cssText = "all:initial;position:fixed;left:50%;top:10px;transform:translateX(-50%);z-index:2147483647;";
      host.attachShadow({ mode: "open" }).innerHTML =
        '<div style="background:#1a232f;color:#f1f5f9;border:1px solid #2d3a4c;border-radius:8px;padding:8px 12px;' +
        'font:13px -apple-system,BlinkMacSystemFont,Segoe UI,Roboto,Arial,sans-serif;box-shadow:0 8px 24px rgba(0,0,0,.35)">' +
        'Offer Hub is adding your Amex offers in this window. Keep it open; it closes itself when it finishes.</div>';
      document.documentElement.appendChild(host);
    }
  }
})();
