/*
 * Universal Offer Hub — Amex background-run steps (ISOLATED world)
 * ------------------------------------------------------------------
 * Loaded at document_start on every global.americanexpress.com page, after
 * lib/offers.js and content/auto-core.js, which handles what every issuer
 * shares: the tab's role, the Web Lock, the port to the service worker, the
 * notes, and running the bank's own autopilot. This file is what only Amex
 * has:
 *
 *   seen      the card on screen in the account switcher
 *   discover  the switcher's options
 *   add       show the card in the switcher, then run "Run Amex Autopilot"
 *             on it, the popup button's own code (content/scraper.js). It
 *             adds every offer, opens the card's Added page (a new page load:
 *             the manifest starts it again there) and reads it.
 */
(function () {
  "use strict";
  var PAGE = self.UOH_AUTO_PAGE;
  var text = PAGE.text, click = PAGE.click;

  var SEL = {
    combo: '[data-testid="simple_switcher_combobox"]',
    num: '[data-testid="simple_switcher_display_number_val"]',
    name: '[data-testid="simple_switcher_display_name"]',
    selected: '[data-testid="simple_switcher_selected_option_display"]',
    listbox: '[data-testid="simple_switcher_listbox"]',
    addBtn: 'button[data-testid="merchantOfferListAddButton"]',
    success: '[data-testid="merchantOfferSuccessIcon"]',
    offersReady: '[data-testid="recommendedOffersContainer"], [data-testid="addedToCardContainer"], [data-testid="listViewContainer"]',
    panel: "amex-autopilot-ui"
  };

  // The open job and its state, set on every tick (content/auto-core.js).
  var job = null, st = null;
  var done, fail, progress, autopilot;

  // The card shown in the account switcher (the closed combobox).
  function readDisplayed() {
    var combo = document.querySelector(SEL.combo);
    var scope = combo || document;
    var digits = (text(scope.querySelector(SEL.num)).match(/(\d{4,5})\b/) || [])[1] || "";
    if (!digits) {
      var sel = document.querySelector(SEL.selected);
      digits = ((sel && sel.getAttribute("aria-label")) || "").match(/(\d{4,5})\b/);
      digits = digits ? digits[1] : "";
    }
    return { digits: digits, name: text(scope.querySelector(SEL.name)) };
  }

  function listbox() {
    return document.querySelector(SEL.listbox) || document.getElementById("simple-switcher-listbox");
  }

  /* ---------- the card on screen ---------- */

  function offersReady() {
    if (document.querySelector(SEL.offersReady) || document.querySelector(SEL.addBtn) || document.querySelector(SEL.success)) {
      if (!st.readyAt) st.readyAt = Date.now();
      return true;
    }
    if (Date.now() - st.t0 > 20000) fail("not-ready");
    return false;
  }

  // After discover, every page must show one of this login's cards; any
  // other card means the browser signed into a different login.
  function sameLogin() {
    var d = readDisplayed().digits;
    if (d && job.loginDigits && job.loginDigits.length > 1 && job.loginDigits.indexOf(d) < 0) {
      fail("login-changed");
      return false;
    }
    return true;
  }

  function findOption(card) {
    var lb = listbox();
    if (!lb) return null;
    var byId = card.optId ? lb.querySelector('[id="combo-' + card.optId + '"]') : null;
    if (byId) return byId;
    var opts = lb.querySelectorAll('[role="option"]');
    for (var i = 0; i < opts.length; i++) {
      if ((opts[i].getAttribute("aria-label") || "").indexOf("ending in " + card.digits) > -1) return opts[i];
    }
    return null;
  }

  // Make the switcher show `card`. Returns true once it does. If picking
  // the card reloads the page, the service worker resends the same job and
  // the new page finds the card already selected.
  function ensureCard(card) {
    if (readDisplayed().digits === card.digits) {
      if (!st.cardAt) st.cardAt = Date.now();
      return true;
    }
    var t = Date.now(), sw = st.sw = st.sw || { phase: "open", at: t, tries: 0 };
    var retry = function () {
      if (++sw.tries >= 2) fail("switch-failed");
      else { sw.phase = "open"; sw.at = t; }
    };
    if (sw.phase === "open") {
      var combo = document.querySelector(SEL.combo);
      if (!combo) { fail("switch-failed"); return false; }
      progress("Switching to " + (card.name || "card") + " ••" + card.digits);
      click(combo);
      sw.phase = "pick"; sw.at = t;
    } else if (sw.phase === "pick") {
      var opt = findOption(card);
      if (opt) { click(opt); sw.phase = "confirm"; sw.at = t; }
      else if (t - sw.at > 5000) retry();
    } else if (t - sw.at > 15000) {
      retry();
    }
    return false;
  }

  // True once the count of `sel` has held for stableMs, at least minMs after
  // the card was on screen. Gives up waiting (true) after maxMs.
  function settled(sel, stableMs, minMs, maxMs) {
    var n = document.querySelectorAll(sel).length, t = Date.now();
    if (st.cnt !== n) { st.cnt = n; st.cntAt = t; }
    var base = st.cardAt || st.readyAt || st.t0;
    if (t - base > maxMs) return true;
    return t - st.cntAt >= stableMs && t - base >= minMs;
  }

  /* ---------- jobs ---------- */

  function stepDiscover() {
    if (!offersReady()) return;
    var t = Date.now();
    if (!st.step) {
      st.displayed = readDisplayed();
      var combo = document.querySelector(SEL.combo);
      if (!combo) { done({ displayed: st.displayed, options: [], optId: viewAllOptId() }); return; }
      progress("Reading your cards");
      click(combo);
      st.step = "list"; st.at = t;
      return;
    }
    var lb = listbox();
    var opts = lb ? lb.querySelectorAll('[role="option"]') : [];
    if (opts.length) {
      var out = Array.prototype.map.call(opts, function (o) {
        return { testid: o.getAttribute("data-testid") || "", id: o.id || "", aria: o.getAttribute("aria-label") || "",
                 name: text(o.querySelector(SEL.name)), digits: text(o.querySelector(SEL.num)), text: text(o) };
      });
      closeSwitcher();
      done({ displayed: st.displayed, options: out, optId: viewAllOptId() });
      return;
    }
    if (t - st.at > 5000) {
      if (!st.retried) { st.retried = true; st.step = null; return; }
      fail("switcher-empty");
    }
  }

  function closeSwitcher() {
    var combo = document.querySelector(SEL.combo);
    if (!combo) return;
    combo.dispatchEvent(new KeyboardEvent("keydown", { key: "Escape", code: "Escape", keyCode: 27, bubbles: true }));
    if (combo.getAttribute("aria-expanded") === "true") click(combo);
  }

  // The "View All" link on /offers names the displayed card's account id.
  function viewAllOptId() {
    var a = document.querySelector('a[href*="/offers/enrolled?opaqueAccountId="]');
    var m = a && (a.getAttribute("href") || "").match(/opaqueAccountId=([^&#]+)/);
    return m ? decodeURIComponent(m[1]) : null;
  }

  function stepAdd() {
    // The autopilot moved on to the card's Added page: the manifest's content
    // script started it again there (content/scraper.js resumes the run).
    if (job.started && /\/offers\/enrolled/i.test(location.pathname)) {
      autopilot(SEL.panel, false);
      return;
    }
    if (!st.go) {
      if (!offersReady() || !sameLogin() || !ensureCard(job.card)) return;
      if (!settled(SEL.addBtn, 1500, 2000, 20000)) { progress("Loading offers on ••" + job.card.digits); return; }
      st.go = true;
    }
    autopilot(SEL.panel, true);
  }

  PAGE.start({
    issuer: "Amex",
    label: "Amex",
    // The card on screen starts a run. Some sign-in landing pages show
    // "Overview" instead of a card; then the first 5-digit card ending on
    // the page.
    seen: function (tries) {
      var d = readDisplayed();
      if (!d.digits && tries > 12) {
        var m = String(document.body && document.body.textContent || "").match(/•{2,}\s*(\d{5})\b/);
        if (m) d.digits = m[1];
      }
      return d.digits ? [d.digits] : null;
    },
    steps: function (api) {
      done = api.done; fail = api.fail; progress = api.progress; autopilot = api.autopilot;
      return function (j, s) {
        job = j; st = s;
        if (job.kind === "discover") return stepDiscover();
        if (job.kind === "add") return stepAdd();
        fail("unknown-job");
      };
    }
  });
})();
