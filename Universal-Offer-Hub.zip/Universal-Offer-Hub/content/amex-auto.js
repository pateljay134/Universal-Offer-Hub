/*
 * Universal Offer Hub — Amex background-run driver (ISOLATED world)
 * ------------------------------------------------------------------
 * Loaded at document_start on every global.americanexpress.com page, after
 * lib/offers.js. It asks the service worker what this tab is for:
 *
 *   run    the hidden "Offer Hub" tab (lib/autorun.js). Holds a Web Lock for
 *          the page's life (Chrome doesn't freeze a page that holds one, and
 *          it freezes every tab in a collapsed group), connects a port, and
 *          does one job at a time, one step per TICK from the service worker.
 *          Timers in a hidden tab slow to one wake-up a minute after about
 *          60 s; port messages don't.
 *   watch  the user's own Amex tab, with auto-add on: reports the card on
 *          screen (that's what starts a run) and shows a small note while a
 *          run is working, then its result.
 *   none   auto-add is off: nothing else runs.
 *
 * Everything here runs in the extension's isolated world. Nothing is posted
 * on the page, so Amex's own scripts can't see the control traffic. Clicks
 * are plain DOM events, as in content/scraper.js. Text is read with
 * textContent, which works in a hidden tab (no layout or rendering needed).
 */
(function () {
  "use strict";
  if (window.__uohAuto) return;
  window.__uohAuto = true;
  if (window.top !== window) return;
  var UOH = self.UOH;

  var SEL = {
    combo: '[data-testid="simple_switcher_combobox"]',
    num: '[data-testid="simple_switcher_display_number_val"]',
    name: '[data-testid="simple_switcher_display_name"]',
    selected: '[data-testid="simple_switcher_selected_option_display"]',
    listbox: '[data-testid="simple_switcher_listbox"]',
    addBtn: 'button[data-testid="merchantOfferListAddButton"]',
    success: '[data-testid="merchantOfferSuccessIcon"]',
    offersReady: '[data-testid="recommendedOffersContainer"], [data-testid="addedToCardContainer"], [data-testid="listViewContainer"]'
  };

  function send(msg, cb) {
    try {
      chrome.runtime.sendMessage(msg, function (r) {
        if (chrome.runtime.lastError) { if (cb) cb(null); return; }
        if (cb) cb(r);
      });
    } catch (e) { if (cb) cb(null); }
  }

  function text(el) { return el ? String(el.textContent || "").replace(/\s+/g, " ").trim() : ""; }

  function whenBody(fn) {
    if (document.body) return fn();
    document.addEventListener("DOMContentLoaded", function () { fn(); }, { once: true });
  }

  function click(el) {
    var o = { bubbles: true, cancelable: true, view: window };
    el.dispatchEvent(new MouseEvent("mousedown", o));
    el.dispatchEvent(new MouseEvent("mouseup", o));
    el.dispatchEvent(new MouseEvent("click", o));
  }

  // The card shown in the account switcher (the closed combobox).
  function readDisplayed() {
    var combo = document.querySelector(SEL.combo);
    var scope = combo || document;
    var digits = (text(scope.querySelector(SEL.num)).match(/(\d{4,5})\b/) || [])[1] || "";
    if (!digits) {
      var sel = document.querySelector(SEL.selected);
      digits = ((sel && sel.getAttribute("aria-label")) || "").match(/(\d{4,5})\b/);
      digits = digits ? digits[1] : "";
    }
    return { digits: digits, name: text(scope.querySelector(SEL.name)) };
  }

  function listbox() {
    return document.querySelector(SEL.listbox) || document.getElementById("simple-switcher-listbox");
  }

  send({ type: "UOH_HELLO", url: location.href }, function (r) {
    if (!r || r.role === "none") return;
    if (r.role === "run") drive(r.runId);
    else if (r.role === "watch") watch();
  });

  /* ============================================================ */
  /*                 watch: the user's own Amex tab                */
  /* ============================================================ */
  function watch() {
    chrome.runtime.onMessage.addListener(function (m) {
      if (m && m.type === "UOH_RUN_DONE") note(m.ok ? (m.scanOnly ? "found" : "added") : "stopped", m);
    });
    whenBody(function () {
      var tries = 0;
      var iv = setInterval(function () {
        var d = readDisplayed();
        // Some sign-in landing pages show "Overview" instead of a card; fall
        // back to the first 5-digit card ending on the page.
        if (!d.digits && tries > 12) {
          var m = String(document.body && document.body.textContent || "").match(/•{2,}\s*(\d{5})\b/);
          if (m) d.digits = m[1];
        }
        if (d.digits || ++tries > 40) {
          clearInterval(iv);
          if (!d.digits) return;
          send({ type: "UOH_AMEX_SEEN", digits: d.digits, name: d.name }, function (r) {
            if (r && r.started) note("start");
          });
        }
      }, 250);
    });
  }

  var noteHost = null, noteTimer = null;
  function note(kind, m) {
    whenBody(function () {
      if (!noteHost) {
        noteHost = document.createElement("div");
        noteHost.style.cssText = "all:initial;position:fixed;right:20px;bottom:20px;z-index:2147483647;";
        noteHost.attachShadow({ mode: "open" });
        document.documentElement.appendChild(noteHost);
      }
      if (noteTimer) { clearTimeout(noteTimer); noteTimer = null; }
      var msg, action = "";
      if (kind === "start") msg = "Updating offers for this login in a background tab (about 2 minutes). Stay signed in until it finishes.";
      else if (kind === "added") msg = (m.note || "Done.");
      else if (kind === "found") { msg = m.note || "Set your card order in the dashboard to turn on auto-add."; action = "Set card order"; }
      else msg = "Stopped: " + (m.note || "something went wrong") + " It will try again on a later visit.";
      noteHost.shadowRoot.innerHTML =
        '<style>' +
        '.b{width:300px;background:#1a232f;color:#f1f5f9;border:1px solid #2d3a4c;border-radius:10px;' +
        'box-shadow:0 12px 36px rgba(0,0,0,.45);font:13px/1.45 -apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Arial,sans-serif;padding:11px 12px}' +
        '.h{display:flex;justify-content:space-between;align-items:center;font-weight:700;margin-bottom:4px}' +
        '.x{cursor:pointer;opacity:.75;font-size:16px;line-height:1;padding:0 2px;background:none;border:0;color:inherit}' +
        '.a{margin-top:8px;background:#3b82f6;color:#fff;border:0;border-radius:7px;padding:6px 10px;font-weight:600;cursor:pointer}' +
        '</style>' +
        '<div class="b"><div class="h"><span>Offer Hub</span><button class="x" aria-label="Dismiss">×</button></div>' +
        '<div class="t"></div>' + (action ? '<button class="a"></button>' : '') + '</div>';
      var root = noteHost.shadowRoot;
      root.querySelector(".t").textContent = msg;
      root.querySelector(".x").addEventListener("click", function () { noteHost.remove(); noteHost = null; });
      if (action) {
        var a = root.querySelector(".a");
        a.textContent = action;
        a.addEventListener("click", function () { send({ type: "UOH_OPEN_DASHBOARD", hash: "cards" }); });
      }
      if (kind === "added" || kind === "stopped") {
        noteTimer = setTimeout(function () { if (noteHost) { noteHost.remove(); noteHost = null; } }, 12000);
      }
    });
  }

  /* ============================================================ */
  /*                 run: the hidden "Offer Hub" tab               */
  /* ============================================================ */
  function drive(runId) {
    var port = null, locked = false, stopped = false, reconnects = 0;
    var job = null, st = null, lastProgress = 0, rafCount = 0;

    // Held until this page goes away. The name is unique per page load so the
    // next page's lock never waits on this one.
    try {
      navigator.locks.request("uoh-run-" + runId + "-" + Math.random().toString(36).slice(2), function () {
        locked = true;
        post({ t: "LOCKED" });
        return new Promise(function () {});
      });
    } catch (e) {}

    connect();
    whenBody(banner);

    function connect() {
      try { port = chrome.runtime.connect({ name: "uoh-run" }); } catch (e) { return; }
      port.onMessage.addListener(onMsg);
      port.onDisconnect.addListener(function () {
        port = null;
        // The service worker restarted mid-run: reconnect and get the job again.
        if (!stopped && reconnects++ < 3) setTimeout(connect, 1000);
      });
      if (locked) post({ t: "LOCKED" });
    }
    function post(m) { if (port) { try { port.postMessage(m); } catch (e) {} } }

    function onMsg(m) {
      if (!m) return;
      if (m.t === "STOP") { stopped = true; job = null; return; }
      if (m.t === "JOB") {
        if (!job || job.id !== m.job.id) { job = m.job; st = { t0: Date.now() }; }
        return;
      }
      if (m.t === "TICK" && job) {
        try { step(); } catch (e) { fail("error: " + (e && e.message || e)); }
      }
    }

    function done(result) { if (!job) return; post({ t: "DONE", jobId: job.id, result: result }); job = null; }
    function fail(reason) { if (!job) return; post({ t: "FAIL", jobId: job.id, reason: reason }); job = null; }
    function progress(t) {
      var now = Date.now();
      if (now - lastProgress < 1000) return;
      lastProgress = now;
      post({ t: "PROGRESS", jobId: job && job.id, text: t });
    }

    function step() {
      if (job.kind === "discover") return stepDiscover();
      if (job.kind === "probe") return stepProbe();
      if (job.kind === "scan") return stepScan();
      if (job.kind === "add") return stepAdd();
      if (job.kind === "harvest") return stepHarvest();
      fail("unknown-job");
    }

    /* ---------- shared steps ---------- */

    function offersReady() {
      if (document.querySelector(SEL.offersReady) || document.querySelector(SEL.addBtn) || document.querySelector(SEL.success)) {
        if (!st.readyAt) st.readyAt = Date.now();
        return true;
      }
      if (Date.now() - st.t0 > 20000) fail("not-ready");
      return false;
    }

    // After discover, every page must show one of this login's cards; any
    // other card means the browser signed into a different login.
    function sameLogin() {
      var d = readDisplayed().digits;
      if (d && job.loginDigits && job.loginDigits.length > 1 && job.loginDigits.indexOf(d) < 0) {
        fail("login-changed");
        return false;
      }
      return true;
    }

    function findOption(card) {
      var lb = listbox();
      if (!lb) return null;
      var byId = card.optId ? lb.querySelector('[id="combo-' + card.optId + '"]') : null;
      if (byId) return byId;
      var opts = lb.querySelectorAll('[role="option"]');
      for (var i = 0; i < opts.length; i++) {
        if ((opts[i].getAttribute("aria-label") || "").indexOf("ending in " + card.digits) > -1) return opts[i];
      }
      return null;
    }

    // Make the switcher show `card`. Returns true once it does. If picking
    // the card reloads the page, the service worker resends the same job and
    // the new page finds the card already selected.
    function ensureCard(card) {
      if (readDisplayed().digits === card.digits) {
        if (!st.cardAt) st.cardAt = Date.now();
        return true;
      }
      var t = Date.now(), sw = st.sw = st.sw || { phase: "open", at: t, tries: 0 };
      var retry = function () {
        if (++sw.tries >= 2) fail("switch-failed");
        else { sw.phase = "open"; sw.at = t; }
      };
      if (sw.phase === "open") {
        var combo = document.querySelector(SEL.combo);
        if (!combo) { fail("switch-failed"); return false; }
        progress("Switching to " + (card.name || "card") + " ••" + card.digits);
        click(combo);
        sw.phase = "pick"; sw.at = t;
      } else if (sw.phase === "pick") {
        var opt = findOption(card);
        if (opt) { click(opt); sw.phase = "confirm"; sw.at = t; }
        else if (t - sw.at > 5000) retry();
      } else if (t - sw.at > 15000) {
        retry();
      }
      return false;
    }

    // True once the count of `sel` has held for stableMs, at least minMs after
    // the card was on screen. Gives up waiting (true) after maxMs.
    function settled(sel, stableMs, minMs, maxMs) {
      var n = document.querySelectorAll(sel).length, t = Date.now();
      if (st.cnt !== n) { st.cnt = n; st.cntAt = t; }
      var base = st.cardAt || st.readyAt || st.t0;
      if (t - base > maxMs) return true;
      return t - st.cntAt >= stableMs && t - base >= minMs;
    }

    function tileOf(el) {
      return el.closest(".flex-justify-between.flex-item-grow") || el.closest(".row") || null;
    }
    // Merchant / offer / expiry from an offer tile; same selectors as the
    // adding phase in content/scraper.js.
    function tileInfo(btn) {
      var tile = tileOf(btn);
      if (!tile) return null;
      var h = tile.querySelector("h3.heading-sans-small-medium span") || tile.querySelector("h3 span") || tile.querySelector("h3");
      var vEl = tile.querySelector(".body.color-text-regular span");
      if (!vEl) {
        var oc = tile.querySelectorAll('[data-testid="overflowTextContainer"]');
        if (oc.length >= 2) vEl = oc[1].querySelector("span") || oc[1];
      }
      var m = text(h);
      if (!m) return null;
      var exp = text(tile.querySelector(".color-status-text-critical")) || UOH.expiryText(tile.textContent);
      return { mk: UOH.compact(m), m: m, v: text(vEl), exp: exp, tile: tile };
    }
    function addButtons() { return Array.prototype.slice.call(document.querySelectorAll(SEL.addBtn)); }

    /* ---------- jobs ---------- */

    function stepDiscover() {
      if (!offersReady()) return;
      var t = Date.now();
      if (!st.step) {
        st.displayed = readDisplayed();
        var combo = document.querySelector(SEL.combo);
        if (!combo) { done({ displayed: st.displayed, options: [], optId: viewAllOptId() }); return; }
        progress("Reading your cards");
        click(combo);
        st.step = "list"; st.at = t;
        return;
      }
      var lb = listbox();
      var opts = lb ? lb.querySelectorAll('[role="option"]') : [];
      if (opts.length) {
        var out = Array.prototype.map.call(opts, function (o) {
          return { testid: o.getAttribute("data-testid") || "", id: o.id || "", aria: o.getAttribute("aria-label") || "",
                   name: text(o.querySelector(SEL.name)), digits: text(o.querySelector(SEL.num)), text: text(o) };
        });
        closeSwitcher();
        done({ displayed: st.displayed, options: out, optId: viewAllOptId() });
        return;
      }
      if (t - st.at > 5000) {
        if (!st.retried) { st.retried = true; st.step = null; return; }
        fail("switcher-empty");
      }
    }

    function closeSwitcher() {
      var combo = document.querySelector(SEL.combo);
      if (!combo) return;
      combo.dispatchEvent(new KeyboardEvent("keydown", { key: "Escape", code: "Escape", keyCode: 27, bubbles: true }));
      if (combo.getAttribute("aria-expanded") === "true") click(combo);
    }

    // The "View All" link on /offers names the displayed card's account id.
    function viewAllOptId() {
      var a = document.querySelector('a[href*="/offers/enrolled?opaqueAccountId="]');
      var m = a && (a.getAttribute("href") || "").match(/opaqueAccountId=([^&#]+)/);
      return m ? decodeURIComponent(m[1]) : null;
    }

    // Spike diagnostics: is this hidden page rendering, and what does it see?
    function stepProbe() {
      var t = Date.now();
      if (!st.rafStarted) {
        st.rafStarted = true;
        var loop = function () { rafCount++; requestAnimationFrame(loop); };
        requestAnimationFrame(loop);
      }
      if (!st.lastProbe || t - st.lastProbe >= 2000) {
        st.lastProbe = t;
        post({ t: "PROBE", data: {
          s: Math.round((t - st.t0) / 1000), vis: document.visibilityState, focus: document.hasFocus(),
          raf: rafCount, addButtons: document.querySelectorAll(SEL.addBtn).length,
          success: document.querySelectorAll(SEL.success).length, card: readDisplayed().digits,
          path: location.pathname
        } });
      }
      if (t - st.t0 >= (job.seconds || 60) * 1000) done({});
    }

    function stepScan() {
      if (!offersReady() || !sameLogin() || !ensureCard(job.card)) return;
      // Scrolling loads more tiles on a visible page; in a hidden tab it's harmless.
      try { window.scrollTo(0, document.body.scrollHeight); } catch (e) {}
      if (!settled(SEL.addBtn, 2000, 3000, 20000)) { progress("Reading offers on ••" + job.card.digits); return; }
      var items = [], seen = {};
      addButtons().forEach(function (b) {
        var i = tileInfo(b);
        if (!i || seen[i.mk + "|" + i.v]) return;
        seen[i.mk + "|" + i.v] = true;
        items.push({ mk: i.mk, m: i.m, v: i.v, exp: i.exp });
      });
      done({ items: items, buttons: addButtons().length });
    }

    function stepAdd() {
      if (!offersReady() || !sameLogin() || !ensureCard(job.card)) return;
      var t = Date.now();
      if (!st.adding) {
        if (!settled(SEL.addBtn, 2000, 3000, 20000)) return;
        st.adding = true;
        st.keys = {};
        (job.keys || []).forEach(function (k) { st.keys[k] = true; });
        st.total = Object.keys(st.keys).length;
        st.tried = {}; st.added = []; st.failed = []; st.miss = 0; st.nextAt = 0; st.pending = null;
      }
      if (st.pending) {
        var p = st.pending;
        // Confirmed when the tile shows the success check, or its add button
        // is gone and no add button with the same merchant and offer is left.
        var ok = (p.tile && p.tile.isConnected && p.tile.querySelector(SEL.success)) ||
                 (!p.btn.isConnected && !findButton(p.mk, p.v));
        if (ok) {
          st.added.push(p.mk);
          st.pending = null; st.miss = 0;
          st.nextAt = t + 800 + Math.floor(Math.random() * 700);
          progress("Added " + st.added.length + " of " + st.total + " on ••" + job.card.digits);
        } else if (t - p.at > 10000) {
          st.failed.push(p.mk);
          st.pending = null;
          st.nextAt = t + 1500;
          if (++st.miss >= 3) finishAdd(true);
        }
        return;
      }
      if (t < st.nextAt) return;
      var btns = addButtons(), next = null;
      for (var i = 0; i < btns.length; i++) {
        var info = tileInfo(btns[i]);
        if (info && st.keys[info.mk] && !st.tried[info.mk + "|" + info.v]) { next = info; next.btn = btns[i]; break; }
      }
      if (!next) { finishAdd(false); return; }
      st.tried[next.mk + "|" + next.v] = true;
      st.pending = { mk: next.mk, v: next.v, btn: next.btn, tile: next.tile, at: t };
      try { next.btn.scrollIntoView({ block: "center" }); } catch (e) {}
      click(next.btn);
    }

    function findButton(mk, v) {
      var btns = addButtons();
      for (var i = 0; i < btns.length; i++) {
        var info = tileInfo(btns[i]);
        if (info && info.mk === mk && info.v === v) return btns[i];
      }
      return null;
    }

    function finishAdd(stalled) {
      var triedKeys = {};
      Object.keys(st.tried).forEach(function (k) { triedKeys[k.split("|")[0]] = true; });
      var gone = Object.keys(st.keys).filter(function (k) { return !triedKeys[k]; });
      done({ added: st.added, failed: st.failed, gone: gone, stalled: stalled });
    }

    function stepHarvest() {
      var t = Date.now();
      var shown = readDisplayed().digits;
      if (!(document.querySelector(SEL.success) || document.querySelector('[data-testid="listViewContainer"]') || shown)) {
        if (t - st.t0 > 20000) fail("not-ready");
        return;
      }
      if (!st.readyAt) st.readyAt = t;
      if (!settled(SEL.success, 1000, 2000, 15000)) { progress("Reading added offers on ••" + job.card.digits); return; }
      if (!sameLogin()) return;
      // A card on screen must be the job's card. The id in the URL is the one
      // the service worker put there, so it only counts when no card shows.
      var idm = location.search.match(/opaqueAccountId=([^&#]+)/);
      var urlOk = idm && job.card.optId && decodeURIComponent(idm[1]) === job.card.optId;
      if (shown ? shown !== job.card.digits : !urlOk) { fail("card-unverified"); return; }
      var card = job.card, recs = {}, n = 0, batch = 0;
      var flush = function () { if (batch) { post({ t: "SAVE", records: recs }); recs = {}; batch = 0; } };
      Array.prototype.forEach.call(document.querySelectorAll(SEL.success), function (icon) {
        var tile = icon;
        for (var i = 0; i < 14 && tile; i++) {
          tile = tile.parentElement;
          if (tile && tile.querySelector("h3.heading-sans-small-medium span")) break;
        }
        if (!tile) return;
        var m = text(tile.querySelector("h3.heading-sans-small-medium span") || tile.querySelector("h3 span"));
        var oc = tile.querySelectorAll('[data-testid="overflowTextContainer"]');
        var v = oc.length >= 2 ? text(oc[1].querySelector("span") || oc[1]) : text(tile.querySelector(".body-1.text-truncate span"));
        if (!m || !v) return;
        var days = text(tile.querySelector(".color-status-text-critical")) || UOH.expiryText(tile.textContent);
        recs["amex_" + card.digits + "_" + m.replace(/\W/g, "")] = {
          m: m, v: v, site: "Amex", status: "added", days: days,
          card: (card.name || "Amex") + " ••" + card.digits, cardId: card.digits, last4: card.digits
        };
        n++;
        if (++batch >= 100) flush();
      });
      flush();
      done({ harvested: n });
    }

    function banner() {
      var host = document.createElement("div");
      host.style.cssText = "all:initial;position:fixed;left:50%;top:10px;transform:translateX(-50%);z-index:2147483647;";
      host.attachShadow({ mode: "open" }).innerHTML =
        '<div style="background:#1a232f;color:#f1f5f9;border:1px solid #2d3a4c;border-radius:8px;padding:8px 12px;' +
        'font:13px -apple-system,BlinkMacSystemFont,Segoe UI,Roboto,Arial,sans-serif;box-shadow:0 8px 24px rgba(0,0,0,.35)">' +
        'Offer Hub is updating your Amex offers in this tab. It closes itself when it finishes.</div>';
      document.documentElement.appendChild(host);
    }
  }
})();
