/*
 * Universal Offer Hub — Chase background-run steps (ISOLATED world)
 * -------------------------------------------------------------------
 * Loaded at document_start on Chase's signed-in pages (/web/auth/…), after
 * lib/offers.js, lib/issuers/chase.js (the parsers) and content/auto-core.js
 * (roles, Web Lock, port, notes, running the bank's autopilot; see there).
 * Chase's site is one page app, so this script moves between its pages by
 * the hash:
 *
 *   seen      the account ids on the overview, or the one in the address
 *   discover  the overview's accounts, then the offers page's "Choose
 *             account" list
 *   add       open the offers page on the card (its account id in the
 *             address, as when you open it yourself), then run "Run Chase
 *             Autopilot" there, the popup button's own code. Two waits are
 *             added around its steps (hold()); its code is not changed.
 */
(function () {
  "use strict";
  var PAGE = self.UOH_AUTO_PAGE, C = self.UOH_ISSUERS.Chase;
  var text = PAGE.text, click = PAGE.click;

  var SEL = {
    account: 'button[data-testid^="accounts-name-link-button-"]',
    offersEntry: '[data-testid="ovd-cta-flag"], [data-testid="offer-carousel-header-container"]',
    trigger: 'button[data-testid="account-selector-trigger"]',
    sheet: '#accountSelectorSheet, [data-testid="account-selector-sheet"]',
    option: 'li[role="option"]',
    sheetClose: 'button[aria-label="Select here to close."]',
    tile: '[data-cy="commerce-tile"]',
    added: '[data-testid="offer-tile-alert-container-success"]',
    wallet: '[data-testid="wallet-tile-button"]',
    errorBox: '[data-testid="error-banner-container"]',
    tryAgain: '[data-testid="error-banner-try-again-link"]',
    backNav: '#mds-secondary-back-navbar',
    timeout: '#octagonSessionTimeoutDialogue',
    panel: "chase-autopilot-ui"
  };
  var OVERVIEW = "#/dashboard/overview", HUB = "#/dashboard/merchantOffers/offer-hub";

  // The open job and its state, set on every tick (content/auto-core.js).
  var job = null, st = null;
  var done, fail, progress, autopilot;

  function all(sel, root) { return Array.prototype.slice.call((root || document).querySelectorAll(sel)); }
  function idOf(btn) { return ((btn.getAttribute("data-testid") || "").match(/(\d+)$/) || [])[1] || ""; }
  function onHub() { return /merchantOffers\/offer-hub/i.test(location.hash); }

  // The overview's accounts, once each: [{ id, label }].
  function overviewAccounts() {
    var out = [], ids = {};
    all(SEL.account).forEach(function (b) {
      var id = idOf(b);
      if (id && !ids[id]) { ids[id] = true; out.push({ id: id, label: text(b) }); }
    });
    return out;
  }

  /* ---------- what can block the page ---------- */

  // Chase's "we'll sign you out" warning: press Stay signed in.
  function staySignedIn() {
    var d = document.querySelector(SEL.timeout), open = d && d.getAttribute("open");
    if (!d || open === null || open === "false") return false;
    var t = Date.now();
    if (st.stayAt && t - st.stayAt < 5000) return true;
    st.stayAt = t;
    var b = findButton(d, /stay signed in/i);
    if (b) click(b);
    return true;
  }
  // A button by its text, inside web components' shadow roots too.
  function findButton(host, re) {
    var roots = [host];
    if (host.shadowRoot) roots.push(host.shadowRoot);
    while (roots.length) {
      var els = all("*", roots.shift());
      for (var i = 0; i < els.length; i++) {
        var el = els[i];
        if ((el.tagName === "BUTTON" || el.getAttribute("role") === "button") && re.test(text(el))) return el;
        if (el.shadowRoot) roots.push(el.shadowRoot);
      }
    }
    return null;
  }

  // "It looks like we're having trouble with Chase Offers." The container
  // is always there; a "Hide" class hides it.
  function errorShown() {
    var box = document.querySelector(SEL.errorBox);
    if (!box || /hide/i.test(box.className || "") || !box.querySelector(SEL.tryAgain)) return false;
    return getComputedStyle(box).display !== "none";
  }

  // True while something blocks the page. The error banner gets 5 s, then
  // Try again, at most twice; then the service worker reloads the tab once.
  function guard() {
    if (staySignedIn()) { progress("Staying signed in"); return true; }
    if (!errorShown()) { if (st.err) st.err.since = 0; return false; }
    var t = Date.now(), e = st.err = st.err || { n: 0, since: 0, at: 0 };
    if (!e.since) e.since = t;
    progress("Chase Offers is having trouble; trying again");
    if (t - e.since < 5000 || t - e.at < 5000) return true;
    if (e.n >= 2) { fail("page-error"); return true; }
    e.n++; e.at = t;
    var a = document.querySelector(SEL.tryAgain);
    if (a) click(a);
    return true;
  }

  /* ---------- discover ---------- */

  function stepDiscover() {
    if (guard()) return;
    var t = Date.now();
    if (!st.accounts) {
      var accts = overviewAccounts();
      if (!accts.length) {
        // A reload can land on the offers page: the accounts are on the overview.
        if (onHub() && !st.toOverview) { st.toOverview = t; location.hash = OVERVIEW; }
        if (t - st.t0 > 30000) fail("no-accounts");
        else progress("Waiting for your accounts");
        return;
      }
      // The accounts come in groups: wait until the list holds still.
      if (st.nAcc !== accts.length) { st.nAcc = accts.length; st.accAt = t; return; }
      if (t - st.accAt < 1500) return;
      st.accounts = accts;
      st.hubAt = t;
      progress("Opening Chase Offers");
      location.hash = HUB;
      return;
    }
    if (!onHub()) {
      // The address didn't take: the overview's offers link, once.
      if (t - st.hubAt > 8000 && !st.entry) {
        st.entry = true;
        var link = document.querySelector(SEL.offersEntry);
        if (link) click(link); else location.hash = HUB;
      }
      if (t - st.hubAt > 30000) fail("no-offers-page");
      return;
    }
    var trig = document.querySelector(SEL.trigger);
    if (!trig) {
      // A login with one card may have no account list; its offers show.
      if (document.querySelector(SEL.tile) && t - st.hubAt > 8000) { finishDiscover([], ""); return; }
      if (t - st.hubAt > 30000) fail("no-offers-page");
      return;
    }
    var sheet = document.querySelector(SEL.sheet), opts = sheet ? all(SEL.option, sheet) : [];
    if (!opts.length) {
      if (st.listAt && t - st.listAt < 4000) return;
      if ((st.opens = (st.opens || 0) + 1) > 3) { fail("account-list-empty"); return; }
      st.listAt = t;
      progress("Reading your cards");
      click(trig);
      return;
    }
    if (st.nOpt !== opts.length) { st.nOpt = opts.length; st.optAt = t; return; }
    if (t - st.optAt < 800) return;
    var options = opts.map(function (o) { return { label: text(o), selected: o.getAttribute("aria-selected") === "true" }; });
    var shown = text(trig);
    closeSheet();
    finishDiscover(options, shown);
  }

  function finishDiscover(options, shown) {
    done({ accounts: st.accounts, options: options, shown: shown, hashId: C.accountIdFromHash(location.hash) });
  }

  function closeSheet() {
    var sheet = document.querySelector(SEL.sheet);
    if (!sheet) return;
    var x = sheet.querySelector(SEL.sheetClose);
    if (x) click(x);
    else sheet.dispatchEvent(new KeyboardEvent("keydown", { key: "Escape", code: "Escape", keyCode: 27, bubbles: true }));
  }

  /* ---------- the card on screen ---------- */

  function findOption(card) {
    var sheet = document.querySelector(SEL.sheet), hits = [];
    all(SEL.option, sheet || document.createElement("i")).forEach(function (o) {
      var p = C.parseAccountLabel(text(o));
      if (p.last4 === card.digits) hits.push({ el: o, name: p.name.toLowerCase() });
    });
    if (hits.length < 2) return hits[0] ? hits[0].el : null;
    var n = String(card.name || "").toLowerCase();
    return (hits.filter(function (h) { return h.name === n; })[0] || hits[0]).el;
  }

  // The offers page on `card`, with its account id in the address bar
  // ("…offer-hub?accountId=…"): the autopilot saves every offer under the id
  // it finds there. First ask for the card's own address. If Chase keeps
  // another account, pick the card in "Choose account" as you would; then
  // the address must name this card before the autopilot starts. If Chase
  // never shows its id, the card is skipped (card-unverified) rather than
  // saved under another card.
  function onCardHub(card) {
    var t = Date.now(), want = HUB + "?accountId=" + card.id;
    if (!onHub() || (!st.asked && C.accountIdFromHash(location.hash) !== card.id)) {
      // Not on the offers page (start, an offer's page), or not asked yet:
      // its address, at most 3 times, 5 s apart.
      if (st.addrAt && t - st.addrAt < 5000) return false;
      if ((st.addrTries = (st.addrTries || 0) + 1) > 3) { fail("no-offers-page"); return false; }
      st.addrAt = t; st.asked = true; st.cardAt = 0;
      progress("Opening ••" + card.digits + " in Chase Offers");
      location.hash = want;
      return false;
    }
    if (t - st.addrAt < 1500) return false;          // Chase settles on the new address
    if (!ensureCard(card)) return false;              // the selector names it (Choose account if not)
    if (C.accountIdFromHash(location.hash) === card.id) return true;
    // The card is on screen but the address names another account or none:
    // Chase may still be updating it after the switch; then write it once more.
    if (!st.fixAt) st.fixAt = t;
    if (t - st.fixAt < 3000) return false;
    if (!st.fixed) { st.fixed = true; st.fixAt = t; location.hash = want; return false; }
    fail("card-unverified");
    return false;
  }

  // The account selector must name `card`; if Chase opened another card,
  // pick it in "Choose account".
  function ensureCard(card) {
    var t = Date.now(), trig = document.querySelector(SEL.trigger);
    var shown = trig ? C.parseAccountLabel(text(trig)) : null;
    var here = shown ? shown.last4 === card.digits : !!document.querySelector(SEL.tile) && t - st.t0 > 5000;
    if (here) {
      if (!st.cardAt) {
        st.cardAt = t;
        if (st.sw) { st.switched = true; st.sw = null; }
        if (document.querySelector(SEL.sheet)) closeSheet();
      }
      return true;
    }
    st.cardAt = 0;
    if (!trig) { if (t - st.t0 > 20000) fail("not-ready"); return false; }
    // A card from another login on screen: the browser signed in elsewhere.
    var login = job.loginDigits || [];
    if (shown.last4 && login.length > 1 && login.indexOf(shown.last4) < 0) { fail("login-changed"); return false; }
    var sw = st.sw = st.sw || { phase: "open", at: 0, tries: 0 };
    if (sw.phase === "open") {
      if (sw.tries >= 3) { fail("switch-failed"); return false; }
      sw.tries++; sw.phase = "pick"; sw.at = t;
      progress("Switching to " + (card.name || "card") + " ••" + card.digits);
      click(trig);
    } else if (sw.phase === "pick") {
      var opt = findOption(card);
      if (opt) { click(opt); sw.phase = "wait"; sw.at = t; }
      else if (t - sw.at > 5000) { closeSheet(); sw.phase = "open"; }
    } else if (t - sw.at > 15000) {
      sw.phase = "open";
    }
    return false;
  }

  // The card's offers have held still for 1.5 s (2.5 s at least after a
  // switch), so the autopilot's first step sees them. No offers after 10 s:
  // start anyway; it reads the Added list.
  function tilesSettled() {
    var t = Date.now(), n = document.querySelectorAll(SEL.tile).length;
    if (st.nTiles !== n) { st.nTiles = n; st.tilesAt = t; }
    if (t - st.cardAt < (st.switched ? 2500 : 0)) return false;
    return n ? t - st.tilesAt >= 1500 : t - st.cardAt > 10000;
  }

  function walletCount() {
    var w = document.querySelector(SEL.wallet);
    return w ? C.walletAdded(w.getAttribute("aria-label")) : null;
  }

  // An offer's own page, which + opens.
  function onOfferPage() { return /offer-activated/i.test(location.hash) || backBarUp(); }
  // Its back bar, which the autopilot presses (content/scraper.js).
  function backBarUp() {
    var nav = document.querySelector(SEL.backNav);
    return !!(nav && nav.getBoundingClientRect().width > 0 && nav.shadowRoot);
  }

  /* ---------- the autopilot's steps ---------- */

  // A background tab draws no frames, so Chase's list may not draw new rows
  // until it hears a scroll event.
  function nudge() {
    try { window.dispatchEvent(new Event("scroll")); document.dispatchEvent(new Event("scroll")); } catch (e) {}
  }

  // Offers the autopilot would still click: tiles without the added check
  // that it hasn't marked as clicked (content/scraper.js, adding phase).
  function toAdd() {
    return all(SEL.tile).filter(function (t) {
      return !t.querySelector(SEL.added) && !t.hasAttribute("data-chase-processed");
    }).length;
  }

  // Holds the autopilot's next step, in its adding phase only (its Added-list
  // phase gets every step):
  //   - an offer's page is up: once its back bar shows (3 s at most), one
  //     step goes through, so the autopilot presses Back once; the next only
  //     after 5 s, if Chase hasn't gone back by then. (Pressed on every step,
  //     Back went past the offers in a slow tab.)
  //   - no offer left to add on screen: Chase may still be drawing the list
  //     after Back, so look again twice, a second apart, before the step that
  //     lets the autopilot decide every offer is added.
  function hold(status) {
    if (!/^(Starting|Adding|Going back)/i.test(status)) return false;
    var t = Date.now(), g = st.gate = st.gate || { backAt: 0, offerAt: 0, empty: 0, looks: 0 };
    if (onOfferPage()) {
      g.empty = 0;
      if (!backBarUp()) {
        if (!g.offerAt) g.offerAt = t;
        return t - g.offerAt < 3000;
      }
      if (g.backAt && t - g.backAt < 5000) return true;
      g.backAt = t;
      return false;
    }
    g.backAt = g.offerAt = 0;
    if (toAdd()) { g.empty = 0; return false; }
    if (!g.empty) { g.empty = g.lookAt = t; g.looks = 0; nudge(); return true; }
    if (g.looks < 2) {
      if (t - g.lookAt >= 1000) { g.looks++; g.lookAt = t; nudge(); }
      return true;
    }
    return false;
  }

  function stepAdd() {
    if (st.go) {
      if (staySignedIn()) { progress("Staying signed in"); return; }
      // Checked on the live runs: Chase's "Added offers" count before the
      // run (the autopilot reads the Added list at the end: harvested), and
      // the account id the autopilot saved under.
      autopilot(SEL.panel, true, hold, function () {
        return { check: { addedBefore: st.wallet0, urlId: C.accountIdFromHash(location.hash), id: job.card.id } };
      });
      return;
    }
    if (guard()) return;
    // Opening the card's address also leaves an offer's page or the Added list.
    if (!onCardHub(job.card)) return;
    if (!tilesSettled()) { progress("Loading offers on ••" + job.card.digits); return; }
    st.wallet0 = walletCount();
    st.go = true;
    autopilot(SEL.panel, true, hold);
  }

  PAGE.start({
    issuer: "Chase",
    label: "Chase",
    spa: true,
    watchTries: 80,          // the overview can take a while to list the accounts
    // The accounts on the overview start a run; on another page, the
    // account in the address.
    seen: function () {
      var ids = overviewAccounts().map(function (a) { return a.id; });
      var h = C.accountIdFromHash(location.hash);
      if (!ids.length && h) ids.push(h);
      return ids.length ? ids : null;
    },
    steps: function (api) {
      done = api.done; fail = api.fail; progress = api.progress; autopilot = api.autopilot;
      return function (j, s) {
        job = j; st = s;
        if (job.kind === "discover") return stepDiscover();
        if (job.kind === "add") return stepAdd();
        fail("unknown-job");
      };
    }
  });
})();
