/*
 * Universal Offer Hub — Popup
 * ----------------------------
 * Responsibilities:
 *   1. Auto-detect the active tab and offer a branded one-tap Run button.
 *   2. Render the cross-source search hub with chips / sort / scoring. The
 *      search engine and record helpers live in lib/offers.js (shared with
 *      the dashboard and the service worker).
 *   3. Persist filter state across reopens (UOH_UIState).
 *   4. The two toggles: offer reminders, and Amex auto-add with its status.
 *
 * Reads come straight from chrome.storage. Writes (clean-up, clear all,
 * settings) are messages to the service worker, the hub's only writer.
 *
 * Storage keys read here:
 *   UOH_Database     map of offer key → offer record (m, v, site, n, t, r, ts, firstSeen, ...)
 *   UOH_LastRunCount last autopilot's added/clipped count
 *   UOH_UIState      last-used filter state (source, type, sort, search, card key)
 *   UOH_Settings     { notifierOff, autoAdd: { Amex }, cards: { "<site>|<cardId>": { nick, rank, ... } } }
 *   UOH_AutoState    last background run summary (session: UOH_Run while one is working)
 */
(function () {
  "use strict";

  var DEFAULT_UI = { source: "ALL", type: "ALL", sort: "best", query: "", card: "ALL" };
  var state = Object.assign({}, DEFAULT_UI);
  var settings = {};
  var activeTab = null;
  var activeSource = null;
  var expiredCount = 0;     // saved offers past their expiry, left out of the list

  /* ---------- DOM helpers ---------- */
  var $ = function (id) { return document.getElementById(id); };
  var escapeHtml = function (s) {
    return String(s == null ? "" : s)
      .replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;").replace(/'/g, "&#39;");
  };

  // In-popup replacement for alert()/confirm(). onOk omitted => alert-style.
  function showDialog(msg, onOk, onCancel) {
    var wrap = document.createElement("div");
    wrap.className = "uoh-dialog";
    wrap.innerHTML = '<div class="uoh-dialog-box"><div class="uoh-dialog-msg"></div><div class="uoh-dialog-btns">'
      + (onOk ? '<button class="btn-ghost" data-act="cancel">Cancel</button>' : "")
      + '<button class="btn-ghost uoh-dialog-ok" data-act="ok">OK</button></div></div>';
    wrap.querySelector(".uoh-dialog-msg").innerText = msg;
    wrap.addEventListener("click", function (e) {
      var act = e.target.getAttribute && e.target.getAttribute("data-act");
      if (!act) return;
      wrap.remove();
      if (act === "ok" && onOk) onOk();
      if (act === "cancel" && onCancel) onCancel();
    });
    document.body.appendChild(wrap);
  }

  function send(msg) {
    return new Promise(function (resolve) {
      chrome.runtime.sendMessage(msg, function (r) {
        void chrome.runtime.lastError;
        resolve(r || {});
      });
    });
  }

  function ago(ts) {
    var s = Math.max(0, Math.round((Date.now() - ts) / 1000));
    if (s < 60) return "just now";
    if (s < 3600) return Math.round(s / 60) + " min ago";
    if (s < 86400) return Math.round(s / 3600) + " h ago";
    return Math.round(s / 86400) + " days ago";
  }

  function openDashboard(hash) {
    var url = chrome.runtime.getURL("dashboard/dashboard.html");
    var target = url + (hash ? "#" + hash : "");
    chrome.tabs.query({ url: url + "*" }, function (tabs) {
      if (tabs && tabs.length) {
        chrome.tabs.update(tabs[0].id, { active: true, url: target });
        chrome.windows.update(tabs[0].windowId, { focused: true });
      } else {
        chrome.tabs.create({ url: target });
      }
      window.close();
    });
  }

  /* ---------- Render: top-of-popup auto-detect card ---------- */
  function renderRunCard() {
    var runCard = $("run-card");
    var quick = $("quick-open");
    if (activeSource) {
      runCard.hidden = false;
      quick.hidden = true;
      runCard.style.setProperty("--site-color", activeSource.color);
      $("run-detected").innerText = "Detected: " + activeSource.name;
      $("run-btn-label").innerText = "Run " + activeSource.shortName + " Autopilot";
      $("run-blurb").innerText = activeSource.blurb;
      $("run-extra").hidden = activeSource.id !== "Amex";
    } else {
      runCard.hidden = true;
      quick.hidden = false;
      var grid = $("quick-open-grid");
      grid.innerHTML = "";
      window.UOH_SOURCES.forEach(function (s) {
        var btn = document.createElement("button");
        btn.className = "quick-open-tile";
        btn.innerHTML = '<span class="dot" style="background:' + s.color + '"></span>'
                      + '<span>' + escapeHtml(s.shortName) + '</span>';
        btn.title = "Open " + s.name;
        btn.addEventListener("click", function () { chrome.tabs.create({ url: s.landingUrl }); });
        grid.appendChild(btn);
      });
    }
  }

  /* ---------- Render: background-run status ---------- */
  function renderAutoStatus() {
    Promise.all([
      chrome.storage.session.get(["UOH_Run"]),
      chrome.storage.local.get(["UOH_AutoState"])
    ]).then(function (r) {
      var run = r[0].UOH_Run, last = (r[1].UOH_AutoState || {}).lastRun;
      var on = !!(settings.autoAdd && settings.autoAdd.Amex);
      var el = $("auto-status");
      var working = run && run.phase !== "done";
      // An auto-add run and a manual Amex run on the same login would click
      // the same offers; while one runs, the Amex card shows its progress.
      var onAmex = activeSource && activeSource.id === "Amex";
      $("run-btn").hidden = !!(working && onAmex);
      $("run-progress").hidden = !(working && onAmex);
      if (working && onAmex) $("run-progress").innerText = "Auto-add: " + (run.status || "starting");
      if (onAmex) $("run-extra").hidden = !!working;

      if (working) {
        el.hidden = false;
        el.innerHTML = escapeHtml("Working: " + (run.status || "starting")) + ' · <button class="link" id="stop-run">Stop</button>';
        $("stop-run").addEventListener("click", function () { send({ type: "UOH_STOP_RUN" }).then(renderAutoStatus); });
      } else if (last) {
        el.hidden = false;
        el.innerText = (last.ok ? "Last run " : "Last run stopped ") + ago(last.endedAt) + ": " + last.note;
      } else if (on) {
        el.hidden = false;
        el.innerText = "Adds offers in a new window the next time you open Amex while signed in.";
      } else {
        el.hidden = true;
      }
      if (!working) chrome.action.setBadgeText({ text: "" });
    });
  }

  /* ---------- Render: source filter chips (one per known source) ---------- */
  function renderSourceChips() {
    var bar = $("source-chips");
    bar.innerHTML = "";
    var chips = [{ id: "ALL", label: "All sources", color: null }].concat(
      window.UOH_SOURCES.map(function (s) { return { id: s.id, label: s.shortName, color: s.color }; })
    );
    chips.forEach(function (c) {
      var btn = document.createElement("button");
      btn.className = "chip" + (state.source === c.id ? " active" : "");
      btn.setAttribute("data-source", c.id);
      btn.innerText = c.label;
      if (c.color) btn.style.setProperty("--chip-color", c.color);
      btn.addEventListener("click", function () {
        state.source = c.id;
        persistUI();
        renderSourceChips();
        rerenderResults();
      });
      bar.appendChild(btn);
    });
  }

  /* ---------- Render: results list ---------- */
  function rerenderResults() {
    chrome.storage.local.get(["UOH_Database", "UOH_LastRunCount"], function (res) {
      var db = res.UOH_Database || {};
      var nowMs = Date.now(), all = Object.values(db);
      // Counted the way the dashboard counts: active offers only (one that
      // ends today counts until midnight), and an offer saved on several
      // cards once. Expired ones stay saved until Clean expired.
      var active = all.filter(function (o) { return UOH.isActive(o, nowMs); });
      var expired = all.length - active.length;

      // Filter by source
      var recs = state.source === "ALL" ? active.slice() : active.filter(function (o) { return o.site === state.source; });

      // Card dropdown: rebuilt from the saved data each render so new cards
      // appear after a run. Scoped to the current source filter.
      renderCardSelect(recs);
      if (state.card !== "ALL") {
        recs = recs.filter(function (o) { return UOH.cardKey(o) === state.card; });
      }

      // Filter by type. We bucket DOLLAR + SPEND_GET together under "$".
      if (state.type !== "ALL") {
        recs = recs.filter(function (o) {
          var t = o.t || "OTHER";
          if (state.type === "DOLLAR") return t === "DOLLAR" || t === "SPEND_GET";
          return t === state.type;
        });
      }

      // Search scoring + AND filter. Card names and nicknames are searchable too.
      var tokens = UOH.tokenize(state.query);
      var items = UOH.mergeDuplicates(recs, { cards: settings.cards }).map(function (r) {
        return { o: r, s: tokens.length ? UOH.scoreOffer(r, tokens, r.cards.map(function (c) { return c.label; }).join(" ")) : 0 };
      });
      if (tokens.length) items = items.filter(function (x) { return x.s > 0; });

      // Sort
      var bestScore = 0;
      items.forEach(function (x) { if (x.s > bestScore) bestScore = x.s; });
      items.sort(function (a, b) {
        if (state.sort === "best" && tokens.length) {
          if (b.s !== a.s) return b.s - a.s;
        }
        if (state.sort === "expiry") {
          // Offers without a parsed expiry sink to the bottom; otherwise the
          // soonest-to-expire wins. Already-expired offers (ts in the past)
          // still surface first so the user can decide whether to drop them.
          var ae = a.o.expiresTs == null ? Infinity : a.o.expiresTs;
          var be = b.o.expiresTs == null ? Infinity : b.o.expiresTs;
          if (ae !== be) return ae - be;
        }
        if (state.sort === "value") {
          return (b.o.n || 0) - (a.o.n || 0);
        }
        if (state.sort === "az") {
          return (a.o.m || "").localeCompare(b.o.m || "");
        }
        if (state.sort === "recent") {
          return (b.o.ts || 0) - (a.o.ts || 0);
        }
        // best-match default tie-breaker: numeric value desc, then merchant
        if ((b.o.n || 0) !== (a.o.n || 0)) return (b.o.n || 0) - (a.o.n || 0);
        return (a.o.m || "").localeCompare(b.o.m || "");
      });

      // Stats
      $("stat-total").innerText = UOH.mergeDuplicates(active, {}).length.toLocaleString();
      $("stat-cards").innerText = new Set(active.map(function (o) { return o.site; })).size;
      $("stat-recent").innerText = res.UOH_LastRunCount || 0;
      $("results-count").innerText = items.length.toLocaleString() + (items.length === 1 ? " offer" : " offers");
      expiredCount = expired;
      $("expired-note").hidden = !expired;
      $("expired-info").textContent = expired.toLocaleString() + " expired hidden ⓘ";

      // List
      var list = $("results");
      if (!items.length) {
        list.innerHTML = '<div class="row-empty">' + (state.query ? "No offers match your search." :
          all.length ? "No active offers here." : "No offers saved yet. Open a supported site and click Run.") + "</div>";
        return;
      }

      list.innerHTML = items.map(function (x) {
        var o = x.o;
        var src = window.UOH_SOURCES.find(function (s) { return s.id === o.site; });
        var bg = src ? src.color : "#475569";
        var typeTxt = (o.t && o.t !== "OTHER") ? '<span class="type-tag">' + escapeHtml(o.t) + "</span>" : "";
        var cardTxt = o.cards.map(function (c) {
          return c.label ? '<span class="card-tag" title="' + escapeHtml(c.label) + '">' + escapeHtml(c.label) + "</span>" : "";
        }).join("");
        var exp = UOH.expiryLabel(o, nowMs);
        var expiryTxt = exp ? '<span class="' + exp.cls + '" title="' + escapeHtml(exp.title) + '">' + escapeHtml(exp.label) + "</span>" : "";
        var newTxt = UOH.isNew(o, nowMs) ? '<span class="new-tag">NEW</span>' : "";
        var isBest = tokens.length && x.s === bestScore && bestScore >= 4;
        return '<div class="row' + (isBest ? " best" : "") + '">'
             + '  <div class="row-info">'
             + '    <div class="row-merchant" title="' + escapeHtml(o.m) + '">' + escapeHtml(o.m) + "</div>"
             + '    <div class="row-meta">'
             + '      <span class="site-tag" style="background:' + bg + '">' + escapeHtml(src ? src.shortName : o.site) + "</span>"
             + newTxt + typeTxt + cardTxt + expiryTxt
             + "    </div>"
             + "  </div>"
             + '  <div class="row-value">' + escapeHtml(o.v) + "</div>"
             + "</div>";
      }).join("");
    });
  }

  function renderCardSelect(items) {
    var sel = $("card-select");
    if (!sel) return;
    var counts = {}, labels = {};
    items.forEach(function (o) {
      if (!o.card && !o.cardId) return;
      var k = UOH.cardKey(o);
      counts[k] = (counts[k] || 0) + 1;
      labels[k] = UOH.cardLabel(o, settings.cards) || k;
    });
    var keys = Object.keys(counts).sort(function (a, b) { return labels[a].localeCompare(labels[b]); });
    if (state.card !== "ALL" && !counts[state.card]) state.card = "ALL";
    sel.innerHTML = '<option value="ALL">All cards</option>' + keys.map(function (k) {
      return '<option value="' + escapeHtml(k) + '">' + escapeHtml(labels[k]) + " (" + counts[k] + ")</option>";
    }).join("");
    sel.value = state.card;
  }

  /* ---------- UI state persistence ---------- */
  function persistUI() { chrome.storage.local.set({ UOH_UIState: state }); }
  function loadUI(cb) {
    chrome.storage.local.get(["UOH_UIState", "UOH_Settings"], function (res) {
      state = Object.assign({}, DEFAULT_UI, res.UOH_UIState || {});
      settings = res.UOH_Settings || {};
      cb && cb();
    });
  }

  /* ---------- Wire up events ---------- */
  function bind() {
    $("run-btn").addEventListener("click", function () {
      if (!activeTab || !activeSource) return;
      // 0) MAIN-world marker: lets the AMEX auto-injected content script tell a
      //    real popup-triggered run apart from passive page-visit auto-injection.
      //    Scraper consumes & deletes it on the first invocation.
      chrome.scripting.executeScript(
        {
          target: { tabId: activeTab.id },
          func: function () { try { sessionStorage.setItem("UOH_PopupTrigger", String(Date.now())); } catch (e) {} },
          world: "MAIN"
        },
        function () {
          // 1) ISOLATED bridge: forwards window.postMessage offers → service worker.
          chrome.scripting.executeScript(
            { target: { tabId: activeTab.id }, files: ["content/bridge.js"] },
            function () {
              if (chrome.runtime.lastError) {
                showDialog("Could not install storage bridge: " + chrome.runtime.lastError.message);
                return;
              }
              // 2) MAIN-world autopilot: needed for Capital One's React-fiber clicks
              //    and its inline onclick="window.c1Clk(...)" handlers. Safe for the
              //    other sites too — they only use plain DOM events.
              chrome.scripting.executeScript(
                { target: { tabId: activeTab.id }, files: ["content/scraper.js"], world: "MAIN" },
                function () {
                  if (chrome.runtime.lastError) {
                    showDialog("Could not start the autopilot: " + chrome.runtime.lastError.message);
                  } else {
                    window.close();
                  }
                }
              );
            }
          );
        }
      );
    });

    $("run-all").addEventListener("click", function () {
      if (!activeTab) return;
      send({ type: "UOH_RUN_NOW", issuer: "Amex", windowId: activeTab.windowId, tabId: activeTab.id }).then(function (r) {
        if (!r.ok) showDialog(r.reason === "running" ? "A background run is already working." : "Couldn't start the background run.");
        renderAutoStatus();
      });
    });

    $("dashboard-btn").addEventListener("click", function () { openDashboard(""); });
    $("card-order-link").addEventListener("click", function () { openDashboard("cards"); });

    $("search").addEventListener("input", function (e) {
      state.query = e.target.value;
      persistUI();
      rerenderResults();
    });

    $("clear-search").addEventListener("click", function () {
      state.query = "";
      $("search").value = "";
      persistUI();
      rerenderResults();
    });

    $("sort-select").addEventListener("change", function (e) {
      state.sort = e.target.value;
      persistUI();
      rerenderResults();
    });

    $("card-select").addEventListener("change", function (e) {
      state.card = e.target.value;
      persistUI();
      rerenderResults();
    });

    $("expired-info").addEventListener("click", function () {
      showDialog(expiredCount.toLocaleString() + (expiredCount === 1 ? " saved offer is" : " saved offers are") +
                 " past the expiry date, so the list and counts leave them out. An offer that ends today still counts until midnight.\n\n" +
                 "They stay saved until you press Clean expired.");
    });

    // The service worker works out the stale set again when it applies the
    // clean, so offers an autopilot refreshed in the meantime are kept.
    $("cleanup-btn").addEventListener("click", function () {
      send({ type: "UOH_CLEAN", dryRun: true }).then(function (c) {
        var n = (c.expired || 0) + (c.unseen || 0);
        if (!n) { showDialog("Nothing to clean up. All saved offers are current."); return; }
        showDialog("Remove " + n + " stale offers?\n\n" +
                   (c.expired || 0) + " past their expiry date\n" +
                   (c.unseen || 0) + " not seen on the latest run of their card\n\n" +
                   "Tip: run the autopilot on every card first so current offers are refreshed.", function () {
          send({ type: "UOH_CLEAN" }).then(rerenderResults);
        });
      });
    });

    $("type-chips").addEventListener("click", function (e) {
      var btn = e.target.closest(".chip"); if (!btn) return;
      state.type = btn.getAttribute("data-type");
      Array.from(this.querySelectorAll(".chip")).forEach(function (c) {
        c.classList.toggle("active", c === btn);
      });
      persistUI();
      rerenderResults();
    });

    $("export-btn").addEventListener("click", function () {
      chrome.storage.local.get(["UOH_Database", "UOH_Categories"], function (res) {
        var arr = Object.values(res.UOH_Database || {});
        if (!arr.length) { showDialog("No saved offers yet."); return; }
        var cats = res.UOH_Categories || {};
        var csv = UOH.toCsv(arr, {
          now: Date.now(), cards: settings.cards,
          categoryOf: self.UOH_CATS ? function (o) { return UOH_CATS.categorize(o.m, o.v, cats); } : null
        });
        var fname = "universal_offer_hub_" + new Date().toISOString().slice(0, 10) + ".csv";
        var blob = new Blob([csv], { type: "text/csv;charset=utf-8" });
        var a = document.createElement("a");
        a.href = URL.createObjectURL(blob);
        a.download = fname;
        a.click();
      });
    });

    // Clear all ALWAYS wipes the whole hub, whatever source/card filter is
    // selected, so there is one guaranteed way back to a clean slate.
    // Settings (toggles, card nicknames and order) are kept.
    $("reset-source").addEventListener("click", function () {
      chrome.storage.local.get(["UOH_Database"], function (res) {
        var n = Object.keys(res.UOH_Database || {}).length;
        showDialog("Delete all " + n + " saved offers from every card and source? This can't be undone.", function () {
          // If a live-file folder is set up, ask for write access from this
          // click (only a page can ask) so the wipe reaches offers.json too.
          var grant = self.UOH_LIVE ? UOH_LIVE.getDir().then(function (dir) {
            if (!dir) return null;
            return dir.requestPermission({ mode: "readwrite" }).catch(function () { return null; });
          }).catch(function () { return null; }) : Promise.resolve(null);
          grant.then(function () { return send({ type: "UOH_CLEAR_ALL" }); }).then(function (r) {
            if (r && r.live && r.live !== "ok" && r.live !== "off") {
              showDialog("Your live-file folder still has the old offers.json and offers.csv, because Chrome didn't allow " +
                         "writing to it. Delete those two files, or open the dashboard and click Keep updating.");
            }
            state = Object.assign({}, DEFAULT_UI);
            $("search").value = "";
            $("sort-select").value = state.sort;
            Array.from($("type-chips").querySelectorAll(".chip")).forEach(function (c) {
              c.classList.toggle("active", c.getAttribute("data-type") === "ALL");
            });
            renderSourceChips();
            rerenderResults();
            renderAutoStatus();
          });
        });
      });
    });

    // Offer-reminder toggle: UOH_Settings.notifierOff, read by the service
    // worker before deciding whether to inject the toast.
    var notifierToggle = $("notifier-toggle");
    notifierToggle.checked = !settings.notifierOff;
    notifierToggle.addEventListener("change", function (e) {
      send({ type: "UOH_PATCH_SETTINGS", patch: { notifierOff: !e.target.checked } });
    });

    // Amex auto-add toggle: UOH_Settings.autoAdd.Amex. Off by default; when
    // off, nothing is ever automated. Turning it on explains what will happen.
    var autoToggle = $("autoadd-toggle");
    autoToggle.checked = !!(settings.autoAdd && settings.autoAdd.Amex);
    autoToggle.addEventListener("change", function (e) {
      if (!e.target.checked) {
        send({ type: "UOH_PATCH_SETTINGS", patch: { autoAdd: { Amex: false } } }).then(renderAutoStatus);
        return;
      }
      showDialog("When you open Amex while signed in, Offer Hub opens the offers page in a new window, adds every offer " +
                 "to your cards (top card first) and closes the window when it's done, at most once every 2 hours per login.\n\n" +
                 "The first time, it reads your cards and opens Cards so you choose which cards get offers and their order. " +
                 "It asks again only when a new card shows up.",
        function () { send({ type: "UOH_PATCH_SETTINGS", patch: { autoAdd: { Amex: true } } }).then(renderAutoStatus); },
        function () { autoToggle.checked = false; });
    });

    // Live refresh while autopilots write (popup stays open), and while a
    // background run reports progress.
    chrome.storage.onChanged.addListener(function (changes, area) {
      if (area === "local" && changes.UOH_Settings) {
        settings = changes.UOH_Settings.newValue || {};
        rerenderResults();
        renderAutoStatus();
      }
      if (area === "local" && (changes.UOH_Database || changes.UOH_LastRunCount)) rerenderResults();
      if ((area === "session" && changes.UOH_Run) || (area === "local" && changes.UOH_AutoState)) renderAutoStatus();
    });
  }

  /* ---------- Init ---------- */
  loadUI(function () {
    $("search").value = state.query || "";
    $("sort-select").value = state.sort || "best";
    Array.from($("type-chips").querySelectorAll(".chip")).forEach(function (c) {
      c.classList.toggle("active", c.getAttribute("data-type") === state.type);
    });
    renderSourceChips();
    chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
      activeTab = tabs && tabs[0] ? tabs[0] : null;
      activeSource = activeTab ? window.UOH_detectSource(activeTab.url) : null;
      renderRunCard();
      bind();
      rerenderResults();
      renderAutoStatus();
    });
  });
})();
