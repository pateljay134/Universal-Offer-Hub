/*
 * Universal Offer Hub — Popup
 * ----------------------------
 * Responsibilities:
 *   1. Auto-detect the active tab and offer a branded one-tap Run button.
 *   2. Render the cross-source search hub with chips / sort / scoring.
 *   3. Persist filter state across reopens (UOH_UIState).
 *
 * Storage keys:
 *   UOH_Database     map of offer key → offer record (m, v, site, n, t, r, ts, status, ...)
 *   UOH_LastRunCount last autopilot's added/clipped count (set by content/scraper.js)
 *   UOH_UIState      last-used filter state (source filter, type filter, sort, search)
 */
(function () {
  "use strict";

  var DEFAULT_UI = { source: "ALL", type: "ALL", sort: "best", query: "", card: "ALL" };
  var state = Object.assign({}, DEFAULT_UI);
  var activeTab = null;
  var activeSource = null;

  /* ---------- DOM helpers ---------- */
  var $ = function (id) { return document.getElementById(id); };
  var escapeHtml = function (s) {
    return String(s == null ? "" : s)
      .replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;").replace(/'/g, "&#39;");
  };

  /* ---------- Safari support ----------
   * Safari ignores scripting's `world` option (and the manifest content_scripts
   * `world` key), and its extension popovers don't reliably show alert() /
   * confirm(). Detect it from the extension's own URL scheme. */
  var IS_SAFARI = String(chrome.runtime.getURL("")).indexOf("safari-web-extension://") === 0;
  if (IS_SAFARI && /iPhone|iPad|iPod/.test(navigator.userAgent)) document.documentElement.classList.add("uoh-ios");

  // In-popup replacement for alert()/confirm(). onOk omitted => alert-style.
  function showDialog(msg, onOk) {
    var wrap = document.createElement("div");
    wrap.className = "uoh-dialog";
    wrap.innerHTML = '<div class="uoh-dialog-box"><div class="uoh-dialog-msg"></div><div class="uoh-dialog-btns">'
      + (onOk ? '<button class="btn-ghost" data-act="cancel">Cancel</button>' : "")
      + '<button class="btn-ghost uoh-dialog-ok" data-act="ok">OK</button></div></div>';
    wrap.querySelector(".uoh-dialog-msg").innerText = msg;
    wrap.addEventListener("click", function (e) {
      var act = e.target.getAttribute && e.target.getAttribute("data-act");
      if (!act) return;
      wrap.remove();
      if (act === "ok" && onOk) onOk();
    });
    document.body.appendChild(wrap);
  }

  /* ---------- Search engine ----------
   * Goal: "roadrunner", "Road Runner", "Road-Runner", "RoadRunner", "Road & Runner"
   * all return the same offers. So we don't ask the user to use any particular
   * separator — we normalize both sides aggressively before matching.
   *
   * Two flavours of normalization are used together per offer:
   *   normalize()  → camelCase split, lowercase, every non-alphanumeric → space.
   *                  "Road-Runner" / "RoadRunner" both become "road runner".
   *                  Used for whole-token substring search.
   *   compact()    → lowercase + strip every non-alphanumeric.
   *                  "Road Runner" / "Road-Runner" both become "roadrunner".
   *                  Lets a single-token query "roadrunner" hit a multi-word
   *                  merchant "Road Runner".
   *
   * Tokenization mirrors normalize(): the user can type spaces, dashes,
   * ampersands, dots — all are separators. AND semantics still apply across
   * tokens; we just don't surface the `&` operator anywhere. */
  function splitCamelCase(s) { return String(s == null ? "" : s).replace(/([a-z])([A-Z])/g, "$1 $2"); }
  function normalize(s) { return splitCamelCase(s).toLowerCase().replace(/[^a-z0-9]+/g, " ").trim(); }
  function compact(s)   { return String(s == null ? "" : s).toLowerCase().replace(/[^a-z0-9]/g, ""); }

  function tokenize(q) {
    if (!q) return [];
    return normalize(q).split(/\s+/).filter(Boolean);
  }

  // Score an offer against tokens. Each token MUST hit somewhere (AND); the
  // tier scale below ranks merchant matches above value matches above haystack
  // matches, with prefix/whole-string hits worth more than a substring.
  function scoreOffer(o, tokens) {
    if (!tokens.length) return 1;
    var mN = normalize(o.m);
    var vN = normalize(o.v);
    var rN = normalize(o.r || (o.m + " " + o.v + " " + (o.card || "")));
    var mC = compact(o.m);
    var vC = compact(o.v);
    var rC = compact(o.r || (o.m + " " + o.v + " " + (o.card || "")));
    var total = 0;
    for (var i = 0; i < tokens.length; i++) {
      var t = tokens[i], s = 0;
      if (mN === t)                  s = 6;
      else if (mN.indexOf(t) === 0)  s = 5;
      else if (mN.indexOf(t) > -1)   s = 4;
      else if (mC.indexOf(t) > -1)   s = 3; // catches "roadrunner" vs "Road Runner"
      else if (vN.indexOf(t) > -1)   s = 2;
      else if (vC.indexOf(t) > -1)   s = 2;
      else if (rN.indexOf(t) > -1)   s = 1;
      else if (rC.indexOf(t) > -1)   s = 1;
      if (s === 0) return 0; // AND failed
      total += s;
    }
    return total;
  }

  /* ---------- Render: top-of-popup auto-detect card ---------- */
  function renderRunCard() {
    var runCard = $("run-card");
    var quick = $("quick-open");
    if (activeSource) {
      runCard.hidden = false;
      quick.hidden = true;
      runCard.style.setProperty("--site-color", activeSource.color);
      $("run-detected").innerText = "Detected: " + activeSource.name;
      $("run-btn-label").innerText = "Run " + activeSource.shortName + " Autopilot";
      $("run-blurb").innerText = activeSource.blurb;
    } else {
      runCard.hidden = true;
      quick.hidden = false;
      var grid = $("quick-open-grid");
      grid.innerHTML = "";
      window.UOH_SOURCES.forEach(function (s) {
        var btn = document.createElement("button");
        btn.className = "quick-open-tile";
        btn.innerHTML = '<span class="dot" style="background:' + s.color + '"></span>'
                      + '<span>' + escapeHtml(s.shortName) + '</span>';
        btn.title = "Open " + s.name;
        btn.addEventListener("click", function () { chrome.tabs.create({ url: s.landingUrl }); });
        grid.appendChild(btn);
      });
    }
  }

  /* ---------- Render: source filter chips (one per known source) ---------- */
  function renderSourceChips() {
    var bar = $("source-chips");
    bar.innerHTML = "";
    var chips = [{ id: "ALL", label: "All sources", color: null }].concat(
      window.UOH_SOURCES.map(function (s) { return { id: s.id, label: s.shortName, color: s.color }; })
    );
    chips.forEach(function (c) {
      var btn = document.createElement("button");
      btn.className = "chip" + (state.source === c.id ? " active" : "");
      btn.setAttribute("data-source", c.id);
      btn.innerText = c.label;
      if (c.color) btn.style.setProperty("--chip-color", c.color);
      btn.addEventListener("click", function () {
        state.source = c.id;
        persistUI();
        renderSourceChips();
        rerenderResults();
      });
      bar.appendChild(btn);
    });
  }

  /* ---------- Render: results list ---------- */
  function rerenderResults() {
    chrome.storage.local.get(["UOH_Database", "UOH_LastRunCount"], function (res) {
      var db = res.UOH_Database || {};
      var all = Object.values(db);

      // Filter by source
      var items = state.source === "ALL" ? all.slice() : all.filter(function (o) { return o.site === state.source; });

      // Card dropdown: rebuilt from the saved data each render so new cards
      // appear after a run. Scoped to the current source filter.
      renderCardSelect(items);
      if (state.card !== "ALL") {
        items = items.filter(function (o) { return (o.card || "") === state.card; });
      }

      // Filter by type. We bucket DOLLAR + SPEND_GET together under "$".
      if (state.type !== "ALL") {
        items = items.filter(function (o) {
          var t = o.t || "OTHER";
          if (state.type === "DOLLAR") return t === "DOLLAR" || t === "SPEND_GET";
          return t === state.type;
        });
      }

      // Search scoring + AND filter
      var tokens = tokenize(state.query);
      if (tokens.length) {
        items = items.map(function (o) { return { o: o, s: scoreOffer(o, tokens) }; })
                     .filter(function (x) { return x.s > 0; });
      } else {
        items = items.map(function (o) { return { o: o, s: 0 }; });
      }

      // Sort
      var bestScore = 0;
      items.forEach(function (x) { if (x.s > bestScore) bestScore = x.s; });
      items.sort(function (a, b) {
        if (state.sort === "best" && tokens.length) {
          if (b.s !== a.s) return b.s - a.s;
        }
        if (state.sort === "expiry") {
          // Offers without a parsed expiry sink to the bottom; otherwise the
          // soonest-to-expire wins. Already-expired offers (ts in the past)
          // still surface first so the user can decide whether to drop them.
          var ae = a.o.expiresTs == null ? Infinity : a.o.expiresTs;
          var be = b.o.expiresTs == null ? Infinity : b.o.expiresTs;
          if (ae !== be) return ae - be;
        }
        if (state.sort === "value") {
          return (b.o.n || 0) - (a.o.n || 0);
        }
        if (state.sort === "az") {
          return (a.o.m || "").localeCompare(b.o.m || "");
        }
        if (state.sort === "recent") {
          return (b.o.ts || 0) - (a.o.ts || 0);
        }
        // best-match default tie-breaker: numeric value desc, then merchant
        if ((b.o.n || 0) !== (a.o.n || 0)) return (b.o.n || 0) - (a.o.n || 0);
        return (a.o.m || "").localeCompare(b.o.m || "");
      });

      // Stats
      $("stat-total").innerText = all.length;
      $("stat-cards").innerText = new Set(all.map(function (o) { return o.site; })).size;
      $("stat-recent").innerText = res.UOH_LastRunCount || 0;
      $("results-count").innerText = items.length + (items.length === 1 ? " result" : " results");

      // List
      var list = $("results");
      if (!items.length) {
        list.innerHTML = '<div class="row-empty">' + (state.query ? "No offers match your search." : "No offers saved yet. Open a supported site and click Run.") + "</div>";
        return;
      }

      var nowMs = Date.now();
      list.innerHTML = items.map(function (x) {
        var o = x.o;
        var src = window.UOH_SOURCES.find(function (s) { return s.id === o.site; });
        var bg = src ? src.color : "#475569";
        var typeTxt = (o.t && o.t !== "OTHER") ? '<span class="type-tag">' + escapeHtml(o.t) + "</span>" : "";
        var cardTxt = o.card ? '<span class="card-tag" title="' + escapeHtml(o.card) + '">' + escapeHtml(o.card) + "</span>" : "";
        var expiryTxt = "";
        if (o.expiresTs) {
          var msLeft = o.expiresTs - nowMs;
          var daysLeft = Math.floor(msLeft / 86400000);
          var label, cls = "expiry-tag";
          if (msLeft < 0) { label = "Expired"; cls += " expired"; }
          else if (daysLeft === 0) { label = "Expires today"; cls += " soon"; }
          else if (daysLeft === 1) { label = "1 day left"; cls += " soon"; }
          else if (daysLeft <= 7)  { label = daysLeft + " days left"; cls += " soon"; }
          else if (daysLeft <= 30) { label = daysLeft + " days left"; }
          else { label = new Date(o.expiresTs).toLocaleDateString(); }
          var fullTitle = "Expires " + new Date(o.expiresTs).toLocaleDateString();
          expiryTxt = '<span class="' + cls + '" title="' + escapeHtml(fullTitle) + '">' + escapeHtml(label) + '</span>';
        } else if (o.days) {
          // Fall-through for legacy offers saved before expiresTs existed.
          expiryTxt = '<span class="expiry-tag" title="' + escapeHtml(o.days) + '">' + escapeHtml(o.days) + '</span>';
        }
        var isBest = tokens.length && x.s === bestScore && bestScore >= 4;
        return '<div class="row' + (isBest ? " best" : "") + '">'
             + '  <div class="row-info">'
             + '    <div class="row-merchant" title="' + escapeHtml(o.m) + '">' + escapeHtml(o.m) + "</div>"
             + '    <div class="row-meta">'
             + '      <span class="site-tag" style="background:' + bg + '">' + escapeHtml(src ? src.shortName : o.site) + "</span>"
             + typeTxt + cardTxt + expiryTxt
             + "    </div>"
             + "  </div>"
             + '  <div class="row-value">' + escapeHtml(o.v) + "</div>"
             + "</div>";
      }).join("");
    });
  }

  function renderCardSelect(items) {
    var sel = $("card-select");
    if (!sel) return;
    var counts = {};
    items.forEach(function (o) { if (o.card) counts[o.card] = (counts[o.card] || 0) + 1; });
    var cards = Object.keys(counts).sort();
    if (state.card !== "ALL" && !counts[state.card]) state.card = "ALL";
    sel.innerHTML = '<option value="ALL">All cards</option>' + cards.map(function (c) {
      return '<option value="' + escapeHtml(c) + '">' + escapeHtml(c) + " (" + counts[c] + ")</option>";
    }).join("");
    sel.value = state.card;
  }

  /* Stale-offer detection. Every save refreshes `ts`, so after a run the
   * offers still live on that card share a recent ts; anything on the same
   * card with a ts more than 6h older than the card's newest save was not seen
   * on the latest run (expired, removed or used up at the issuer). */
  var STALE_GAP_MS = 6 * 3600 * 1000;
  function findStale(db) {
    var now = Date.now(), newest = {}, out = { expired: [], unseen: [] };
    Object.keys(db).forEach(function (k) {
      var o = db[k], c = o.site + "|" + (o.cardId || o.card || "");
      if ((o.ts || 0) > (newest[c] || 0)) newest[c] = o.ts || 0;
    });
    Object.keys(db).forEach(function (k) {
      var o = db[k], c = o.site + "|" + (o.cardId || o.card || "");
      if (o.expiresTs && o.expiresTs < now) out.expired.push(k);
      else if ((o.ts || 0) < newest[c] - STALE_GAP_MS) out.unseen.push(k);
    });
    return out;
  }

  function csvDate(ts) {
    if (!ts) return "";
    var d = new Date(ts);
    return d.getFullYear() + "-" + ("0" + (d.getMonth() + 1)).slice(-2) + "-" + ("0" + d.getDate()).slice(-2);
  }

  /* ---------- UI state persistence ---------- */
  function persistUI() { chrome.storage.local.set({ UOH_UIState: state }); }
  function loadUI(cb) {
    chrome.storage.local.get(["UOH_UIState"], function (res) {
      state = Object.assign({}, DEFAULT_UI, res.UOH_UIState || {});
      cb && cb();
    });
  }

  /* ---------- Wire up events ---------- */
  function bind() {
    $("run-btn").addEventListener("click", function () {
      if (!activeTab || !activeSource) return;
      // 0) MAIN-world marker: lets the AMEX auto-injected content script tell a
      //    real popup-triggered run apart from passive page-visit auto-injection.
      //    Scraper consumes & deletes it on the first invocation.
      // sessionStorage is per-origin, so on Safari (no `world`) the ISOLATED
      // world writes the same store the scraper reads.
      var marker = {
        target: { tabId: activeTab.id },
        func: function () { try { sessionStorage.setItem("UOH_PopupTrigger", String(Date.now())); } catch (e) {} }
      };
      if (!IS_SAFARI) marker.world = "MAIN";
      chrome.scripting.executeScript(
        marker,
        function () {
          // 1) ISOLATED bridge: forwards window.postMessage offers → chrome.storage.
          chrome.scripting.executeScript(
            { target: { tabId: activeTab.id }, files: ["content/bridge.js"] },
            function () {
              if (chrome.runtime.lastError) {
                showDialog("Could not install storage bridge: " + chrome.runtime.lastError.message);
                return;
              }
              // 2) MAIN-world autopilot: needed for Capital One's React-fiber clicks
              //    and its inline onclick="window.c1Clk(...)" handlers. Safe for the
              //    other sites too — they only use plain DOM events.
              //    Safari has no `world` option: Capital One is loaded through a
              //    <script> tag (web_accessible_resources) so it still runs in
              //    the page's context; every other site runs as a normal
              //    content script, which is all their DOM-only autopilots need.
              var inject;
              if (!IS_SAFARI) {
                inject = { target: { tabId: activeTab.id }, files: ["content/scraper.js"], world: "MAIN" };
              } else if (activeSource.id === "Capital One") {
                inject = {
                  target: { tabId: activeTab.id },
                  func: function (src) {
                    var s = document.createElement("script");
                    s.src = src;
                    s.onload = function () { s.remove(); };
                    (document.head || document.documentElement).appendChild(s);
                  },
                  args: [chrome.runtime.getURL("content/scraper.js")]
                };
              } else {
                inject = { target: { tabId: activeTab.id }, files: ["content/scraper.js"] };
              }
              chrome.scripting.executeScript(inject, function () {
                if (chrome.runtime.lastError) {
                  showDialog("Could not start the autopilot: " + chrome.runtime.lastError.message);
                } else {
                  window.close();
                }
              });
            }
          );
        }
      );
    });

    $("search").addEventListener("input", function (e) {
      state.query = e.target.value;
      persistUI();
      rerenderResults();
    });

    $("clear-search").addEventListener("click", function () {
      state.query = "";
      $("search").value = "";
      persistUI();
      rerenderResults();
    });

    $("sort-select").addEventListener("change", function (e) {
      state.sort = e.target.value;
      persistUI();
      rerenderResults();
    });

    $("card-select").addEventListener("change", function (e) {
      state.card = e.target.value;
      persistUI();
      rerenderResults();
    });

    $("cleanup-btn").addEventListener("click", function () {
      chrome.storage.local.get(["UOH_Database"], function (res) {
        var db = res.UOH_Database || {};
        var st = findStale(db);
        var n = st.expired.length + st.unseen.length;
        if (!n) { showDialog("Nothing to clean up. All saved offers are current."); return; }
        showDialog("Remove " + n + " stale offers?\n\n" +
                   st.expired.length + " past their expiry date\n" +
                   st.unseen.length + " not seen on the latest run of their card\n\n" +
                   "Tip: run the autopilot on every card first so current offers are refreshed.", function () {
          st.expired.concat(st.unseen).forEach(function (k) { delete db[k]; });
          chrome.storage.local.set({ UOH_Database: db }, rerenderResults);
        });
      });
    });

    $("type-chips").addEventListener("click", function (e) {
      var btn = e.target.closest(".chip"); if (!btn) return;
      state.type = btn.getAttribute("data-type");
      Array.from(this.querySelectorAll(".chip")).forEach(function (c) {
        c.classList.toggle("active", c === btn);
      });
      persistUI();
      rerenderResults();
    });

    $("export-btn").addEventListener("click", function () {
      chrome.storage.local.get(["UOH_Database"], function (res) {
        var arr = Object.values(res.UOH_Database || {});
        if (!arr.length) { showDialog("No saved offers yet."); return; }
        var header = ["Merchant", "Offer", "Source", "Card", "Card Last 4", "Type", "Numeric", "Status",
                      "Expires", "Days Left", "Expiry Text", "Channel", "Badge", "First Seen", "Last Seen"];
        var rows = [header.join(",")];
        var nowMs = Date.now();
        arr.forEach(function (o) {
          var last4 = o.last4 || ((o.card || "").match(/••(\d{4,5})$/) || [])[1] || "";
          var daysLeft = o.expiresTs ? Math.floor((o.expiresTs - nowMs) / 86400000) : "";
          var row = [o.m, o.v, o.site, o.card || "", last4, o.t, o.n, o.status || "",
                     csvDate(o.expiresTs), daysLeft, o.days || "", o.channel || "", o.badge || "",
                     csvDate(o.firstSeen), o.ts ? new Date(o.ts).toISOString() : ""];
          rows.push(row.map(function (x) { return '"' + String(x == null ? "" : x).replace(/"/g, '""') + '"'; }).join(","));
        });
        var fname = "universal_offer_hub_" + new Date().toISOString().slice(0, 10) + ".csv";
        var blob = new Blob(["﻿" + rows.join("\n")], { type: "text/csv;charset=utf-8" });
        // iPhone/iPad Safari can't download from an extension popover; hand the
        // file to the share sheet (Save to Files, AirDrop, Mail...) instead.
        if (IS_SAFARI && /iPhone|iPad|iPod/.test(navigator.userAgent) && navigator.canShare) {
          var file = new File([blob], fname, { type: "text/csv" });
          if (navigator.canShare({ files: [file] })) {
            navigator.share({ files: [file], title: fname }).catch(function () {});
            return;
          }
        }
        var a = document.createElement("a");
        a.href = URL.createObjectURL(blob);
        a.download = fname;
        a.click();
      });
    });

    // Clear all ALWAYS wipes the whole hub, whatever source/card filter is
    // selected, so there is one guaranteed way back to a clean slate.
    // Settings (notifier toggle) are kept.
    $("reset-source").addEventListener("click", function () {
      chrome.storage.local.get(["UOH_Database"], function (res) {
        var n = Object.keys(res.UOH_Database || {}).length;
        showDialog("Delete all " + n + " saved offers from every card and source? This can't be undone.", function () {
          chrome.storage.local.remove(["UOH_Database", "UOH_LastRunCount", "UOH_LastRunAt", "UOH_UIState"], function () {
            state = Object.assign({}, DEFAULT_UI);
            $("search").value = "";
            $("sort-select").value = state.sort;
            Array.from($("type-chips").querySelectorAll(".chip")).forEach(function (c) {
              c.classList.toggle("active", c.getAttribute("data-type") === "ALL");
            });
            renderSourceChips();
            rerenderResults();
          });
        });
      });
    });

    // Offer-reminder toggle: persists to UOH_Settings.notifierOff, read by the
    // background service worker before deciding whether to inject the toast.
    var notifierToggle = $("notifier-toggle");
    if (notifierToggle) {
      chrome.storage.local.get(["UOH_Settings"], function (res) {
        var s = res.UOH_Settings || {};
        notifierToggle.checked = !s.notifierOff;
      });
      notifierToggle.addEventListener("change", function (e) {
        chrome.storage.local.get(["UOH_Settings"], function (res) {
          var s = res.UOH_Settings || {};
          s.notifierOff = !e.target.checked;
          chrome.storage.local.set({ UOH_Settings: s });
        });
      });
    }

    // Live-refresh while autopilot writes new offers (popup stays open scenario).
    chrome.storage.onChanged.addListener(function (changes, area) {
      if (area !== "local") return;
      if (changes.UOH_Database || changes.UOH_LastRunCount) rerenderResults();
    });
  }

  /* ---------- Init ---------- */
  loadUI(function () {
    $("search").value = state.query || "";
    $("sort-select").value = state.sort || "best";
    Array.from($("type-chips").querySelectorAll(".chip")).forEach(function (c) {
      c.classList.toggle("active", c.getAttribute("data-type") === state.type);
    });
    renderSourceChips();
    chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
      activeTab = tabs && tabs[0] ? tabs[0] : null;
      activeSource = activeTab ? window.UOH_detectSource(activeTab.url) : null;
      renderRunCard();
      bind();
      rerenderResults();
    });
  });
})();
