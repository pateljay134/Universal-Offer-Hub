/*
 * lib/ai.js against a fake fetch: the request each provider gets (URL,
 * headers, body), how its reply is read, model lists and defaults, and what
 * the chat gets back when a provider fails.
 *   node --test tests/*.test.js
 */
"use strict";
var test = require("node:test");
var assert = require("node:assert/strict");

var NOW = Date.now(), DAY = 86400000;

function load() {
  global.self = global;
  delete require.cache[require.resolve("../lib/offers.js")];
  delete require.cache[require.resolve("../lib/ai.js")];
  require("../lib/offers.js");
  require("../lib/ai.js");
  return { UOH: global.UOH, AI: global.UOH_AI };
}

// Replies in order; records every request.
function fakeFetch(replies) {
  var calls = [];
  global.fetch = function (url, init) {
    init = init || {};
    calls.push({ url: url, headers: init.headers || {}, body: init.body ? JSON.parse(init.body) : null });
    var r = replies[Math.min(calls.length - 1, replies.length - 1)];
    return Promise.resolve({ ok: r.status < 400, status: r.status, text: function () { return Promise.resolve(JSON.stringify(r.body)); } });
  };
  return calls;
}

function rows(UOH) {
  var recs = [
    { m: "Orient Express - Hotel & Train Reservations", v: "Spend $2,000 or more, earn $400 back", site: "Amex", card: "Platinum Card® ••22001", cardId: "22001", ts: NOW, expiresTs: NOW + 60 * DAY },
    { m: "Hyatt: Miraval & Alila", v: "$250 cash back", site: "Chase", card: "Chase ••7319", cardId: "acc1", last4: "7319", ts: NOW, expiresTs: NOW + 40 * DAY },
    { m: "Pizza Hut", v: "10% back", site: "Amex", card: "Platinum Card® ••22001", cardId: "22001", ts: NOW }
  ];
  var out = UOH.mergeDuplicates(recs, {});
  out[0].cat = "Hotels"; out[1].cat = "Hotels"; out[2].cat = "Dining";
  return out;
}

var CATS = ["Hotels", "Travel", "Dining", "Other"];
var PLAN = { brands: ["Hyatt", "Marriott"], keywords: ["hotel"], categories: ["Hotels"] };
var ANSWER = { summary: "Orient Express is the biggest at $400 back (r1).", points: ["**Orient Express**: $400 back on Platinum ••22001", "- Hyatt: $250 on Chase ••7319"], offerIds: ["r1", "r2", "r99"] };

function ask(env, q) {
  var local = env.UOH.readChatMessage(q, null, {}).plan;
  return env.AI.ask(q, rows(env.UOH), { now: NOW }, CATS, { local: local, subject: true, readBack: "Hotels; biggest first" });
}

test("Claude: current API version, JSON through output_config.format, default fallback, refusal handled", async function () {
  var env = load();
  env.AI._setConfig({ provider: "anthropic", keys: { anthropic: "sk-ant-test" }, models: { anthropic: "claude-opus-5-5" } });
  var calls = fakeFetch([
    { status: 200, body: { stop_reason: "end_turn", content: [{ type: "thinking", thinking: "" }, { type: "text", text: JSON.stringify(PLAN) }] } },
    { status: 200, body: { stop_reason: "end_turn", content: [{ type: "text", text: "```json\n" + JSON.stringify(ANSWER) + "\n```" }] } }
  ]);
  var res = await ask(env, "best hotel offer");
  assert.equal(calls.length, 2);
  var c = calls[1];
  assert.equal(c.url, "https://api.anthropic.com/v1/messages");
  assert.equal(c.headers["x-api-key"], "sk-ant-test");
  assert.equal(c.headers["anthropic-version"], "2026-10-21");
  assert.equal(c.headers["anthropic-dangerous-direct-browser-access"], "true");
  assert.equal(c.headers["anthropic-beta"], "server-side-fallback-2026-07-01");
  assert.equal(c.body.model, "claude-opus-5-5");
  assert.equal(c.body.fallbacks, "default");
  assert.equal(c.body.output_config.format.type, "json_schema");
  assert.equal(c.body.output_config.effort, "medium");
  assert.equal(calls[0].body.output_config.effort, "low");
  assert.equal(c.body.temperature, undefined);
  assert.ok(c.body.messages[0].content.indexOf("Platinum Card® ••22001") > -1, "card name and ending are sent");
  assert.equal(res.answer, "Orient Express is the biggest at $400 back.");          // id stripped
  assert.deepEqual(res.points, ["**Orient Express**: $400 back on Platinum ••22001", "- Hyatt: $250 on Chase ••7319"]);
  assert.deepEqual(res.picks.map(function (r) { return r.m.slice(0, 6); }), ["Orient", "Hyatt:"]);   // r99 dropped

  calls = fakeFetch([{ status: 200, body: { stop_reason: "refusal", content: [] } }]);
  env.AI._setConfig({ provider: "anthropic", keys: { anthropic: "k" }, models: { anthropic: "claude-haiku-5-5" } });
  res = await env.AI.ask("what is expiring this week", rows(env.UOH), { now: NOW }, CATS, { local: env.UOH.readChatMessage("hotels", null, {}).plan, subject: false });
  assert.match(res.error, /declined/);
  assert.equal(res.matches.length, 2);                                               // the rules' matches still come back
  assert.equal(calls[0].headers["anthropic-beta"], undefined);                       // no server-side fallback on Haiku
});

test("ChatGPT: chat completions with a strict JSON schema", async function () {
  var env = load();
  env.AI._setConfig({ provider: "openai", keys: { openai: "sk-test" }, models: { openai: "gpt-5" } });
  var calls = fakeFetch([
    { status: 200, body: { choices: [{ message: { content: JSON.stringify(PLAN) } }] } },
    { status: 200, body: { choices: [{ message: { content: JSON.stringify(ANSWER) } }] } }
  ]);
  var res = await ask(env, "best hotel offer");
  var c = calls[1];
  assert.equal(c.url, "https://api.openai.com/v1/chat/completions");
  assert.equal(c.headers.Authorization, "Bearer sk-test");
  assert.equal(c.body.response_format.type, "json_schema");
  assert.equal(c.body.response_format.json_schema.strict, true);
  assert.equal(c.body.messages[0].role, "system");
  assert.equal(res.picks.length, 2);
});

test("Gemini: generateContent with a JSON response schema; key in a header, not the URL", async function () {
  var env = load();
  env.AI._setConfig({ provider: "gemini", keys: { gemini: "AIza-test" }, models: { gemini: "gemini-2.5-flash" } });
  var calls = fakeFetch([
    { status: 200, body: { candidates: [{ content: { parts: [{ text: JSON.stringify(PLAN) }] } }] } },
    { status: 200, body: { candidates: [{ content: { parts: [{ text: JSON.stringify(ANSWER) }] } }] } }
  ]);
  var res = await ask(env, "best hotel offer");
  var c = calls[1];
  assert.equal(c.url, "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent");
  assert.equal(c.headers["x-goog-api-key"], "AIza-test");
  assert.equal(c.url.indexOf("AIza"), -1);
  assert.equal(c.body.generationConfig.responseMimeType, "application/json");
  assert.equal(c.body.generationConfig.responseSchema.type, "OBJECT");
  assert.equal(c.body.generationConfig.responseSchema.properties.points.type, "ARRAY");
  assert.equal(res.points.length, 2);
});

test("a rejected key leaves the matches and says why; the model lists pick sensible defaults", async function () {
  var env = load();
  env.AI._setConfig({ provider: "openai", keys: { openai: "bad" }, models: { openai: "gpt-5" } });
  fakeFetch([{ status: 401, body: { error: { message: "Incorrect API key provided" } } }]);
  var res = await env.AI.ask("what's expiring", rows(env.UOH), { now: NOW }, CATS, { local: env.UOH.readChatMessage("what is expiring in 90 days", null, {}).plan, subject: false });
  assert.equal(res.status, 401); assert.match(res.error, /Incorrect API key/); assert.equal(res.matches.length, 2);

  var P = env.AI.PROVIDERS;
  fakeFetch([{ status: 200, body: { data: [{ id: "gpt-4o-audio-preview", created: 9 }, { id: "gpt-5-mini", created: 8 }, { id: "gpt-5", created: 7 }, { id: "text-embedding-3", created: 10 }] } }]);
  var ids = await P.openai.listModels("k");
  assert.deepEqual(ids, ["gpt-5-mini", "gpt-5"]); assert.equal(P.openai.pick(ids), "gpt-5");
  fakeFetch([{ status: 200, body: { data: [{ id: "claude-sonnet-5-5" }, { id: "claude-opus-5-5" }, { id: "claude-3-haiku-20240307" }] } }]);
  ids = await P.anthropic.listModels("k");
  assert.deepEqual(ids, ["claude-sonnet-5-5", "claude-opus-5-5"]); assert.equal(P.anthropic.pick(ids), "claude-opus-5-5");
  fakeFetch([{ status: 200, body: { models: [
    { name: "models/gemini-2.5-pro", supportedGenerationMethods: ["generateContent"] },
    { name: "models/gemini-3-flash", supportedGenerationMethods: ["generateContent"] },
    { name: "models/text-embedding-004", supportedGenerationMethods: ["embedContent"] },
    { name: "models/gemini-3-pro", supportedGenerationMethods: ["generateContent"] }] } }]);
  ids = await P.gemini.listModels("k");
  assert.deepEqual(ids, ["gemini-3-flash", "gemini-3-pro", "gemini-2.5-pro"]); assert.equal(P.gemini.pick(ids), "gemini-3-flash");
});
