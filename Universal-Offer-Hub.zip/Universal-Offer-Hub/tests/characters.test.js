/*
 * The Ask AI characters (dashboard/characters.js): the twelve the chat's
 * character menu offers, and that each one is drawable and animated.
 *   node --test tests/*.test.js
 */
"use strict";
var test = require("node:test");
var assert = require("node:assert/strict");
var fs = require("fs"), path = require("path");
global.self = global;
require("../dashboard/characters.js");
var C = self.UOH_CHARS;

// Every tag closes, in order, so the browser draws what we wrote.
function balanced(svg) {
  var stack = [];
  (svg.match(/<\/?[a-zA-Z][^>]*>/g) || []).forEach(function (t) {
    var name = /^<\/?([a-zA-Z]+)/.exec(t)[1];
    if (t[1] === "/") assert.equal(stack.pop(), name, "</" + name + "> closes the wrong tag");
    else if (!/\/>$/.test(t)) stack.push(name);
  });
  return stack.length === 0;
}

test("characters: twelve with unique ids, a known default, drawable and animated", function () {
  var css = fs.readFileSync(path.join(__dirname, "../dashboard/characters.css"), "utf8");
  var ids = C.LIST.map(function (c) { return c.id; });
  assert.equal(ids.length, 12);
  assert.equal(new Set(ids).size, 12);
  assert.ok(C.has(C.DEFAULT));
  assert.ok(balanced(C.DEFS));
  C.LIST.forEach(function (c) {
    var svg = C.svg(c.id);
    assert.ok(svg.indexOf('<svg class="uohc uohc-' + c.id + '"') === 0);
    assert.ok(balanced(svg), c.id + " has unbalanced tags");
    (svg.match(/url\(#[\w-]+\)/g) || []).forEach(function (u) {
      assert.ok(C.DEFS.indexOf('id="' + u.slice(5, -1) + '"') > -1, c.id + " uses " + u + ", which DEFS lacks");
    });
    assert.ok(css.indexOf(".uohc-" + c.id + " ") > -1, c.id + " has no motion in characters.css");
    assert.doesNotMatch(svg, /NaN|undefined/);
  });
  assert.equal(C.svg("retired-name"), C.svg(C.DEFAULT));     // a saved id we no longer ship falls back
});
