/*
 * The Claude Desktop plugin file (lib/mcpb.js): built from the repo's own
 * files the way the dashboard builds it, checked by two other zip readers,
 * unpacked, and the plugin started from the unpacked copy the way Claude
 * Desktop starts it.
 *   node --test tests/*.test.js
 */
"use strict";
var test = require("node:test");
var assert = require("node:assert/strict");
var cp = require("child_process"), fs = require("fs"), os = require("os"), path = require("path");
var H = require("./mcp-helpers.js");
var MCPB = require("../lib/mcpb.js");
var PLUGIN = require("../mcp/offer-hub-mcp.js");

var ROOT = path.join(__dirname, "..");
function has(cmd) { return cp.spawnSync("sh", ["-c", "command -v " + cmd]).status === 0; }
function readRepo(p) { return Promise.resolve(fs.readFileSync(path.join(ROOT, p))); }
// [testzip() result, names, {name: text}] as Python's zipfile reads them.
function pyRead(file) {
  var py = cp.spawnSync("python3", ["-I", "-c",
    "import sys, json, zipfile\nz = zipfile.ZipFile(sys.argv[1])\n" +
    "print(json.dumps([z.testzip(), z.namelist(), {n: z.read(n).decode('utf-8', 'replace') for n in z.namelist() if n.endswith('.txt')}]))",
    file], { encoding: "utf8" });
  assert.equal(py.status, 0, py.stderr);
  return JSON.parse(py.stdout);
}

test("Claude Desktop plugin: a valid zip, and the plugin runs from the unpacked copy", { skip: !has("unzip") && "needs unzip" }, async function () {
  var tmp = fs.mkdtempSync(path.join(os.tmpdir(), "uoh-mcpb-"));
  var file = path.join(tmp, MCPB.NAME), out = path.join(tmp, "unpacked");
  fs.writeFileSync(file, await MCPB.build(readRepo, "3.0.0"));

  var t = cp.spawnSync("unzip", ["-t", file], { encoding: "utf8" });
  assert.equal(t.status, 0, t.stdout + t.stderr);
  assert.match(t.stdout, /No errors detected/);
  if (has("python3")) {
    var z = pyRead(file);
    assert.equal(z[0], null);                                              // every CRC checks out
    assert.deepEqual(z[1], ["manifest.json", "mcp/offer-hub-mcp.js", "lib/offers.js", "lib/categories.js"]);
  }
  assert.equal(cp.spawnSync("unzip", ["-q", file, "-d", out]).status, 0);

  var m = JSON.parse(fs.readFileSync(path.join(out, "manifest.json"), "utf8"));
  assert.equal(m.manifest_version, "0.3");
  assert.equal(m.version, "3.0.0");
  assert.equal(m.server.type, "node");
  assert.ok(fs.existsSync(path.join(out, m.server.entry_point)));
  assert.deepEqual(m.server.mcp_config.args, ["${__dirname}/mcp/offer-hub-mcp.js", "--dir", "${user_config.offers_folder}"]);
  assert.equal(m.user_config.offers_folder.type, "directory");
  assert.equal(m.user_config.offers_folder.required, true);
  assert.equal(m.icon, undefined);
  // Claude's install screen lists what the plugin really serves.
  assert.deepEqual(m.tools.map(function (x) { return x.name; }), PLUGIN.TOOLS.map(function (x) { return x.name; }));
  MCPB.FILES.forEach(function (p) {
    assert.ok(fs.readFileSync(path.join(out, p)).equals(fs.readFileSync(path.join(ROOT, p))), p + " copied byte for byte");
  });

  // Claude Desktop replaces ${__dirname} with the unpacked folder and adds --dir with the folder the user picked.
  var s = H.start(H.fixture(), m.server.mcp_config.args[0].replace("${__dirname}", out));
  try {
    var init = await s.call("initialize", { protocolVersion: "2025-06-18", capabilities: {}, clientInfo: { name: "test", version: "1" } });
    assert.equal(init.result.serverInfo.name, "offer-hub");
    s.notify("notifications/initialized");
    var tools = await s.call("tools/list");
    assert.deepEqual(tools.result.tools.map(function (x) { return x.name; }), ["search_offers", "list_cards", "offers_overview"]);
    var r = await s.call("tools/call", { name: "search_offers", arguments: { query: "hotel", sort: "value" } });
    assert.match(H.text(r), /^2 offers match\./);
    assert.match(H.text(r).split("\n")[2], /^Orient Express /);
  } finally { s.close(); }
});

test("Claude Desktop plugin: icon, UTF-8 names and content", { skip: !has("python3") && "needs python3" }, async function () {
  var tmp = fs.mkdtempSync(path.join(os.tmpdir(), "uoh-mcpb-"));
  var png = Uint8Array.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a, 1, 2, 3]);
  var file = path.join(tmp, "icon.mcpb");
  fs.writeFileSync(file, await MCPB.build(readRepo, "3.0.0", png));
  var z = pyRead(file);
  assert.equal(z[0], null);
  assert.equal(z[1][z[1].length - 1], "icon.png");
  var m = JSON.parse(cp.spawnSync("unzip", ["-p", file, "manifest.json"], { encoding: "utf8" }).stdout);
  assert.equal(m.icon, "icon.png");

  file = path.join(tmp, "names.zip");
  fs.writeFileSync(file, MCPB.zip([{ name: "café/notes.txt", data: "Prix: 5 € ••22001" }, { name: "b.txt", data: "" }]));
  z = pyRead(file);
  assert.equal(z[0], null);
  assert.deepEqual(z[1], ["café/notes.txt", "b.txt"]);
  assert.deepEqual(z[2], { "café/notes.txt": "Prix: 5 € ••22001", "b.txt": "" });
});
