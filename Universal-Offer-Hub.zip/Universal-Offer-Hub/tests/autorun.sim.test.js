/*
 * Simulation tests for lib/autorun.js: a fake chrome.* plus a scripted
 * "driver" standing in for the page scripts (content/amex-auto.js,
 * content/chase-auto.js). Checks the run's sequencing (discover -> each card
 * with Add on, top-ranked first, runs the issuer's own autopilot -> finish),
 * the first run that only reads the card list and opens Cards, when the order
 * needs confirming again, the 2-hour gap, and the main stop paths. A stub
 * second issuer shaped like Chase checks the per-issuer parts: toggles, one
 * run at a time, no navigation, the autopilot's pace, page-error reloads.
 *   node --test --test-timeout=30000 tests/*.test.js
 */
"use strict";
var test = require("node:test");
var assert = require("node:assert/strict");

var OFFERS = "https://global.americanexpress.com/offers";
var ENROLLED = "https://global.americanexpress.com/offers/enrolled?opaqueAccountId=BBBB";

function clone(x) { return x === undefined ? x : JSON.parse(JSON.stringify(x)); }
function ev() {
  var fns = [];
  return { addListener: function (f) { fns.push(f); }, fire: function () { var a = arguments; fns.forEach(function (f) { f.apply(null, a); }); } };
}
function tick() { return new Promise(function (r) { setImmediate(r); }); }
async function settle() { for (var i = 0; i < 30; i++) await tick(); }

function makeChrome(local) {
  var store = { local: clone(local || {}), session: {} };
  var calls = [];
  var onChanged = ev();
  function area(name) {
    return {
      get: function (keys) {
        var out = {};
        (Array.isArray(keys) ? keys : [keys]).forEach(function (k) { if (k in store[name]) out[k] = clone(store[name][k]); });
        return Promise.resolve(out);
      },
      set: function (obj) {
        var changes = {};
        Object.keys(obj).forEach(function (k) { changes[k] = { newValue: clone(obj[k]) }; store[name][k] = clone(obj[k]); });
        onChanged.fire(changes, name);
        return Promise.resolve();
      },
      remove: function (keys) {
        (Array.isArray(keys) ? keys : [keys]).forEach(function (k) { delete store[name][k]; });
        return Promise.resolve();
      }
    };
  }
  var tabs = { 1: { id: 1, windowId: 1, url: "https://global.americanexpress.com/overview" } };
  var nextId = 2, ports = [];
  var c = {
    _store: store, _calls: calls, _tabs: tabs, _ports: ports, _injectFails: false,
    storage: { local: area("local"), session: area("session"), onChanged: onChanged },
    tabs: {
      create: function (p) {
        var t = { id: nextId++, windowId: p.windowId, url: p.url };
        tabs[t.id] = t; calls.push(["create", p.url, p.windowId]);
        return Promise.resolve(clone(t));
      },
      update: function (id, p) {
        if (!tabs[id]) return Promise.reject(new Error("no tab"));
        if (p.url) {
          tabs[id].url = p.url; calls.push(["nav", p.url]);
          // The old page goes away: its port disconnects.
          ports.filter(function (pt) { return pt.tabId === id && !pt.dead; }).forEach(function (pt) { pt._disconnect(); });
        }
        return Promise.resolve(clone(tabs[id]));
      },
      get: function (id) { return tabs[id] ? Promise.resolve(clone(tabs[id])) : Promise.reject(new Error("no tab")); },
      reload: function (id) {
        if (!tabs[id]) return Promise.reject(new Error("no tab"));
        calls.push(["reload", id]);
        ports.filter(function (pt) { return pt.tabId === id && !pt.dead; }).forEach(function (pt) { pt._disconnect(); });
        return Promise.resolve();
      },
      remove: function (id) {
        calls.push(["remove", id]);
        delete tabs[id];
        c.tabs.onRemoved.fire(id);
        return Promise.resolve();
      },
      group: function () { calls.push(["group"]); return Promise.resolve(77); },
      ungroup: function () { calls.push(["ungroup"]); return Promise.resolve(); },
      query: function () { return Promise.resolve([]); },
      sendMessage: function (id, m) { calls.push(["notify", id, m.type, m.added, m.scanOnly]); return Promise.resolve(); },
      onUpdated: ev(), onRemoved: ev()
    },
    scripting: {
      executeScript: function (p) {
        calls.push(["inject", p.target.tabId, (p.files || []).join(","), p.world || "ISOLATED"]);
        return c._injectFails ? Promise.reject(new Error("cannot access")) : Promise.resolve([{}]);
      }
    },
    tabGroups: {
      update: function (gid, p) { calls.push(["groupUpdate", p.collapsed]); return Promise.resolve(); },
      query: function () { return Promise.resolve([]); }
    },
    windows: {
      get: function (id) { return Promise.resolve({ id: id }); },
      getLastFocused: function () { return Promise.resolve({ id: 1 }); }
    },
    alarms: { create: function () {}, clear: function () { return Promise.resolve(); }, onAlarm: ev() },
    action: {
      setBadgeText: function (o) { calls.push(["badge", o.text]); return Promise.resolve(); },
      setBadgeBackgroundColor: function () { return Promise.resolve(); }
    },
    runtime: { onConnect: ev(), getURL: function (p) { return "chrome-extension://test/" + p; } }
  };
  return c;
}

// Fresh copies of lib/offers.js, the issuer files and lib/autorun.js bound to
// a fake chrome, in background.js's order.
var FILES = ["../lib/offers.js", "../lib/issuers/amex.js", "../lib/issuers/chase.js", "../lib/autorun.js"];
function load(local) {
  var chrome = makeChrome(local), paces = [];
  globalThis.self = globalThis;
  globalThis.chrome = chrome;
  globalThis.setInterval = function (fn, ms) { paces.push(ms); return paces.length; };   // ticks are sent by hand here
  globalThis.clearInterval = function () {};
  console.log = function () {};
  FILES.forEach(function (f) { delete require.cache[require.resolve(f)]; });
  delete globalThis.UOH; delete globalThis.UOH_ISSUERS; delete globalThis.UOH_AUTO;
  FILES.forEach(function (f) { require(f); });
  var hooks = {
    patchSettings: function (patch) {
      var s = chrome._store.local.UOH_Settings || {};
      Object.keys(patch).forEach(function (k) {
        if (k === "cards") {
          s.cards = s.cards || {};
          Object.keys(patch.cards).forEach(function (ck) { s.cards[ck] = Object.assign({}, s.cards[ck] || {}, patch.cards[ck]); });
        } else s[k] = patch[k];
      });
      return chrome.storage.local.set({ UOH_Settings: s }).then(function () { return { settings: clone(s) }; });
    },
    afterDataChange: function () {}
  };
  UOH_AUTO.init(hooks);
  return { chrome: chrome, A: UOH_AUTO, paces: paces };
}

// The driver side of one page load in the run tab.
function connect(env, tabId) {
  var port = {
    name: "uoh-run", tabId: tabId, inbox: [], dead: false, _m: [], _d: [],
    sender: { tab: { id: tabId }, url: env.chrome._tabs[tabId].url },
    onMessage: { addListener: function (f) { port._m.push(f); } },
    onDisconnect: { addListener: function (f) { port._d.push(f); } },
    postMessage: function (m) { if (m.t !== "TICK") port.inbox.push(m); },
    disconnect: function () { port._disconnect(); },
    _disconnect: function () { if (port.dead) return; port.dead = true; port._d.forEach(function (f) { f(); }); },
    send: function (m) { port._m.forEach(function (f) { f(m); }); }
  };
  env.chrome._ports.push(port);
  env.chrome.runtime.onConnect.fire(port);
  return port;
}
function lastJob(port) {
  var jobs = port.inbox.filter(function (m) { return m.t === "JOB"; });
  return jobs.length ? jobs[jobs.length - 1].job : null;
}
function count(env, kind) { return env.chrome._calls.filter(function (c) { return c[0] === kind; }).length; }
function jobsOf(port, kind) { return port.inbox.filter(function (m) { return m.t === "JOB" && m.job.kind === kind; }).length; }

var OPTIONS = [
  { testid: "simple_switcher_static_option_ALL", aria: "Overview", name: "Overview" },
  { testid: "simple_switcher_product_option_CARD_PRODUCT_AAAA", aria: "Platinum Card® ending in 11111.", name: "Platinum Card®" },
  { testid: "simple_switcher_product_option_CARD_PRODUCT_BBBB", aria: "Blue Cash Everyday® ending in 22222.", name: "Blue Cash Everyday®" },
  { testid: "simple_switcher_product_option_AEXP_PERSONAL_CHECKING_ACCOUNT_cc", aria: "Rewards Checking ending in 3333.", name: "American Express Rewards Checking" }
];
var DASH = "chrome-extension://test/dashboard/dashboard.html#cards";
var RUN_TAB = 2;                                      // the run tab, in the user's window
var CONFIRMED = { UOH_Settings: { autoAdd: { Amex: true }, cards: {
  "Amex|22222": { rank: 0, confirmed: true, login: "11111,22222" },
  "Amex|11111": { rank: 1, confirmed: true, login: "11111,22222" } } } };

async function startRun(env) {
  var r = await env.A.onMessage({ type: "UOH_AMEX_SEEN", digits: "11111", name: "Platinum Card®" },
                                { tab: { id: 1, windowId: 1 } });
  await settle();
  return r;
}

async function discover(env, options) {
  var hello = await env.A.onMessage({ type: "UOH_HELLO" }, { tab: { id: RUN_TAB } });
  assert.deepEqual(hello.role, "run");
  var p1 = connect(env, RUN_TAB);
  await settle();
  p1.send({ t: "LOCKED" });
  var j = lastJob(p1);
  assert.equal(j.kind, "discover");
  p1.send({ t: "DONE", jobId: j.id, result: { displayed: { digits: "11111", name: "Platinum Card®" }, options: options || OPTIONS } });
  await settle();
  return p1;
}

// One card's add job on the connected page: the page asks for the autopilot,
// then reports what it did.
async function runCard(env, port, digits, result) {
  var j = lastJob(port);
  assert.equal(j.kind, "add"); assert.equal(j.card.digits, digits);
  port.send({ t: "AUTOPILOT", jobId: j.id });
  await settle();
  port.send({ t: "DONE", jobId: j.id, result: result || { count: 1, harvested: 1, note: "Done." } });
  await settle();
  return j;
}

test("first run on a login only reads the card list, then opens Cards to pick the cards and their order", async function () {
  var env = load({ UOH_Settings: { autoAdd: { Amex: true } } });
  var r = await startRun(env);
  assert.equal(r.started, true);
  assert.deepEqual(env.chrome._calls[0], ["create", OFFERS, 1]);      // a background tab in the user's window
  assert.ok(env.chrome._calls.some(function (c) { return c[0] === "group"; }));   // in the "Offer Hub" group
  var p = await discover(env);
  assert.equal(jobsOf(p, "add"), 0, "nothing is added before the user confirms");
  assert.equal(count(env, "inject"), 0);
  var cards = env.chrome._store.local.UOH_Settings.cards;
  assert.equal(cards["Amex|11111"].rank, 0);            // card Amex opened first ranks first
  assert.equal(cards["Amex|22222"].rank, 1);
  assert.equal(cards["Amex|11111"].confirmed, false);
  assert.equal(cards["Amex|11111"].name, "Platinum Card®");
  assert.equal(cards["Amex|3333"], undefined);          // checking account skipped
  var st = env.chrome._store.local.UOH_AutoState;
  assert.equal(st.lastRun.ok, true);
  assert.equal(st.lastRun.scanOnly, true);
  assert.equal(st.lastRun.added, 0);
  assert.match(st.lastRun.note, /^Found 2 cards\. Choose which cards get offers and their order in the Cards panel/);
  assert.ok(st.cards["Amex|11111"].doneAt && st.cards["Amex|22222"].doneAt);
  assert.ok(env.chrome._calls.some(function (c) { return c[0] === "remove" && c[1] === RUN_TAB; }));
  assert.ok(env.chrome._calls.some(function (c) { return c[0] === "create" && c[1] === DASH && c[2] === 1; }),
            "Cards opens in the window the user was in");
  assert.ok(env.chrome._calls.some(function (c) { return c[0] === "badge" && c[1] === "!"; }));
  assert.ok(env.chrome._calls.some(function (c) { return c[0] === "notify" && c[1] === 1 && c[4] === true; }));
  assert.equal(env.chrome._store.session.UOH_Run, undefined);

  // Visiting again right away does nothing (2-hour gap per login); the page
  // gets the times for its note.
  var again = await env.A.onMessage({ type: "UOH_AMEX_SEEN", digits: "22222" }, { tab: { id: 1, windowId: 1 } });
  assert.equal(again.started, false); assert.equal(again.reason, "gap");
  assert.equal(again.lastAt, st.cards["Amex|22222"].doneAt);
  assert.equal(again.nextAt - again.lastAt, 2 * 3600 * 1000);
});

test("a first run keeps the order set by hand in the dashboard; only unranked cards go to the bottom", async function () {
  // The user ordered both cards in Cards before auto-add ever saw their login.
  var env = load({ UOH_Settings: { autoAdd: { Amex: true }, cards: {
    "Amex|22222": { rank: 0, nick: "Mom" }, "Amex|11111": { rank: 1 } } } });
  await startRun(env);
  await discover(env);
  var cards = env.chrome._store.local.UOH_Settings.cards;
  assert.equal(cards["Amex|22222"].rank, 0); assert.equal(cards["Amex|11111"].rank, 1);
  assert.equal(cards["Amex|22222"].nick, "Mom");

  // Only 22222 was ordered by hand: 11111 has no rank, so it goes below it.
  env = load({ UOH_Settings: { autoAdd: { Amex: true }, cards: { "Amex|22222": { rank: 0 } } } });
  await startRun(env);
  await discover(env);
  cards = env.chrome._store.local.UOH_Settings.cards;
  assert.equal(cards["Amex|22222"].rank, 0); assert.equal(cards["Amex|11111"].rank, 1);
});

test("with a confirmed order: Run Amex Autopilot runs on each card, top-ranked first; its Added page keeps the tab", async function () {
  var env = load(CONFIRMED);
  await startRun(env);
  var p = await discover(env);
  var j = lastJob(p);
  assert.equal(j.kind, "add"); assert.equal(j.card.digits, "22222");   // rank 0 first, though Amex opened 11111
  assert.equal(j.started, false);
  // The page has the card on screen: the autopilot starts the way the Run button starts it.
  p.send({ t: "AUTOPILOT", jobId: j.id });
  await settle();
  assert.deepEqual(env.chrome._calls.filter(function (c) { return c[0] === "inject"; }), [
    ["inject", RUN_TAB, "content/bridge.js", "ISOLATED"],
    ["inject", RUN_TAB, "content/scraper.js", "MAIN"]
  ]);
  // The autopilot opens the card's Added page itself (a new page load). The
  // tab stays there and the new page gets the same job, marked as started.
  var navs = count(env, "nav");
  env.chrome._tabs[RUN_TAB].url = ENROLLED;
  p._disconnect();
  var p2 = connect(env, RUN_TAB);
  await settle();
  assert.equal(count(env, "nav"), navs, "the service worker doesn't pull the tab back to /offers");
  var j2 = lastJob(p2);
  assert.equal(j2.id, j.id); assert.equal(j2.started, true);
  p2.send({ t: "DONE", jobId: j2.id, result: { count: 2, harvested: 5, saved: 7, note: "Done. 2 added, 5 from history." } });
  await settle();
  // The next card starts on /offers again.
  assert.deepEqual(env.chrome._calls.filter(function (c) { return c[0] === "nav"; }).pop(), ["nav", OFFERS]);
  var p3 = connect(env, RUN_TAB);
  await settle();
  await runCard(env, p3, "11111", { count: 1, harvested: 3, note: "Done. 1 added, 3 from history." });
  var st = env.chrome._store.local.UOH_AutoState;
  assert.equal(st.lastRun.ok, true); assert.equal(st.lastRun.scanOnly, false); assert.equal(st.lastRun.added, 3);
  assert.equal(st.lastRun.note, "3 offers added across 2 cards.");
  var c22 = st.lastRun.cards.filter(function (c) { return c.digits === "22222"; })[0];
  assert.equal(c22.added, 2); assert.equal(c22.harvested, 5); assert.equal(c22.note, "Done. 2 added, 5 from history.");
  assert.ok(env.chrome._calls.some(function (c) { return c[0] === "badge" && c[1] === "+3"; }));
  assert.ok(!env.chrome._calls.some(function (c) { return c[0] === "create" && c[1] === DASH; }), "an adding run doesn't open Cards");

  // A card switched off in Cards gets no job at all.
  env = load({ UOH_Settings: { autoAdd: { Amex: true }, cards: {
    "Amex|22222": { rank: 0, confirmed: true, login: "11111,22222", skip: true },
    "Amex|11111": { rank: 1, confirmed: true, login: "11111,22222" } } } });
  await startRun(env);
  p = await discover(env);
  await runCard(env, p, "11111");
  assert.equal(jobsOf(p, "add"), 1);
  assert.equal(env.chrome._store.local.UOH_AutoState.lastRun.ok, true);
});

test("a card whose autopilot can't run is noted and the run moves on; two in a row stop the run", async function () {
  var env = load(CONFIRMED);
  await startRun(env);
  var p = await discover(env);
  var j = lastJob(p);
  assert.equal(j.card.digits, "22222");
  p.send({ t: "FAIL", jobId: j.id, reason: "switch-failed" });
  await settle();
  await runCard(env, p, "11111");
  var st = env.chrome._store.local.UOH_AutoState;
  assert.equal(st.lastRun.ok, true);
  assert.ok(st.lastRun.notes.indexOf("Amex|22222: switch-failed") > -1);
  assert.equal(st.cards["Amex|22222"].stalledUntil, undefined);

  env = load(CONFIRMED);
  await startRun(env);
  p = await discover(env);
  p.send({ t: "FAIL", jobId: lastJob(p).id, reason: "switch-failed" });
  await settle();
  p.send({ t: "FAIL", jobId: lastJob(p).id, reason: "autopilot-stuck" });
  await settle();
  st = env.chrome._store.local.UOH_AutoState;
  assert.equal(st.lastRun.ok, false);
  assert.match(st.lastRun.note, /two cards in a row/);
  assert.ok(st.cards["Amex|11111"].doneAt);             // it got as far as adding: counts for the 2-hour gap
  assert.ok(env.chrome._calls.some(function (c) { return c[0] === "remove" && c[1] === RUN_TAB; }));
});

test("an autopilot that can't be started fails that card; it is started at most 3 times", async function () {
  var env = load(CONFIRMED);
  env.chrome._injectFails = true;
  await startRun(env);
  var p = await discover(env);
  p.send({ t: "AUTOPILOT", jobId: lastJob(p).id });
  await settle();
  var j = lastJob(p);
  assert.equal(j.card.digits, "11111", "the next card");
  assert.ok(env.chrome._store.session.UOH_Run.notes.indexOf("Amex|22222: autopilot-not-starting") > -1);

  // Reloads that start it again count; the fourth start fails the card.
  env = load(CONFIRMED);
  await startRun(env);
  p = await discover(env);
  var id = lastJob(p).id;
  for (var i = 0; i < 4; i++) { p.send({ t: "AUTOPILOT", jobId: id }); await settle(); }
  assert.equal(count(env, "inject"), 6);                // 3 starts x (bridge + autopilot)
  assert.equal(lastJob(p).card.digits, "11111");
});

test("another account on the same login (checking) neither stops the run nor gets around the 2-hour gap", async function () {
  var env = load(CONFIRMED);
  await startRun(env);
  // Before the card list is read, any ending keeps the run going.
  var r = await env.A.onMessage({ type: "UOH_AMEX_SEEN", digits: "22222" }, { tab: { id: 1, windowId: 1 } });
  assert.equal(r.reason, "running");
  var p = await discover(env);
  r = await env.A.onMessage({ type: "UOH_AMEX_SEEN", digits: "3333" }, { tab: { id: 1, windowId: 1 } });
  assert.equal(r.reason, "running");
  await runCard(env, p, "22222");
  await runCard(env, p, "11111");
  assert.equal(env.chrome._calls.filter(function (c) { return c[0] === "create" && c[1] === OFFERS; }).length, 1);
  r = await env.A.onMessage({ type: "UOH_AMEX_SEEN", digits: "3333" }, { tab: { id: 1, windowId: 1 } });
  assert.equal(r.reason, "gap");
});

test("Stop counts as the login's run; a run whose page never loaded may retry after 15 minutes", async function () {
  var real = Date.now, later = function () { return real() + 16 * 60 * 1000; };
  var env = load({ UOH_Settings: { autoAdd: { Amex: true } } });
  await startRun(env);
  await env.A.onMessage({ type: "UOH_STOP_RUN" }, {});
  await settle();
  assert.ok(env.chrome._store.local.UOH_AutoState.cards["Amex|11111"].doneAt);
  Date.now = later;
  try {
    var r = await env.A.onMessage({ type: "UOH_AMEX_SEEN", digits: "11111" }, { tab: { id: 1, windowId: 1 } });
    assert.equal(r.reason, "gap");
  } finally { Date.now = real; }

  // Signed out before the offers page reported its lock: only triedAt.
  env = load({ UOH_Settings: { autoAdd: { Amex: true } } });
  await startRun(env);
  env.chrome._tabs[2].url = "https://www.americanexpress.com/en-us/account/login";
  connect(env, 2);
  await settle();
  var c = env.chrome._store.local.UOH_AutoState.cards["Amex|11111"];
  assert.ok(c.triedAt && !c.doneAt);
  Date.now = later;
  try {
    r = await env.A.onMessage({ type: "UOH_AMEX_SEEN", digits: "11111" }, { tab: { id: 1, windowId: 1 } });
    assert.equal(r.started, true);
  } finally { Date.now = real; }
});

test("stop paths: signed out, tab closed, toggle off, another login", async function () {
  // signed out: the run tab lands somewhere other than the offers pages
  var env = load({ UOH_Settings: { autoAdd: { Amex: true } } });
  await startRun(env);
  env.chrome._tabs[2].url = "https://www.americanexpress.com/en-us/account/login";
  connect(env, 2);
  await settle();
  assert.match(env.chrome._store.local.UOH_AutoState.lastRun.note, /signed out/);

  // the user closes the Offer Hub tab
  env = load({ UOH_Settings: { autoAdd: { Amex: true } } });
  await startRun(env);
  connect(env, 2); await settle();
  env.chrome.tabs.remove(2); await settle();
  assert.match(env.chrome._store.local.UOH_AutoState.lastRun.note, /closed/);

  // the toggle is turned off mid-run
  env = load({ UOH_Settings: { autoAdd: { Amex: true } } });
  await startRun(env);
  connect(env, 2); await settle();
  await env.chrome.storage.local.set({ UOH_Settings: { autoAdd: { Amex: false } } });
  await settle();
  assert.match(env.chrome._store.local.UOH_AutoState.lastRun.note, /turned off/);

  // the browser signs into another login while a run adds
  env = load(CONFIRMED);
  await startRun(env);
  await discover(env);
  var r = await env.A.onMessage({ type: "UOH_AMEX_SEEN", digits: "99999" }, { tab: { id: 1, windowId: 1 } });
  await settle();
  assert.ok(env.chrome._calls.some(function (c) { return c[0] === "remove" && c[1] === RUN_TAB; }));
  assert.equal(r.started, true);                         // the new login gets its own run
  assert.equal(env.chrome._calls.filter(function (c) { return c[0] === "create" && c[1] === OFFERS; }).length, 2);
});

test("auto-add off: Amex pages get no role and nothing starts", async function () {
  var env = load({ UOH_Settings: {} });
  var hello = await env.A.onMessage({ type: "UOH_HELLO" }, { tab: { id: 1 } });
  assert.equal(hello.role, "none");
  var r = await env.A.onMessage({ type: "UOH_AMEX_SEEN", digits: "11111" }, { tab: { id: 1, windowId: 1 } });
  assert.equal(r.started, false); assert.equal(r.reason, "off");
  assert.equal(count(env, "create"), 0);
});

test("the order is confirmed again only for a new card; a card that's gone doesn't ask", async function () {
  // A confirmed login lost a card (44444 closed): straight to adding.
  var env = load({ UOH_Settings: { autoAdd: { Amex: true }, cards: {
    "Amex|11111": { rank: 0, confirmed: true, login: "11111,22222,44444" },
    "Amex|22222": { rank: 1, confirmed: true, login: "11111,22222,44444" },
    "Amex|44444": { rank: 2, confirmed: true, login: "11111,22222,44444" } } } });
  await startRun(env);
  var p = await discover(env);
  var cards = env.chrome._store.local.UOH_Settings.cards;
  assert.equal(cards["Amex|11111"].confirmed, true);
  assert.equal(cards["Amex|22222"].confirmed, true);
  assert.equal(cards["Amex|11111"].rank, 0); assert.equal(cards["Amex|22222"].rank, 1);
  assert.equal(cards["Amex|11111"].login, "11111,22222");
  assert.equal(lastJob(p).kind, "add"); assert.equal(lastJob(p).card.digits, "11111");

  // A known, confirmed card that moved in from another login doesn't ask either; it goes to the bottom.
  env = load({ UOH_Settings: { autoAdd: { Amex: true }, cards: {
    "Amex|11111": { rank: 0, confirmed: true, login: "11111" },
    "Amex|22222": { rank: 0, confirmed: true, login: "22222,99999" } } } });
  await startRun(env);
  p = await discover(env);
  cards = env.chrome._store.local.UOH_Settings.cards;
  assert.equal(cards["Amex|22222"].confirmed, true);
  assert.ok(cards["Amex|22222"].rank > cards["Amex|11111"].rank);
  assert.equal(cards["Amex|22222"].login, "11111,22222");
  assert.equal(lastJob(p).kind, "add"); assert.equal(lastJob(p).card.digits, "11111");

  // A new card on a confirmed login: read the list only, only the new card is unconfirmed, and Cards opens.
  env = load({ UOH_Settings: { autoAdd: { Amex: true }, cards: {
    "Amex|11111": { rank: 0, confirmed: true, login: "11111" } } } });
  await startRun(env);
  p = await discover(env);
  cards = env.chrome._store.local.UOH_Settings.cards;
  assert.equal(cards["Amex|11111"].confirmed, true);
  assert.equal(cards["Amex|22222"].confirmed, false);
  assert.equal(cards["Amex|22222"].rank, 1);                       // new: goes to the bottom
  assert.equal(jobsOf(p, "add"), 0);
  assert.ok(env.chrome._calls.some(function (c) { return c[0] === "create" && c[1] === DASH; }));
});

test("a run that goes past its 40-minute cap says 40 minutes", async function () {
  var real = Date.now;
  var env = load({ UOH_Settings: { autoAdd: { Amex: true } } });
  await startRun(env);
  connect(env, 2); await settle();
  Date.now = function () { return real() + 41 * 60 * 1000; };
  try {
    env.chrome.alarms.onAlarm.fire({ name: "uoh-run" });
    await settle();
  } finally { Date.now = real; }
  assert.equal(env.chrome._store.local.UOH_AutoState.lastRun.note, "Took longer than 40 minutes");
});

/* ---------- a second issuer ---------- */

// An issuer shaped like Chase: a one-page app the run never navigates (it
// reloads the tab to recover), an autopilot with its own pace, and every card
// can hold every offer.
var BANK_TAB = 50;
var BANK_HOME = "https://secure07.bank.example/app#/home";
var BANK_ACCOUNTS = [{ id: "900", last4: "1234", name: "Gold" }, { id: "901", last4: "5678", name: "Debit" },
                     { id: "902", last4: "9012", name: "Business" }];
function addBank(env) {
  globalThis.UOH_ISSUERS.Bank = {
    id: "Bank", label: "Bank",
    siteRe: /(^|\.)bank\.example$/i,
    hostRe: /^https:\/\/[a-z0-9-]+\.bank\.example\//i,
    pageRe: /^https:\/\/[a-z0-9-]+\.bank\.example\/app/i,
    spa: true, ordered: false, autopilotMs: 300,
    startUrl: function (origin) { return (origin || "https://secure.bank.example") + "/app#/home"; },
    route: function () { return null; },
    cards: function (result) {
      var cards = (result.accounts || []).map(function (a) {
        return { key: "Bank|" + a.id, id: a.id, digits: a.last4, name: a.name };
      });
      return { cards: cards, loginIds: cards.map(function (c) { return c.id; }), initialId: result.shownId || "", notes: [] };
    }
  };
  env.chrome._tabs[BANK_TAB] = { id: BANK_TAB, windowId: 1, url: BANK_HOME };
}
function bankSeen(env) {
  return env.A.onMessage({ type: "UOH_SEEN", issuer: "Bank", ids: ["900", "901", "902"] },
                         { tab: { id: BANK_TAB, windowId: 1, url: BANK_HOME } });
}

// Connects the run tab's page and finishes its discover job.
async function bankDiscover(env) {
  var tabId = env.chrome._store.session.UOH_Run.tabId;
  var hello = await env.A.onMessage({ type: "UOH_HELLO", issuer: "Bank" }, { tab: { id: tabId } });
  assert.equal(hello.role, "run");
  var p = connect(env, tabId);
  await settle();
  p.send({ t: "LOCKED" });
  var j = lastJob(p);
  assert.equal(j.kind, "discover");
  p.send({ t: "DONE", jobId: j.id, result: { accounts: BANK_ACCOUNTS, shownId: "900" } });
  await settle();
  return p;
}
function bankConfirmed(skip902) {
  var login = "900,901,902";
  return { UOH_Settings: { autoAdd: { Bank: true }, cards: {
    "Bank|901": { rank: 0, confirmed: true, login: login },
    "Bank|900": { rank: 1, confirmed: true, login: login },
    "Bank|902": { rank: 2, confirmed: true, login: login, skip: !!skip902 } } } };
}

test("each issuer has its own toggle: page roles and sign-ins follow it", async function () {
  var bankPage = { tab: { id: BANK_TAB, windowId: 1, url: BANK_HOME } };
  var env = load({ UOH_Settings: { autoAdd: { Amex: true } } });
  addBank(env);
  assert.equal((await env.A.onMessage({ type: "UOH_HELLO", issuer: "Bank" }, bankPage)).role, "none");
  assert.equal((await env.A.onMessage({ type: "UOH_HELLO" }, bankPage)).role, "none");      // issuer from the page's host
  assert.equal((await bankSeen(env)).reason, "off");
  assert.equal((await env.A.onMessage({ type: "UOH_HELLO" },
    { tab: { id: 1, url: "https://global.americanexpress.com/overview" } })).role, "watch");

  env = load({ UOH_Settings: { autoAdd: { Bank: true } } });
  addBank(env);
  assert.equal((await env.A.onMessage({ type: "UOH_HELLO" }, bankPage)).role, "watch");
  assert.equal((await env.A.onMessage({ type: "UOH_HELLO" }, { tab: { id: 1 } })).role, "none");   // Amex is off
  // A page on another issuer's site can't start this issuer's run.
  var r = await env.A.onMessage({ type: "UOH_SEEN", issuer: "Bank", ids: ["900"] },
                                { tab: { id: 1, windowId: 1, url: "https://global.americanexpress.com/overview" } });
  assert.equal(r.reason, "wrong-site");
  assert.equal(count(env, "create"), 0);
});

test("a sign-in to another issuer during a run waits for it, then runs on the host of the user's tab", async function () {
  var env = load({ UOH_Settings: { autoAdd: { Amex: true, Bank: true } } });
  addBank(env);
  await startRun(env);
  var r = await bankSeen(env);
  assert.equal(r.reason, "queued");
  await settle();
  assert.equal(count(env, "remove"), 0, "the Amex run keeps going");
  await discover(env);
  assert.equal(env.chrome._store.local.UOH_AutoState.lastRun.issuer, "Amex");
  // The Amex run ended; the Bank run opens on the host the user signed into.
  assert.equal(env.chrome._store.session.UOH_Run.issuer, "Bank");
  assert.ok(env.chrome._calls.some(function (c) { return c[0] === "create" && c[1] === BANK_HOME && c[2] === 1; }));
  var navs = count(env, "nav");
  var p = await bankDiscover(env);
  assert.equal(jobsOf(p, "add"), 0, "a first run only reads the card list");
  assert.equal(count(env, "nav"), navs, "a one-page app is never navigated");
  var st = env.chrome._store.local.UOH_AutoState;
  assert.equal(st.lastRun.issuer, "Bank");
  // Every card gets every offer, so there is no order to pick.
  assert.match(st.lastRun.note, /Choose which cards get offers in the Cards panel/);
  assert.ok(st.cards["Bank|900"].doneAt && st.cards["Amex|11111"].doneAt);
  assert.equal(env.chrome._store.local.UOH_Settings.cards["Bank|901"].confirmed, false);
  assert.equal(env.chrome._calls.filter(function (c) { return c[0] === "create" && c[1] === DASH; }).length, 2);

  // A sign-in that waited is dropped once the user's tab has left that site.
  env = load({ UOH_Settings: { autoAdd: { Amex: true, Bank: true } } });
  addBank(env);
  await startRun(env);
  await bankSeen(env);
  env.chrome._tabs[BANK_TAB].url = "https://news.example/";
  await discover(env);
  assert.equal(env.chrome._store.session.UOH_Run, undefined);
  assert.ok(!env.chrome._calls.some(function (c) { return c[0] === "create" && c[1] === BANK_HOME; }));
});

test("cards that each keep every offer: the autopilot runs on each card with Add on, in rank order, at its own pace", async function () {
  var env = load(bankConfirmed(true));
  addBank(env);
  assert.equal((await bankSeen(env)).started, true);
  await settle();
  var tabId = env.chrome._store.session.UOH_Run.tabId;
  var p = await bankDiscover(env);
  var j = lastJob(p);
  assert.equal(j.kind, "add"); assert.equal(j.card.id, "901");                     // rank 0 first
  assert.equal(env.paces[env.paces.length - 1], 300, "ticks at the autopilot's own pace");
  // The page may show account ids or only endings; both count as this login.
  assert.deepEqual(j.loginDigits.slice().sort(), ["1234", "5678", "900", "901", "9012", "902"]);
  await runCard(env, p, "5678", { count: 4, harvested: 9, note: "Done. 4 added, 9 from history." });
  await runCard(env, p, "1234", { count: 2, harvested: 6, note: "Done. 2 added, 6 from history." });
  assert.deepEqual(env.chrome._calls.filter(function (c) { return c[0] === "inject"; }).map(function (c) { return c[1] + " " + c[3]; }),
                   [tabId + " ISOLATED", tabId + " MAIN", tabId + " ISOLATED", tabId + " MAIN"]);
  var st = env.chrome._store.local.UOH_AutoState;
  assert.equal(st.lastRun.ok, true); assert.equal(st.lastRun.added, 6);
  assert.equal(st.lastRun.cards.filter(function (c) { return c.key === "Bank|902"; })[0].added, 0);   // Add off: no job
  assert.equal(count(env, "nav"), 0);
  assert.ok(!env.chrome._calls.some(function (c) { return c[0] === "create" && c[1] === DASH; }));
  assert.ok(env.chrome._calls.some(function (c) { return c[0] === "badge" && c[1] === "+6"; }));
});

test("a page error reloads the tab once for that step, then moves on; a one-page app retries discover by reloading", async function () {
  var env = load(bankConfirmed(false));
  addBank(env);
  await bankSeen(env);
  await settle();
  var tabId = env.chrome._store.session.UOH_Run.tabId;
  var p = await bankDiscover(env);
  var j = lastJob(p);
  assert.equal(j.card.id, "901");
  p.send({ t: "FAIL", jobId: j.id, reason: "page-error" });
  await settle();
  assert.equal(count(env, "reload"), 1);
  var p2 = connect(env, tabId);                                   // the reloaded page gets the same job
  await settle();
  var j2 = lastJob(p2);
  assert.equal(j2.id, j.id); assert.equal(j2.card.id, "901");
  p2.send({ t: "FAIL", jobId: j2.id, reason: "page-error" });
  await settle();
  assert.equal(count(env, "reload"), 1, "one reload per step");
  await runCard(env, p2, "1234");                                 // the next card
  await runCard(env, p2, "9012");
  var st = env.chrome._store.local.UOH_AutoState;
  assert.equal(st.lastRun.ok, true);
  assert.ok(st.lastRun.notes.indexOf("Bank|901: page-error") > -1);

  // Discover fails: the one-page app is loaded again, not sent to a retry URL.
  env = load({ UOH_Settings: { autoAdd: { Bank: true } } });
  addBank(env);
  await bankSeen(env);
  await settle();
  tabId = env.chrome._store.session.UOH_Run.tabId;
  p = connect(env, tabId);
  await settle();
  p.send({ t: "LOCKED" });
  p.send({ t: "FAIL", jobId: lastJob(p).id, reason: "no-accounts" });
  await settle();
  assert.equal(count(env, "reload"), 1);
  assert.equal(count(env, "nav"), 0);
  p = connect(env, tabId);
  await settle();
  p.send({ t: "FAIL", jobId: lastJob(p).id, reason: "no-accounts" });
  await settle();
  assert.match(env.chrome._store.local.UOH_AutoState.lastRun.note, /card list/);
});

/* ---------- Chase (lib/issuers/chase.js) ---------- */

var CHASE_TAB = 60;
var CHASE_HOME = "https://secure05ea.chase.com/web/auth/dashboard#/dashboard/overview";
var CHASE_ACCOUNTS = [
  { id: "1000000001", label: "CHASE COLLEGE (...2222)" },
  { id: "2000000002", label: "Sapphire Reserve (...1111)" },
  { id: "3000000003", label: "Total Savings (...4444)" }
];
var CHASE_OPTIONS = [
  { label: "CHASE COLLEGE (...2222)", selected: false },
  { label: "Sapphire Reserve (...1111)", selected: true },
  { label: "Ink Business Cash (...5555)", selected: false }
];
async function chaseStart(env) {
  env.chrome._tabs[CHASE_TAB] = { id: CHASE_TAB, windowId: 1, url: CHASE_HOME };
  var r = await env.A.onMessage({ type: "UOH_SEEN", issuer: "Chase", ids: ["1000000001", "2000000002", "3000000003"] },
                                { tab: { id: CHASE_TAB, windowId: 1, url: CHASE_HOME } });
  await settle();
  return r;
}
async function chaseDiscover(env) {
  var tabId = env.chrome._store.session.UOH_Run.tabId;
  assert.equal((await env.A.onMessage({ type: "UOH_HELLO", issuer: "Chase" }, { tab: { id: tabId } })).role, "run");
  var p = connect(env, tabId);
  await settle();
  p.send({ t: "LOCKED" });
  var j = lastJob(p);
  assert.equal(j.kind, "discover");
  p.send({ t: "DONE", jobId: j.id, result: { accounts: CHASE_ACCOUNTS, options: CHASE_OPTIONS,
                                              shown: "Sapphire Reserve...1111", hashId: "" } });
  await settle();
  return p;
}

test("Chase: the first run reads the card list without navigating, then opens Cards", async function () {
  var env = load({ UOH_Settings: { autoAdd: { Chase: true } } });
  assert.equal((await env.A.onMessage({ type: "UOH_HELLO" }, { tab: { id: CHASE_TAB, url: CHASE_HOME } })).role, "watch");
  var r = await chaseStart(env);
  assert.equal(r.started, true);
  assert.deepEqual(env.chrome._calls[0], ["create", CHASE_HOME, 1]);       // the host the user signed into
  var p = await chaseDiscover(env);
  assert.equal(jobsOf(p, "add"), 0);
  assert.equal(count(env, "nav"), 0, "the one-page app is never navigated");
  var cards = env.chrome._store.local.UOH_Settings.cards;
  assert.equal(cards["Chase|2000000002"].confirmed, false);
  assert.equal(cards["Chase|2000000002"].rank, 0);                         // the card on screen first
  assert.equal(cards["Chase|2000000002"].login, "1000000001,2000000002");
  assert.equal(cards["Chase|1000000001"].name, "CHASE COLLEGE");
  assert.equal(cards["Chase|3000000003"], undefined);                      // savings: no offers list
  var st = env.chrome._store.local.UOH_AutoState;
  assert.equal(st.lastRun.issuer, "Chase");
  assert.equal(st.lastRun.ok, true);
  assert.match(st.lastRun.note, /^Found 2 cards\. Choose which cards get offers in the Cards panel/);
  assert.ok(st.lastRun.notes.some(function (n) { return /Ink Business Cash ••5555: not found/.test(n); }));
  // The gap covers every account of the login, the savings account included.
  ["Chase|1000000001", "Chase|2000000002", "Chase|3000000003"].forEach(function (k) { assert.ok(st.cards[k].doneAt, k); });
  assert.ok(env.chrome._calls.some(function (c) { return c[0] === "create" && c[1] === DASH; }));
  r = await env.A.onMessage({ type: "UOH_SEEN", issuer: "Chase", ids: ["3000000003"] },
                            { tab: { id: CHASE_TAB, windowId: 1, url: CHASE_HOME } });
  assert.equal(r.reason, "gap");
});

test("Chase: Run Chase Autopilot runs on every card with Add on, at its 400 ms pace; the endings of the whole login travel with each job", async function () {
  var login = "1000000001,2000000002";
  var env = load({ UOH_Settings: { autoAdd: { Chase: true }, cards: {
    "Chase|2000000002": { rank: 0, confirmed: true, login: login },
    "Chase|1000000001": { rank: 1, confirmed: true, login: login, skip: true } } } });
  await chaseStart(env);
  var p = await chaseDiscover(env);
  var j = lastJob(p);
  assert.equal(j.card.key, "Chase|2000000002");
  assert.equal(env.paces[env.paces.length - 1], 400);
  // The savings account and the skipped card are this login's too.
  ["4444", "5555", "2222", "1000000001"].forEach(function (d) { assert.ok(j.loginDigits.indexOf(d) > -1, d); });
  await runCard(env, p, "1111", { count: 13, harvested: 149, note: "Done. 13 added, 149 from history.",
                                  check: { wallet: [136, 149], urlId: "2000000002", id: "2000000002" } });
  assert.equal(jobsOf(p, "add"), 1, "the card with Add off gets no job");
  var st = env.chrome._store.local.UOH_AutoState;
  assert.equal(st.lastRun.ok, true); assert.equal(st.lastRun.added, 13);
  assert.equal(st.lastRun.note, "13 offers added across 2 cards.");
  assert.equal(count(env, "nav"), 0);
  assert.ok(!env.chrome._calls.some(function (c) { return c[0] === "create" && c[1] === DASH; }));
});

test("Add offers now in the bank's own tab (the gap note's button) runs at once, in that tab's window and host", async function () {
  var env = load({ UOH_Settings: { autoAdd: { Chase: true } } });
  await chaseStart(env);
  await chaseDiscover(env);
  var r = await env.A.onMessage({ type: "UOH_SEEN", issuer: "Chase", ids: ["2000000002"] },
                                { tab: { id: CHASE_TAB, windowId: 1, url: CHASE_HOME } });
  assert.equal(r.reason, "gap");
  env.chrome._tabs[CHASE_TAB].windowId = 3;
  r = await env.A.onMessage({ type: "UOH_RUN_NOW", issuer: "Chase" }, { tab: { id: CHASE_TAB, windowId: 3, url: CHASE_HOME } });
  await settle();
  assert.equal(r.ok, true);
  assert.deepEqual(env.chrome._calls.filter(function (c) { return c[0] === "create" && c[1] === CHASE_HOME; }).pop(), ["create", CHASE_HOME, 3]);
  assert.equal(env.chrome._store.session.UOH_Run.triggerTabId, CHASE_TAB);
});
