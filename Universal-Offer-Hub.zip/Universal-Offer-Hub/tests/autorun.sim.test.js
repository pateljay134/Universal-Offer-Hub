/*
 * Simulation tests for lib/autorun.js: a fake chrome.* plus a scripted
 * "driver" standing in for content/amex-auto.js on the Amex pages. Checks the
 * run's sequencing (discover -> scan -> assign -> add -> harvest -> finish),
 * the scan-only first run, the 2-hour gap, and the main stop paths.
 *   node --test tests/
 */
"use strict";
var test = require("node:test");
var assert = require("node:assert/strict");

var OFFERS = "https://global.americanexpress.com/offers";
var ENROLLED = "https://global.americanexpress.com/offers/enrolled?opaqueAccountId=";

function clone(x) { return x === undefined ? x : JSON.parse(JSON.stringify(x)); }
function ev() {
  var fns = [];
  return { addListener: function (f) { fns.push(f); }, fire: function () { var a = arguments; fns.forEach(function (f) { f.apply(null, a); }); } };
}
function tick() { return new Promise(function (r) { setImmediate(r); }); }
async function settle() { for (var i = 0; i < 30; i++) await tick(); }

function makeChrome(local) {
  var store = { local: clone(local || {}), session: {} };
  var calls = [];
  var onChanged = ev();
  function area(name) {
    return {
      get: function (keys) {
        var out = {};
        (Array.isArray(keys) ? keys : [keys]).forEach(function (k) { if (k in store[name]) out[k] = clone(store[name][k]); });
        return Promise.resolve(out);
      },
      set: function (obj) {
        var changes = {};
        Object.keys(obj).forEach(function (k) { changes[k] = { newValue: clone(obj[k]) }; store[name][k] = clone(obj[k]); });
        onChanged.fire(changes, name);
        return Promise.resolve();
      },
      remove: function (keys) {
        (Array.isArray(keys) ? keys : [keys]).forEach(function (k) { delete store[name][k]; });
        return Promise.resolve();
      }
    };
  }
  var tabs = { 1: { id: 1, windowId: 1, url: "https://global.americanexpress.com/overview" } };
  var nextId = 2, ports = [];
  var c = {
    _store: store, _calls: calls, _tabs: tabs, _ports: ports,
    storage: { local: area("local"), session: area("session"), onChanged: onChanged },
    tabs: {
      create: function (p) {
        var t = { id: nextId++, windowId: p.windowId, url: p.url };
        tabs[t.id] = t; calls.push(["create", p.url]);
        return Promise.resolve(clone(t));
      },
      update: function (id, p) {
        if (!tabs[id]) return Promise.reject(new Error("no tab"));
        if (p.url) {
          tabs[id].url = p.url; calls.push(["nav", p.url]);
          // The old page goes away: its port disconnects.
          ports.filter(function (pt) { return pt.tabId === id && !pt.dead; }).forEach(function (pt) { pt._disconnect(); });
        }
        return Promise.resolve(clone(tabs[id]));
      },
      get: function (id) { return tabs[id] ? Promise.resolve(clone(tabs[id])) : Promise.reject(new Error("no tab")); },
      remove: function (id) {
        calls.push(["remove", id]);
        delete tabs[id];
        c.tabs.onRemoved.fire(id);
        return Promise.resolve();
      },
      group: function () { calls.push(["group"]); return Promise.resolve(77); },
      ungroup: function () { calls.push(["ungroup"]); return Promise.resolve(); },
      query: function () { return Promise.resolve([]); },
      sendMessage: function (id, m) { calls.push(["notify", id, m.type, m.added, m.scanOnly]); return Promise.resolve(); },
      onUpdated: ev(), onRemoved: ev()
    },
    tabGroups: {
      update: function (gid, p) { calls.push(["groupUpdate", p.collapsed]); return Promise.resolve(); },
      query: function () { return Promise.resolve([]); }
    },
    windows: { get: function (id) { return Promise.resolve({ id: id }); }, getLastFocused: function () { return Promise.resolve({ id: 1 }); } },
    alarms: { create: function () {}, clear: function () { return Promise.resolve(); }, onAlarm: ev() },
    action: {
      setBadgeText: function (o) { calls.push(["badge", o.text]); return Promise.resolve(); },
      setBadgeBackgroundColor: function () { return Promise.resolve(); }
    },
    runtime: { onConnect: ev(), getURL: function (p) { return "chrome-extension://test/" + p; } }
  };
  return c;
}

// Fresh copies of lib/offers.js + lib/autorun.js bound to a fake chrome.
function load(local) {
  var chrome = makeChrome(local);
  globalThis.self = globalThis;
  globalThis.chrome = chrome;
  globalThis.setInterval = function () { return 1; };   // ticks don't matter here
  globalThis.clearInterval = function () {};
  console.log = function () {};
  delete require.cache[require.resolve("../lib/offers.js")];
  delete require.cache[require.resolve("../lib/autorun.js")];
  delete globalThis.UOH; delete globalThis.UOH_AUTO;
  require("../lib/offers.js");
  require("../lib/autorun.js");
  var saved = {};
  var hooks = {
    save: function (recs) { Object.assign(saved, recs); return Promise.resolve({ ok: true }); },
    patchSettings: function (patch) {
      var s = chrome._store.local.UOH_Settings || {};
      Object.keys(patch).forEach(function (k) {
        if (k === "cards") {
          s.cards = s.cards || {};
          Object.keys(patch.cards).forEach(function (ck) { s.cards[ck] = Object.assign({}, s.cards[ck] || {}, patch.cards[ck]); });
        } else s[k] = patch[k];
      });
      return chrome.storage.local.set({ UOH_Settings: s }).then(function () { return { settings: clone(s) }; });
    },
    afterDataChange: function () {}
  };
  UOH_AUTO.init(hooks);
  return { chrome: chrome, A: UOH_AUTO, saved: saved };
}

// The driver side of one page load in the run tab.
function connect(env, tabId) {
  var port = {
    name: "uoh-run", tabId: tabId, inbox: [], dead: false, _m: [], _d: [],
    sender: { tab: { id: tabId }, url: env.chrome._tabs[tabId].url },
    onMessage: { addListener: function (f) { port._m.push(f); } },
    onDisconnect: { addListener: function (f) { port._d.push(f); } },
    postMessage: function (m) { if (m.t !== "TICK") port.inbox.push(m); },
    disconnect: function () { port._disconnect(); },
    _disconnect: function () { if (port.dead) return; port.dead = true; port._d.forEach(function (f) { f(); }); },
    send: function (m) { port._m.forEach(function (f) { f(m); }); }
  };
  env.chrome._ports.push(port);
  env.chrome.runtime.onConnect.fire(port);
  return port;
}
function lastJob(port) {
  var jobs = port.inbox.filter(function (m) { return m.t === "JOB"; });
  return jobs.length ? jobs[jobs.length - 1].job : null;
}
var OPTIONS = [
  { testid: "simple_switcher_static_option_ALL", aria: "Overview", name: "Overview" },
  { testid: "simple_switcher_product_option_CARD_PRODUCT_AAAA", aria: "Platinum Card® ending in 11111.", name: "Platinum Card®" },
  { testid: "simple_switcher_product_option_CARD_PRODUCT_BBBB", aria: "Blue Cash Everyday® ending in 22222.", name: "Blue Cash Everyday®" },
  { testid: "simple_switcher_product_option_AEXP_PERSONAL_CHECKING_ACCOUNT_cc", aria: "Rewards Checking ending in 3333.", name: "American Express Rewards Checking" }
];
var SCAN_A = [{ mk: "thepalm", m: "The Palm", v: "Spend $150 or more, earn $50 back" },
              { mk: "away", m: "Away", v: "Spend $300 or more, earn $60 back" }];
var SCAN_B = [{ mk: "thepalm", m: "The Palm", v: "Spend $100 or more, earn $25 back" },
              { mk: "away", m: "Away", v: "Spend $300 or more, earn $60 back" },
              { mk: "fubotv", m: "Fubo TV", v: "Spend $60 or more, earn $30 back" }];

async function startRun(env) {
  var r = await env.A.onMessage({ type: "UOH_AMEX_SEEN", digits: "11111", name: "Platinum Card®" },
                                { tab: { id: 1, windowId: 1 } });
  await settle();
  return r;
}

async function discoverAndScan(env) {
  var runTab = 2;
  var hello = await env.A.onMessage({ type: "UOH_HELLO" }, { tab: { id: runTab } });
  assert.deepEqual(hello.role, "run");
  var p1 = connect(env, runTab);
  await settle();
  p1.send({ t: "LOCKED" });
  var j = lastJob(p1);
  assert.equal(j.kind, "discover");
  p1.send({ t: "DONE", jobId: j.id, result: { displayed: { digits: "11111", name: "Platinum Card®" }, options: OPTIONS } });
  await settle();
  j = lastJob(p1);
  assert.equal(j.kind, "scan"); assert.equal(j.card.digits, "11111");   // card on screen first
  p1.send({ t: "DONE", jobId: j.id, result: { items: SCAN_A } });
  await settle();
  j = lastJob(p1);
  assert.equal(j.kind, "scan"); assert.equal(j.card.digits, "22222"); assert.equal(j.card.optId, "BBBB");
  p1.send({ t: "DONE", jobId: j.id, result: { items: SCAN_B } });
  await settle();
  return p1;
}

async function harvestAll(env, expectDigits) {
  for (var i = 0; i < expectDigits.length; i++) {
    var navs = env.chrome._calls.filter(function (c) { return c[0] === "nav"; });
    assert.ok(navs.length && navs[navs.length - 1][1].indexOf(ENROLLED) === 0, "navigates to an Added page");
    var p = connect(env, 2);
    await settle();
    var j = lastJob(p);
    assert.equal(j.kind, "harvest"); assert.equal(j.card.digits, expectDigits[i]);
    p.send({ t: "SAVE", records: { ["amex_" + j.card.digits + "_X"]: { m: "X", v: "$1 back", site: "Amex" } } });
    p.send({ t: "DONE", jobId: j.id, result: { harvested: 1 } });
    await settle();
  }
}

test("first run on a login only scans and harvests, then asks for the card order", async function () {
  var env = load({ UOH_Settings: { autoAdd: { Amex: true } } });
  var r = await startRun(env);
  assert.equal(r.started, true);
  assert.deepEqual(env.chrome._calls[0], ["create", OFFERS]);
  await discoverAndScan(env);
  var cards = env.chrome._store.local.UOH_Settings.cards;
  assert.equal(cards["Amex|11111"].rank, 0);            // card Amex opened first ranks first
  assert.equal(cards["Amex|22222"].rank, 1);
  assert.equal(cards["Amex|11111"].confirmed, false);
  assert.equal(cards["Amex|3333"], undefined);          // checking account skipped
  assert.ok(env.chrome._calls.some(function (c) { return c[0] === "groupUpdate" && c[1] === true; }), "collapsed after LOCKED");
  await harvestAll(env, ["11111", "22222"]);
  var st = env.chrome._store.local.UOH_AutoState;
  assert.equal(st.lastRun.ok, true);
  assert.equal(st.lastRun.scanOnly, true);
  assert.equal(st.lastRun.added, 0);
  assert.ok(st.cards["Amex|11111"].doneAt && st.cards["Amex|22222"].doneAt);
  assert.ok(env.chrome._calls.some(function (c) { return c[0] === "ungroup"; }));
  assert.ok(env.chrome._calls.some(function (c) { return c[0] === "remove" && c[1] === 2; }));
  assert.ok(env.chrome._calls.some(function (c) { return c[0] === "badge" && c[1] === "!"; }));
  assert.ok(env.chrome._calls.some(function (c) { return c[0] === "notify" && c[1] === 1 && c[4] === true; }));
  assert.ok(env.saved["amex_11111_X"] && env.saved["amex_22222_X"]);
  assert.equal(env.chrome._store.session.UOH_Run, undefined);

  // Visiting again right away does nothing (2-hour gap per login).
  var again = await env.A.onMessage({ type: "UOH_AMEX_SEEN", digits: "22222" }, { tab: { id: 1, windowId: 1 } });
  assert.equal(again.started, false); assert.equal(again.reason, "gap");
});

test("a first run keeps the order set by hand in the dashboard; only unranked cards go to the bottom", async function () {
  // The user ordered both cards in Cards before auto-add ever saw their login.
  var env = load({ UOH_Settings: { autoAdd: { Amex: true }, cards: {
    "Amex|22222": { rank: 0 }, "Amex|11111": { rank: 1 } } } });
  await startRun(env);                                    // Amex opens 11111 first
  var p = await discoverAndScan(env);
  var cards = env.chrome._store.local.UOH_Settings.cards;
  assert.equal(cards["Amex|22222"].rank, 0);            // kept, though Amex opened 11111 first
  assert.equal(cards["Amex|11111"].rank, 1);
  assert.equal(cards["Amex|22222"].confirmed, false);   // a first run only scans
  assert.equal(cards["Amex|11111"].confirmed, false);
  assert.equal(cards["Amex|22222"].login, "11111,22222");
  assert.equal(cards["Amex|11111"].login, "11111,22222");
  assert.equal(p.inbox.filter(function (m) { return m.t === "JOB" && m.job.kind === "add"; }).length, 0);

  // Only 22222 was ordered by hand: 11111 has no rank, so it goes below it.
  env = load({ UOH_Settings: { autoAdd: { Amex: true }, cards: { "Amex|22222": { rank: 0, nick: "Wife BCE" } } } });
  await startRun(env);
  await discoverAndScan(env);
  cards = env.chrome._store.local.UOH_Settings.cards;
  assert.equal(cards["Amex|22222"].rank, 0);
  assert.equal(cards["Amex|11111"].rank, 1);
  assert.equal(cards["Amex|22222"].nick, "Wife BCE");
});

test("with a confirmed order: assign by value then rank, add top-ranked card first", async function () {
  var env = load({ UOH_Settings: { autoAdd: { Amex: true }, cards: {
    "Amex|22222": { rank: 0, confirmed: true, login: "11111,22222" },
    "Amex|11111": { rank: 1, confirmed: true, login: "11111,22222" } } } });
  await startRun(env);
  var p = await discoverAndScan(env);
  var j = lastJob(p);
  assert.equal(j.kind, "add");
  assert.equal(j.card.digits, "22222");                  // rank 0 first
  assert.deepEqual(j.keys, ["away", "fubotv"]);          // tie -> rank 0; only on B
  p.send({ t: "DONE", jobId: j.id, result: { added: ["away", "fubotv"], failed: [], gone: [], stalled: false } });
  await settle();
  j = lastJob(p);
  assert.equal(j.kind, "add"); assert.equal(j.card.digits, "11111");
  assert.deepEqual(j.keys, ["thepalm"]);                 // $50 beats $25
  p.send({ t: "DONE", jobId: j.id, result: { added: ["thepalm"], failed: [], gone: [], stalled: false } });
  await settle();
  assert.equal(env.saved["amex_22222_Away"].status, "added");
  assert.equal(env.saved["amex_11111_ThePalm"].card, "Platinum Card® ••11111");
  await harvestAll(env, ["11111", "22222"]);
  var st = env.chrome._store.local.UOH_AutoState;
  assert.equal(st.lastRun.ok, true); assert.equal(st.lastRun.scanOnly, false); assert.equal(st.lastRun.added, 3);
  assert.ok(env.chrome._calls.some(function (c) { return c[0] === "badge" && c[1] === "+3"; }));
});

test("a stalled card hands its offers to the next card; two stalls in a row stop the run", async function () {
  var env = load({ UOH_Settings: { autoAdd: { Amex: true }, cards: {
    "Amex|22222": { rank: 0, confirmed: true, login: "11111,22222" },
    "Amex|11111": { rank: 1, confirmed: true, login: "11111,22222" } } } });
  await startRun(env);
  var p = await discoverAndScan(env);
  var j = lastJob(p);
  p.send({ t: "DONE", jobId: j.id, result: { added: [], failed: ["away"], gone: [], stalled: true } });
  await settle();
  j = lastJob(p);
  assert.equal(j.card.digits, "11111");
  assert.deepEqual(j.keys.slice().sort(), ["away", "thepalm"]);  // Away moved over; Fubo exists only on B
  p.send({ t: "DONE", jobId: j.id, result: { added: [], failed: ["thepalm"], gone: [], stalled: true } });
  await settle();
  var st = env.chrome._store.local.UOH_AutoState;
  assert.equal(st.lastRun.ok, false);
  assert.match(st.lastRun.note, /isn't confirming/);
  assert.ok(st.cards["Amex|11111"].doneAt);             // it got as far as adding: counts for the 2-hour gap
  assert.ok(env.chrome._calls.some(function (c) { return c[0] === "remove" && c[1] === 2; }));
});

test("an add job that fails outright doesn't bench the card or hand its offers to a lower-ranked card", async function () {
  var env = load({ UOH_Settings: { autoAdd: { Amex: true }, cards: {
    "Amex|22222": { rank: 0, confirmed: true, login: "11111,22222" },
    "Amex|11111": { rank: 1, confirmed: true, login: "11111,22222" } } } });
  await startRun(env);
  var p = await discoverAndScan(env);
  var j = lastJob(p);
  assert.equal(j.card.digits, "22222");
  p.send({ t: "FAIL", jobId: j.id, reason: "switch-failed" });
  await settle();
  j = lastJob(p);
  assert.equal(j.kind, "add"); assert.equal(j.card.digits, "11111");
  assert.deepEqual(j.keys, ["thepalm"]);                 // Away waits for the rank-0 card's next run
  p.send({ t: "DONE", jobId: j.id, result: { added: ["thepalm"], failed: [], gone: [], stalled: false } });
  await settle();
  await harvestAll(env, ["11111", "22222"]);
  var st = env.chrome._store.local.UOH_AutoState;
  assert.equal(st.lastRun.ok, true);
  assert.equal(st.cards["Amex|22222"].stalledUntil, undefined);
});

test("another account on the same login (checking) neither stops the run nor gets around the 2-hour gap", async function () {
  var env = load({ UOH_Settings: { autoAdd: { Amex: true } } });
  await startRun(env);
  // Before the card list is read, any ending keeps the run going.
  var r = await env.A.onMessage({ type: "UOH_AMEX_SEEN", digits: "22222" }, { tab: { id: 1, windowId: 1 } });
  assert.equal(r.reason, "running");
  await discoverAndScan(env);
  r = await env.A.onMessage({ type: "UOH_AMEX_SEEN", digits: "3333" }, { tab: { id: 1, windowId: 1 } });
  assert.equal(r.reason, "running");
  await harvestAll(env, ["11111", "22222"]);
  assert.equal(env.chrome._calls.filter(function (c) { return c[0] === "create"; }).length, 1);
  r = await env.A.onMessage({ type: "UOH_AMEX_SEEN", digits: "3333" }, { tab: { id: 1, windowId: 1 } });
  assert.equal(r.reason, "gap");
});

test("Stop counts as the login's run; a run whose page never loaded may retry after 15 minutes", async function () {
  var real = Date.now, later = function () { return real() + 16 * 60 * 1000; };
  var env = load({ UOH_Settings: { autoAdd: { Amex: true } } });
  await startRun(env);
  await env.A.onMessage({ type: "UOH_STOP_RUN" }, {});
  await settle();
  assert.ok(env.chrome._store.local.UOH_AutoState.cards["Amex|11111"].doneAt);
  Date.now = later;
  try {
    var r = await env.A.onMessage({ type: "UOH_AMEX_SEEN", digits: "11111" }, { tab: { id: 1, windowId: 1 } });
    assert.equal(r.reason, "gap");
  } finally { Date.now = real; }

  // Signed out before the offers page reported its lock: only triedAt.
  env = load({ UOH_Settings: { autoAdd: { Amex: true } } });
  await startRun(env);
  env.chrome._tabs[2].url = "https://www.americanexpress.com/en-us/account/login";
  connect(env, 2);
  await settle();
  var c = env.chrome._store.local.UOH_AutoState.cards["Amex|11111"];
  assert.ok(c.triedAt && !c.doneAt);
  Date.now = later;
  try {
    r = await env.A.onMessage({ type: "UOH_AMEX_SEEN", digits: "11111" }, { tab: { id: 1, windowId: 1 } });
    assert.equal(r.started, true);
  } finally { Date.now = real; }
});

test("stop paths: signed out, tab closed, toggle off, another login", async function () {
  // signed out: the run tab lands somewhere other than the offers pages
  var env = load({ UOH_Settings: { autoAdd: { Amex: true } } });
  await startRun(env);
  env.chrome._tabs[2].url = "https://www.americanexpress.com/en-us/account/login";
  connect(env, 2);
  await settle();
  assert.match(env.chrome._store.local.UOH_AutoState.lastRun.note, /signed out/);

  // the user closes the Offer Hub tab
  env = load({ UOH_Settings: { autoAdd: { Amex: true } } });
  await startRun(env);
  connect(env, 2); await settle();
  env.chrome.tabs.remove(2); await settle();
  assert.match(env.chrome._store.local.UOH_AutoState.lastRun.note, /closed/);

  // the toggle is turned off mid-run
  env = load({ UOH_Settings: { autoAdd: { Amex: true } } });
  await startRun(env);
  connect(env, 2); await settle();
  await env.chrome.storage.local.set({ UOH_Settings: { autoAdd: { Amex: false } } });
  await settle();
  assert.match(env.chrome._store.local.UOH_AutoState.lastRun.note, /turned off/);

  // the browser signs into another login while a run works
  env = load({ UOH_Settings: { autoAdd: { Amex: true } } });
  await startRun(env);
  var p = await discoverAndScan(env);
  var r = await env.A.onMessage({ type: "UOH_AMEX_SEEN", digits: "99999" }, { tab: { id: 1, windowId: 1 } });
  await settle();
  assert.ok(env.chrome._calls.some(function (c) { return c[0] === "remove" && c[1] === 2; }));
  assert.equal(r.started, true);                         // the new login gets its own run
  assert.equal(env.chrome._calls.filter(function (c) { return c[0] === "create"; }).length, 2);
});

test("auto-add off: Amex pages get no role and nothing starts", async function () {
  var env = load({ UOH_Settings: {} });
  var hello = await env.A.onMessage({ type: "UOH_HELLO" }, { tab: { id: 1 } });
  assert.equal(hello.role, "none");
  var r = await env.A.onMessage({ type: "UOH_AMEX_SEEN", digits: "11111" }, { tab: { id: 1, windowId: 1 } });
  assert.equal(r.started, false); assert.equal(r.reason, "off");
  assert.equal(env.chrome._calls.filter(function (c) { return c[0] === "create"; }).length, 0);
});

test("a login whose cards changed goes back to scan-only until its order is confirmed again", async function () {
  // 22222 was confirmed on another login (with 99999); it now shows up on this login.
  var env = load({ UOH_Settings: { autoAdd: { Amex: true }, cards: {
    "Amex|11111": { rank: 0, confirmed: true, login: "11111" },
    "Amex|22222": { rank: 0, confirmed: true, login: "22222,99999" } } } });
  await startRun(env);
  var p = await discoverAndScan(env);
  var cards = env.chrome._store.local.UOH_Settings.cards;
  assert.equal(cards["Amex|11111"].confirmed, false);
  assert.equal(cards["Amex|22222"].confirmed, false);
  assert.equal(cards["Amex|11111"].rank, 0);                     // kept: it was ranked on this login
  assert.ok(cards["Amex|22222"].rank > cards["Amex|11111"].rank); // moved in: goes to the bottom
  assert.equal(cards["Amex|22222"].login, "11111,22222");
  var navs = env.chrome._calls.filter(function (c) { return c[0] === "nav"; });
  assert.ok(navs[navs.length - 1][1].indexOf(ENROLLED) === 0);     // scan-only: straight to harvest, no add job
  assert.equal(p.inbox.filter(function (m) { return m.t === "JOB" && m.job.kind === "add"; }).length, 0);
});
