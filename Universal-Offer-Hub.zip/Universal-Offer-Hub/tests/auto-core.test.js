/*
 * Unit tests for content/auto-core.js: reading who is signed in from a
 * bank's page. Made-up names only.
 *   node --test --test-timeout=30000 tests/*.test.js
 */
"use strict";
var test = require("node:test");
var assert = require("node:assert/strict");
globalThis.self = globalThis;
require("../content/auto-core.js");
var P = globalThis.UOH_AUTO_PAGE;

test("a greeting names who is signed in, whatever it says first", function () {
  assert.equal(P.greetedName("Good evening, Alex"), "Alex");
  assert.equal(P.greetedName("Good morning, ALEX!"), "Alex");
  assert.equal(P.greetedName("Good afternoon,   Sam R."), "Sam R.");
  assert.equal(P.greetedName("Welcome back Jordan"), "Jordan");
  assert.equal(P.greetedName("Hi Casey"), "Casey");
  assert.equal(P.greetedName("Hilary"), "Hilary", "a name that starts like a greeting stays whole");
  assert.equal(P.greetedName("Good evening"), "");
  assert.equal(P.greetedName(""), "");
});

test("only text that looks like a name is taken as one", function () {
  assert.equal(P.personName("Alex R."), "Alex R.");
  assert.equal(P.personName("MARY-JO O'NEIL"), "Mary-Jo O'Neil");
  assert.equal(P.personName("Account 1234"), "");
  assert.equal(P.personName("a@b.c"), "");
  assert.equal(P.personName(new Array(46).join("x")), "");
});
