/*
 * Unit tests for lib/offers.js. No dependencies: run with
 *   node --test tests/
 * from the extension folder.
 */
"use strict";
var test = require("node:test");
var assert = require("node:assert/strict");
var UOH = require("../lib/offers.js");

var NOW = new Date(2026, 9, 28, 12, 0, 0).getTime(); // Oct 28 2026, noon local
var DAY = 86400000;

test("search matches merchants however the user spaces or punctuates them", function () {
  var o = { m: "Road Runner Sports", v: "10% back", card: "Platinum ••31005" };
  ["roadrunner", "Road-Runner", "Road & Runner", "road runner"].forEach(function (q) {
    assert.ok(UOH.scoreOffer(o, UOH.tokenize(q)) > 0, q);
  });
  assert.equal(UOH.scoreOffer(o, UOH.tokenize("samsung")), 0);
  // a nickname passed as extra text is searchable
  assert.ok(UOH.scoreOffer(o, UOH.tokenize("mom runner"), "Mom Plat") > 0);
});

test("parseValue classifies by what you get back", function () {
  assert.deepEqual(UOH.parseValue("Spend $30, earn 1,500 miles"), { num: 1500, type: "MILES" });
  assert.deepEqual(UOH.parseValue("10% cash back"), { num: 10, type: "PERCENT" });
  assert.deepEqual(UOH.parseValue("Spend $150 or more, earn $50 back"), { num: 50, type: "DOLLAR" });
  assert.deepEqual(UOH.parseValue("8X miles"), { num: 8, type: "MULTI" });
});

test("parseTerms and estValueUsd read the Amex offer shapes", function () {
  var a = UOH.parseTerms("Spend $60 or more, earn $30 back, up to 3 times (total of $90).");
  assert.equal(a.spendMin, 60); assert.equal(a.reward, 30); assert.equal(a.times, 3); assert.equal(a.total, 90);
  assert.equal(UOH.estValueUsd("Spend $60 or more, earn $30 back, up to 3 times (total of $90)."), 90);

  var b = UOH.parseTerms("Earn 4% back on purchases, up to a total of $250");
  assert.equal(b.pct, 4); assert.equal(b.cap, 250); assert.equal(b.total, null);
  assert.equal(UOH.estValueUsd("Earn 4% back on purchases, up to a total of $250"), 250);

  var c = UOH.parseTerms("Spend $800 or more, earn 10,000 Membership Rewards® points");
  assert.equal(c.spendMin, 800); assert.equal(c.points, 10000);
  assert.equal(UOH.estValueUsd("Spend $800 or more, earn 10,000 Membership Rewards® points"), 100);

  var d = UOH.parseTerms("Earn +5 Membership Rewards® points per eligible dollar spent, up to 50,000 pts");
  assert.equal(d.ptsPerDollar, 5); assert.equal(d.ptsCap, 50000); assert.equal(d.points, null);
  assert.equal(UOH.estValueUsd("Earn +5 Membership Rewards® points per eligible dollar spent, up to 50,000 pts"), 500);

  assert.equal(UOH.estValueUsd("Spend $1,795 or more, earn $270 back"), 270);
  assert.equal(UOH.estValueUsd("10% cash back"), null);           // uncapped percent: no dollar value
  assert.equal(UOH.parseTerms("10% cash back").pct, 10);
  assert.equal(UOH.estValueUsd("22,500 miles"), 225);
  assert.equal(UOH.parseTerms("5X miles").points, null);          // a multiplier is not a points amount
});

test("expiry parsing, end-of-day reading and labels", function () {
  var abs = UOH.parseExpiresTs("Expires 10/31/26", NOW);
  assert.equal(new Date(abs).getDate(), 31);
  var rel = UOH.parseExpiresTs("13d left", NOW);
  assert.equal(new Date(rel).getDate(), 10);                       // Nov 10
  assert.equal(new Date(rel).getMonth(), 10);
  assert.equal(UOH.expiryText("Spend $50 by 12/31. Expires 11/05/26"), "Expires 11/05/26");
  assert.equal(UOH.expiryText("Spend $50 by 12/31"), "");

  // "Expires 10/28/26" is still good at noon on Oct 28 (it runs through the day).
  var today = { expiresTs: UOH.parseExpiresTs("10/28/26", NOW) };
  assert.equal(UOH.isActive(today, NOW), true);
  assert.equal(UOH.daysLeft(today, NOW), 0);
  assert.equal(UOH.expiryLabel(today, NOW).label, "Expires today");
  var yesterday = { expiresTs: UOH.parseExpiresTs("10/27/26", NOW) };
  assert.equal(UOH.isActive(yesterday, NOW), false);
  assert.equal(UOH.expiryLabel(yesterday, NOW).label, "Expired");
  assert.equal(UOH.daysLeft({ expiresTs: UOH.parseExpiresTs("11/04/26", NOW) }, NOW), 7);

  // Chase tiles say "Last day" on an offer's final day: good until midnight.
  ["Last day", "Expires today"].forEach(function (s) {
    var last = { expiresTs: UOH.parseExpiresTs(s, NOW) };
    assert.equal(new Date(last.expiresTs).getDate(), 28, s);
    assert.equal(UOH.isActive(last, NOW), true, s);
    assert.equal(UOH.expiryLabel(last, NOW).label, "Expires today", s);
  });
});

test("normalizeRecord keeps the first firstSeen and an earlier expiry", function () {
  var first = UOH.normalizeRecord({ m: "Fubo TV", v: "Spend $60, earn $30 back", site: "Amex", days: "Expires 11/30/26" }, null, NOW);
  assert.equal(first.firstSeen, NOW);
  assert.equal(first.ts, NOW);
  assert.equal(first.t, "DOLLAR");
  assert.ok(first.expiresTs > NOW);
  var later = UOH.normalizeRecord({ m: "Fubo TV", v: "Spend $60, earn $30 back", site: "Amex", status: "added" }, first, NOW + 5 * DAY);
  assert.equal(later.firstSeen, NOW);                              // not overwritten
  assert.equal(later.ts, NOW + 5 * DAY);
  assert.equal(later.expiresTs, first.expiresTs);                  // blank expiry kept the old one
  assert.equal(later.status, "added");
  // legacy record without firstSeen falls back to its ts
  var legacy = UOH.normalizeRecord({ m: "X", v: "$5 back", site: "Chase" }, { m: "X", v: "$5 back", ts: NOW - DAY }, NOW);
  assert.equal(legacy.firstSeen, NOW - DAY);
});

test("findStale splits expired and not-seen-on-latest-run offers per card", function () {
  var db = {
    a: { site: "Amex", cardId: "1", ts: NOW, expiresTs: NOW + 9 * DAY },
    b: { site: "Amex", cardId: "1", ts: NOW - 10 * 3600000, expiresTs: NOW + 9 * DAY },
    c: { site: "Amex", cardId: "1", ts: NOW, expiresTs: NOW - 2 * DAY },
    d: { site: "Chase", cardId: "9", ts: NOW - 10 * 3600000 }
  };
  var s = UOH.findStale(db, NOW);
  assert.deepEqual(s.expired, ["c"]);
  assert.deepEqual(s.unseen, ["b"]);                               // d is its card's newest, so not stale
});

test("migrateFirstSeen pushes v2 values out of the new-this-week window", function () {
  var db = { a: { firstSeen: NOW, ts: NOW }, b: { firstSeen: NOW - 30 * DAY, ts: NOW }, c: { ts: NOW - DAY } };
  var n = UOH.migrateFirstSeen(db, NOW);
  assert.equal(n, 2);
  assert.equal(UOH.isNew(db.a, NOW), false);
  assert.equal(db.b.firstSeen, NOW - 30 * DAY);
  assert.equal(UOH.isNew(db.c, NOW), false);
  assert.equal(UOH.versionLt("2.5.0", "3.0.0"), true);
  assert.equal(UOH.versionLt("3.0.0", "3.0.0"), false);
  assert.equal(UOH.versionLt("3.0.1", "3.0.0"), false);
});

test("mergeDuplicates collapses one offer on several cards into one row", function () {
  var recs = [
    { site: "Amex", m: "The Palm", v: "Spend $150, earn $50 back", cardId: "42031", card: "Platinum Card® ••42031", firstSeen: NOW - 2 * DAY, ts: NOW, expiresTs: NOW + 8 * DAY },
    { site: "Amex", m: "The Palm", v: "Spend $150, earn $50 back", cardId: "73009", card: "Gold Card® ••73009", firstSeen: NOW - 9 * DAY, ts: NOW, expiresTs: NOW + 6 * DAY },
    { site: "Chase", m: "The Palm", v: "Spend $150, earn $50 back", cardId: "x", card: "Sapphire ••2453", ts: NOW }
  ];
  var rows = UOH.mergeDuplicates(recs, { cards: { "Amex|73009": { nick: "Wife Gold" } } });
  assert.equal(rows.length, 2);                                    // different source stays separate
  assert.equal(rows[0].cards.length, 2);
  assert.equal(rows[0].firstSeen, NOW - 9 * DAY);
  assert.equal(rows[0].expiresTs, NOW + 6 * DAY);
  assert.equal(rows[0].cards[1].label, "Wife Gold ••73009");
});

test("card order: ranked cards first, a move renumbers the group, merged rows list the higher card first", function () {
  var reg = { "Amex|31005": { rank: 1 }, "Amex|84002": { rank: 0 }, "Chase|acc9": { nick: "Mom" } };
  var list = [{ key: "Chase|acc9", name: "Sapphire" }, { key: "Amex|31005", name: "Platinum" },
              { key: "Capital One|4417", name: "Venture X" }, { key: "Amex|84002", name: "Blue Cash" }];
  var sorted = UOH.sortCards(list, reg, function (c) { return c.name; });
  assert.deepEqual(sorted.map(function (c) { return c.key; }), ["Amex|84002", "Amex|31005", "Chase|acc9", "Capital One|4417"]);
  assert.equal(list[0].key, "Chase|acc9");                         // a sorted copy; the list is untouched

  var keys = ["a", "b", "c", "d"];
  assert.deepEqual(UOH.moveKey(keys, "c", 0), ["c", "a", "b", "d"]);
  assert.deepEqual(UOH.moveKey(keys, "a", 3), ["b", "c", "d", "a"]);
  assert.deepEqual(UOH.moveKey(keys, "b", 99), ["a", "c", "d", "b"]);   // clamped to the end
  assert.deepEqual(UOH.moveKey(keys, "zz", 0), keys);                    // not in the group: unchanged
  assert.deepEqual(keys, ["a", "b", "c", "d"]);
  // Dropped after c, a lands between c and d; before b, d lands second.
  assert.deepEqual(UOH.moveKey(keys, "a", UOH.dropIndex(keys, "a", "c", true)), ["b", "c", "a", "d"]);
  assert.deepEqual(UOH.moveKey(keys, "d", UOH.dropIndex(keys, "d", "b", false)), ["a", "d", "b", "c"]);
  assert.equal(UOH.dropIndex(keys, "b", "c", false), 1);              // just before the next card: no move
  assert.equal(UOH.dropIndex(keys, "b", "a", true), 1);               // just after the card above: no move
  assert.equal(UOH.dropIndex(keys, "b", "b", true), 1);               // on itself: no move
  assert.deepEqual(UOH.rankPatch(["Amex|31005", "Amex|84002"]), { "Amex|31005": { rank: 0 }, "Amex|84002": { rank: 1 } });

  var recs = ["11111", "33333", "22222"].map(function (d) {
    return { site: "Amex", m: "Away", v: "Spend $300, earn $60 back", cardId: d,
             card: (d === "33333" ? "Gold Card® ••" : d === "11111" ? "Platinum Card® ••" : "Blue Cash Everyday® ••") + d, ts: NOW };
  });
  var row = UOH.mergeDuplicates(recs, { cards: { "Amex|22222": { rank: 0 }, "Amex|11111": { rank: 1 } } })[0];
  assert.deepEqual(row.cards.map(function (c) { return c.digits; }), ["22222", "11111", "33333"]);   // unranked Gold last
  assert.equal(row.records.length, 3);
});

test("isCreditCardOption keeps credit cards from the Amex switcher", function () {
  var opts = [
    { testid: "simple_switcher_static_option_ALL", aria: "Overview", name: "Overview" },
    { testid: "simple_switcher_static_option_BBP", aria: "Business Blueprint", name: "Business Blueprint" },
    { testid: "simple_switcher_product_option_CARD_PRODUCT_AAAA1111", aria: "Platinum Card® ending in 11111.", name: "Platinum Card®" },
    { testid: "simple_switcher_product_option_CARD_PRODUCT_BBBB2222", aria: "Blue Cash Everyday® ending in 22222.", name: "Blue Cash Everyday®" },
    { testid: "simple_switcher_product_option_AEXP_PERSONAL_CHECKING_ACCOUNT_cccc", aria: "American Express Rewards Checking ending in 3333.", name: "American Express Rewards Checking" },
    { testid: "simple_switcher_product_option_AEXP_PERSONAL_SAVING_ACCOUNT_dddd", aria: "HYSA ending in 4444.", name: "HYSA" },
    { testid: "simple_switcher_product_option_CARD_PRODUCT_EEEE5555", aria: "Personal Loan ending in 55555. This account is Canceled.", name: "Personal Loan" },
    { testid: "simple_switcher_product_option_CARD_PRODUCT_FFFF6666", aria: "Business Platinum Card® ending in 66666.", name: "Business Platinum Card®" }
  ];
  var kept = opts.map(UOH.isCreditCardOption).filter(Boolean);
  assert.deepEqual(kept.map(function (c) { return c.digits; }), ["11111", "22222", "66666"]);
  assert.equal(kept[0].optId, "AAAA1111");
  assert.equal(kept[1].name, "Blue Cash Everyday®");
});

test("assignOffers: higher value wins, ties go to the higher-ranked card", function () {
  var scan = {
    "Amex|11111": [{ m: "The Palm", v: "Spend $150 or more, earn $50 back" }, { m: "Away", v: "Spend $300, earn $60 back" }, { m: "Hulu", v: "10% back" }],
    "Amex|22222": [{ m: "The Palm", v: "Spend $100 or more, earn $25 back" }, { m: "Away", v: "Spend $300, earn $60 back" }, { m: "Fubo TV", v: "Spend $60, earn $30 back" }, { m: "Hulu", v: "15% back" }]
  };
  var rank = { "Amex|11111": 1, "Amex|22222": 0 };                 // the user put card 22222 first
  var out = UOH.assignOffers(scan, function (k) { return rank[k]; });
  assert.deepEqual(out["Amex|11111"], ["thepalm"]);                // $50 beats $25
  assert.deepEqual(out["Amex|22222"], ["away", "fubotv", "hulu"]); // tie -> rank 0; only here; 15% > 10%
  // an excluded (stalled) card gets nothing and its offers move on
  var out2 = UOH.assignOffers(scan, function (k) { return rank[k]; }, { exclude: ["Amex|22222"] });
  assert.equal(out2["Amex|22222"], undefined);
  assert.deepEqual(out2["Amex|11111"], ["away", "hulu", "thepalm"]);
  // with no ranks, switcher order breaks ties
  var out3 = UOH.assignOffers(scan, null, { order: ["Amex|11111", "Amex|22222"] });
  assert.ok(out3["Amex|11111"].indexOf("away") > -1);
});

test("toCsv keeps the v2.5 columns first and quotes values", function () {
  var csv = UOH.toCsv([{ m: 'Joe "J" Co', v: "Spend $60, earn $30 back", site: "Amex", card: "Platinum ••31005", cardId: "31005",
                         t: "DOLLAR", n: 30, status: "added", expiresTs: NOW + 3 * DAY, firstSeen: NOW, ts: NOW }],
                       { now: NOW, cards: { "Amex|31005": { nick: "Jay Plat" } } });
  assert.equal(csv.charCodeAt(0), 0xfeff);
  var lines = csv.slice(1).split("\n");
  assert.equal(lines[0].split(",").slice(0, 15).join(","),
    "Merchant,Offer,Source,Card,Card Last 4,Type,Numeric,Status,Expires,Days Left,Expiry Text,Channel,Badge,First Seen,Last Seen");
  assert.ok(lines[1].indexOf('"Joe ""J"" Co"') === 0);
  assert.ok(lines[1].indexOf('"Jay Plat"') > -1);
  assert.ok(lines[1].indexOf('"31005"') > -1);
});

test("toLiveJson and copyForAiText describe the hub for an outside AI", function () {
  var recs = [
    { m: "Away", v: "Spend $300, earn $60 back", site: "Amex", card: "Platinum ••31005", cardId: "31005", t: "DOLLAR", n: 60,
      status: "added", expiresTs: NOW + 10 * DAY, firstSeen: NOW - DAY, ts: NOW },
    { m: "Old", v: "$5 back", site: "Chase", card: "Freedom ••1234", cardId: "acc1", t: "DOLLAR", n: 5,
      expiresTs: NOW - 3 * DAY, firstSeen: NOW - 40 * DAY, ts: NOW - 30 * DAY }
  ];
  var j = UOH.toLiveJson(recs, { now: NOW });
  assert.equal(j.schema, "universal-offer-hub/offers@1");
  assert.equal(j.offers.length, 2);
  var away = j.offers.filter(function (o) { return o.merchant === "Away"; })[0];
  assert.equal(away.spend_min, 300); assert.equal(away.reward, 60); assert.equal(away.is_new, true);
  assert.equal(away.active, true); assert.equal(away.days_left, 10);
  assert.equal(j.offers.filter(function (o) { return o.merchant === "Old"; })[0].active, false);
  var txt = UOH.copyForAiText(recs, { now: NOW });
  assert.ok(txt.indexOf("(1 offer, as of") > -1);
  assert.ok(txt.indexOf("Away | Spend $300, earn $60 back | Platinum ••31005") > -1);
  assert.equal(txt.indexOf("Old |"), -1);
});

test("retrieve ranks brand hits above keyword and category hits", function () {
  var recs = [
    { m: "Samsonite", v: "Spend $200, earn $40 back", site: "Amex", card: "P ••1", cardId: "1", ts: NOW },
    { m: "Away", v: "Spend $300, earn $60 back", site: "Amex", card: "P ••1", cardId: "1", ts: NOW },
    { m: "Travel Gear Co", v: "10% back", site: "Amex", card: "P ••1", cardId: "1", ts: NOW },
    { m: "Pizza Hut", v: "10% back", site: "Amex", card: "P ••1", cardId: "1", ts: NOW }
  ];
  var rows = UOH.mergeDuplicates(recs, {});
  rows[2].cat = "Travel";
  var got = UOH.retrieve(rows, { brands: ["Away", "Samsonite"], keywords: ["luggage"], categories: ["Travel"] }, { now: NOW }, 10);
  assert.deepEqual(got.map(function (r) { return r.m; }), ["Away", "Samsonite", "Travel Gear Co"]);
});

test("parseQuestion reads dates, new, value, issuer and card from the question", function () {
  var cards = [{ key: "Amex|31005", label: "Jay Plat ••31005", nick: "Jay Plat", name: "Platinum Card®" },
               { key: "Amex|52007", label: "Mom Gold ••52007", nick: "Mom Gold", name: "Gold Card®" },
               { key: "Capital One|4417", label: "Venture X ••4417", name: "Venture X" }];
  var a = UOH.parseQuestion("what is expiring in next 2 days?", { cards: cards });
  assert.equal(a.expiringWithinDays, 2); assert.equal(a.structuredOnly, true); assert.deepEqual(a.topic, []);
  assert.equal(UOH.parseQuestion("What expires this week?").expiringWithinDays, 7);
  assert.equal(UOH.parseQuestion("anything ending today").expiringWithinDays, 0);
  assert.equal(UOH.parseQuestion("offers that expire in two weeks").expiringWithinDays, 14);
  var b = UOH.parseQuestion("new amex offers over $50 on mom's card", { cards: cards });
  assert.equal(b.newOnly, true); assert.equal(b.minValueUsd, 50); assert.deepEqual(b.sources, ["Amex"]);
  assert.deepEqual(b.cardKeys, ["Amex|52007"]); assert.equal(b.structuredOnly, true);
  var c = UOH.parseQuestion("Any luggage offers, like Away or Samsonite?");
  assert.deepEqual(c.categories, ["Travel"]); assert.deepEqual(c.topic, ["luggage", "away", "samsonite"]);
  assert.equal(c.expiringWithinDays, null); assert.equal(c.structuredOnly, false);
  var d = UOH.parseQuestion("Restaurants or stores where I could buy a gift card in person");
  assert.equal(d.giftCards, true); assert.ok(d.categories.indexOf("Dining") > -1); assert.ok(d.categories.indexOf("Gifts & Flowers") < 0);
  var e = UOH.parseQuestion("Birthday gift ideas for my wife");
  assert.deepEqual(e.categories, ["Gifts & Flowers"]); assert.deepEqual(e.topic, ["birthday", "gift"]);
  // a nickname counts only when the question is about a card
  assert.deepEqual(UOH.parseQuestion("gift ideas for my mom", { cards: cards }).cardKeys, []);
  assert.deepEqual(UOH.parseQuestion("what's on my platinum", { cards: cards }).cardKeys, ["Amex|31005"]);
  assert.equal(UOH.parseQuestion("offers that expire in two weeks").structuredOnly, true);
});

test("retrieve applies the question's filters strictly (no 44-day offer for 'next 2 days')", function () {
  var DAYS = 86400000;
  var recs = [
    { m: "Rosewood", v: "Spend $750 or more, earn $150 back", site: "Amex", card: "Platinum ••31005", cardId: "31005", ts: NOW, expiresTs: NOW + 1 * DAYS },
    { m: "Samaritaine", v: "Spend $350 or more, earn $75 back", site: "Amex", card: "Platinum ••31005", cardId: "31005", ts: NOW, expiresTs: NOW + 44 * DAYS },
    { m: "Walmart Marketplace", v: "37,500 miles", site: "Capital One", card: "Venture X ••4417", cardId: "4417", ts: NOW },
    { m: "John Varvatos", v: "Spend $300 or more, earn $70 back", site: "Amex", card: "Platinum ••31005", cardId: "31005", ts: NOW, expiresTs: NOW + 2 * DAYS }
  ];
  var rows = UOH.mergeDuplicates(recs, {});
  var q = UOH.parseQuestion("what is expiring in next 2 days?");
  var got = UOH.retrieve(rows, q, { now: NOW }, 50);
  assert.deepEqual(got.map(function (r) { return r.m; }), ["Rosewood", "John Varvatos"]);   // soonest first, nothing past 2 days
  var amex = UOH.retrieve(rows, { sources: ["Capital One"] }, { now: NOW }, 50);
  assert.deepEqual(amex.map(function (r) { return r.m; }), ["Walmart Marketplace"]);
  // stop words alone never match anything
  assert.equal(UOH.retrieve(rows, { keywords: ["is", "in", "a"] }, { now: NOW }, 50).length, 0);
});

test("readChatMessage: commands never become search words; follow-ups keep the earlier filters", function () {
  var cards = [{ key: "Amex|31005", label: "Jay Plat ••31005", nick: "Jay Plat", name: "Platinum Card®" },
               { key: "Chase|acc9", label: "Sapphire ••2453", name: "Sapphire Preferred" }];
  var ctx = { cards: cards };
  var a = UOH.readChatMessage("what is expiring in next 5 days?", null, ctx);
  assert.equal(a.plan.expiringWithinDays, 5); assert.equal(a.cont, false); assert.equal(a.subject, false);
  var b = UOH.readChatMessage("only chase", a.plan, ctx);
  assert.deepEqual(b.plan.sources, ["Chase"]); assert.equal(b.plan.expiringWithinDays, 5);
  assert.deepEqual(b.plan.topic, []); assert.equal(b.cont, true);
  var c = UOH.readChatMessage("export these as csv", b.plan, ctx);
  assert.equal(c.action.file, "csv"); assert.equal(c.command, true); assert.deepEqual(c.plan.topic, []);
  assert.deepEqual(c.plan.sources, ["Chase"]);
  var d = UOH.readChatMessage("show all", b.plan, ctx);
  assert.equal(d.action.showAll, true); assert.deepEqual(d.plan.categories, []); assert.deepEqual(d.plan.topic, []);
  var e = UOH.readChatMessage("sort by value", b.plan, ctx);
  assert.equal(e.plan.sort, "value"); assert.deepEqual(e.plan.topic, []); assert.equal(e.command, true);
  var f = UOH.readChatMessage("what about restaurants?", b.plan, ctx);
  assert.deepEqual(f.plan.categories, ["Dining"]); assert.equal(f.plan.expiringWithinDays, 5); assert.equal(f.subject, true);
  var g = UOH.readChatMessage("anything worth more than $50", b.plan, ctx);
  assert.equal(g.action.showAll, false); assert.equal(g.plan.minValueUsd, 50);
  var h = UOH.readChatMessage("top 10 as json", b.plan, ctx);
  assert.equal(h.action.top, 10); assert.equal(h.action.file, "json"); assert.equal(h.plan.sort, "value");
  var i = UOH.readChatMessage("any time, on all cards", b.plan, ctx);
  assert.equal(i.plan.expiringWithinDays, null); assert.deepEqual(i.plan.sources, []); assert.deepEqual(i.plan.topic, []);
  // A new subject replaces the old one, with the model's brand ideas; a filter keeps them.
  var lug = UOH.readChatMessage("luggage offers", null, ctx);
  lug.plan.brands = ["Away", "Samsonite"];
  var j = UOH.readChatMessage("on my platinum", lug.plan, ctx);
  assert.deepEqual(j.plan.brands, ["Away", "Samsonite"]); assert.deepEqual(j.plan.cardKeys, ["Amex|31005"]);
  assert.deepEqual(j.plan.categories, ["Travel"]); assert.equal(j.cont, true);
  var k = UOH.readChatMessage("what about pizza", lug.plan, ctx);
  assert.deepEqual(k.plan.brands, []); assert.deepEqual(k.plan.categories, ["Dining"]); assert.deepEqual(k.plan.topic, ["pizza"]);
  assert.equal(k.cont, false);                           // nothing from "luggage" was used
  // "show" in a real question still counts ("any broadway shows")
  assert.deepEqual(UOH.readChatMessage("any broadway shows?", null, ctx).plan.categories, ["Entertainment"]);
});

test("describePlan reads a plan back in plain words; Copy text has no AI instructions", function () {
  var cards = [{ key: "Chase|acc9", label: "Sapphire ••2453" }];
  var p = UOH.readChatMessage("chase offers expiring in 5 days, biggest first", null, { cards: cards }).plan;
  assert.deepEqual(UOH.describePlan(p, { cards: cards }), ["expiring within 5 days", "Chase", "biggest first"]);
  var lug = UOH.readChatMessage("luggage", null, {}).plan;
  lug.brands = ["Away", "Luggage"];
  assert.deepEqual(UOH.describePlan(lug, {}), ["luggage, Away", "Travel"]);
  var rows = UOH.mergeDuplicates([{ m: "Away", v: "$60 back", site: "Amex", card: "P ••1", cardId: "1", ts: NOW }], {});
  var txt = UOH.rowsAiText(rows, { now: NOW, filters: "Amex" });
  assert.ok(txt.indexOf("Shown: Amex.") > -1);
  assert.equal(txt.indexOf("Answer using only"), -1);
});

test("readChatMessage on the questions from Jay's 2026-10-29 chat", function () {
  var two = UOH.readChatMessage("what is expiring in next 2 days?", null, {}).plan;
  var a = UOH.readChatMessage("3 days?", two, {});
  assert.equal(a.plan.expiringWithinDays, 3); assert.deepEqual(a.plan.topic, []);
  var b = UOH.readChatMessage("I asked for offers expiring in 3 days", two, {});
  assert.equal(b.plan.expiringWithinDays, 3); assert.deepEqual(b.plan.topic, []); assert.equal(b.subject, false);
  // A new subject starts fresh: the 3-day window doesn't follow it.
  var c = UOH.readChatMessage("find me 1 offer which is highest value offer for hotel bookings", b.plan, {});
  assert.equal(c.plan.expiringWithinDays, null); assert.equal(c.action.top, 1); assert.equal(c.plan.sort, "value");
  assert.deepEqual(c.plan.categories, ["Hotels"]); assert.equal(c.cont, false);
  var hotel3 = UOH.readChatMessage("hotel offers expiring in 3 days", null, {}).plan;
  var d = UOH.readChatMessage("Not just 3 days. Best hotel offer across all offers we have", hotel3, {});
  assert.equal(d.plan.expiringWithinDays, null); assert.deepEqual(d.plan.topic, ["hotel"]); assert.equal(d.plan.sort, "value");
  // Pointing back keeps the filters and swaps the subject.
  var five = UOH.readChatMessage("what is expiring in next 5 days?", null, {}).plan;
  var e = UOH.readChatMessage("which of these are restaurants", five, {});
  assert.equal(e.plan.expiringWithinDays, 5); assert.deepEqual(e.plan.categories, ["Dining"]); assert.equal(e.cont, true);
  var f = UOH.readChatMessage("any luggage offers?", five, {});
  assert.equal(f.plan.expiringWithinDays, null); assert.equal(f.cont, false);
});

test("cardsHashSite: the Cards panel's section from the address, a site with a space included", function () {
  assert.equal(UOH.cardsHashSite("#cards-Capital%20One"), "Capital One");     // how Chrome keeps the space
  assert.equal(UOH.cardsHashSite("#cards-Capital One"), "Capital One");
  assert.equal(UOH.cardsHashSite("#cards-Chase"), "Chase");
  assert.equal(UOH.cardsHashSite("#cards"), "");
  assert.equal(UOH.cardsHashSite("#cards-%E0%A4"), "%E0%A4");                  // a bad escape stays as it is
  assert.equal(UOH.cardsHashSite("#ask"), null);
  assert.equal(UOH.cardsHashSite(""), null);
});
