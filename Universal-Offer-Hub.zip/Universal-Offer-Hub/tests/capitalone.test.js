/*
 * Unit tests for lib/issuers/capitalone.js: reading Capital One's card labels
 * (the offers page's header and card menu, the account tiles), the card the
 * header names read the way "Run CapitalOne Autopilot" reads it, and the card
 * menu turned into the login's cards. Made-up endings only.
 *   node --test --test-timeout=30000 tests/*.test.js
 */
"use strict";
var test = require("node:test");
var assert = require("node:assert/strict");
var fs = require("fs"), path = require("path");
globalThis.self = globalThis;
require("../lib/sources.js");
require("../lib/issuers/capitalone.js");
var UOH = require("../lib/offers.js");
var C = globalThis.UOH_ISSUERS["Capital One"];

test("the issuer is the Capital One source: the site on every offer its autopilot saves", function () {
  var src = globalThis.UOH_SOURCES.filter(function (s) { return s.id === "Capital One"; })[0];
  assert.ok(src);
  assert.equal(C.id, src.id); assert.equal(C.label, "Capital One");
  assert.equal(C.adds, false); assert.equal(C.ordered, false); assert.equal(C.spa, true);
  assert.equal(C.autopilotMs, 250);
  assert.match(C.explain, /Run CapitalOne Autopilot/);
  assert.match(C.explain, /doesn't activate any offer/);
});

test("card labels from the header, the card menu and the account tiles", function () {
  assert.deepEqual(C.parseCardLabel("Venture X...4417"), { name: "Venture X", last4: "4417" });
  assert.deepEqual(C.parseCardLabel("  Discover it …7720 "), { name: "Discover it", last4: "7720" });
  assert.deepEqual(C.parseCardLabel("Savor••7720"), { name: "Savor", last4: "7720" });
  assert.deepEqual(C.parseCardLabel(" ...4417 "), { name: "", last4: "4417" });
  assert.deepEqual(C.parseCardLabel(" ending in ...4417 "), { name: "", last4: "4417" });
  assert.equal(C.parseCardLabel("Apply my offer to:").last4, "");
  assert.equal(C.parseCardLabel("").last4, "");
});

test("the card on screen is read the way Run CapitalOne Autopilot reads it", function () {
  assert.deepEqual(C.headerCard(["Venture X...4417", ""]), { last4: "4417", name: "Venture X", text: "Venture X...4417" });
  // Longer than 60 characters, or no 4 digits: skipped, as content/scraper.js skips them.
  var long = "Earn up to 5X miles on hotels and rental cars you book through Capital One Travel in 2026";
  assert.ok(long.length > 60);
  assert.equal(C.headerCard([long, "Discover it...7720"]).last4, "7720");
  assert.equal(C.headerCard(["Featured Offers for You", "  Discover it...7720  "]).name, "Discover it");
  assert.deepEqual(C.headerCard([]), { last4: "", name: "", text: "" });
  // The same elements and the same rule as capOneCardInfo() in content/scraper.js.
  var scraper = fs.readFileSync(path.join(__dirname, "..", "content", "scraper.js"), "utf8");
  var page = fs.readFileSync(path.join(__dirname, "..", "content", "capitalone-auto.js"), "utf8");
  var fn = scraper.slice(scraper.indexOf("var capOneCardInfo"), scraper.indexOf("var updateLastRun"));
  assert.ok(fn.indexOf("querySelectorAll('p.text-white, button p, header p')") > -1, "capOneCardInfo's elements");
  assert.ok(fn.indexOf("t.length > 60") > -1 && fn.indexOf("t.match(/(\\d{4})\\b/)") > -1, "capOneCardInfo's rule");
  assert.ok(page.indexOf('header: "p.text-white, button p, header p"') > -1, "capitalone-auto.js reads the same elements");
});

var MENU = [{ label: "Venture X...4417", selected: true }, { label: "Discover it...7720", selected: false }];

test("the card menu becomes the login's cards, keyed as the autopilot saves them", function () {
  var r = C.cards({ options: MENU, shown: "Venture X...4417" });
  assert.deepEqual(r.cards, [
    { key: "Capital One|4417", id: "4417", digits: "4417", name: "Venture X" },
    { key: "Capital One|7720", id: "7720", digits: "7720", name: "Discover it" }
  ]);
  assert.equal(r.initialId, "4417");                            // the checked entry
  assert.deepEqual(r.loginIds, ["4417", "7720"]);
  assert.deepEqual(r.endings, ["4417", "7720"]);
  assert.deepEqual(r.notes, []);
  // Offers saved by the autopilot (site "Capital One", cardId = last 4) are this card.
  assert.equal(r.cards[0].key, UOH.cardKey({ site: "Capital One", cardId: "4417" }));
  // Nothing checked: the card the header names.
  r = C.cards({ options: [{ label: "Venture X...4417" }, { label: "Discover it...7720" }], shown: "Discover it...7720" });
  assert.equal(r.initialId, "7720");
});

test("two cards ending the same are run once; a login without a menu has the header's card", function () {
  var r = C.cards({ options: [{ label: "Venture X...4417" }, { label: "Savor...4417" }, { label: "Apply my offer to:" }], shown: "" });
  assert.deepEqual(r.cards.map(function (c) { return c.key; }), ["Capital One|4417"]);
  assert.equal(r.notes.length, 2);
  assert.match(r.notes[0], /Savor ••4417: ends like another card/);
  assert.match(r.notes[1], /no card ending/);

  r = C.cards({ options: [], shown: "Venture X...4417" });
  assert.deepEqual(r.cards, [{ key: "Capital One|4417", id: "4417", digits: "4417", name: "Venture X" }]);
  assert.equal(r.initialId, "4417");
  assert.equal(C.cards({ options: [], shown: "" }).cards.length, 0);
  assert.equal(C.cards({}).cards.length, 0);
});

test("the run opens Capital One Offers; which hosts are Capital One's", function () {
  assert.equal(C.startUrl("https://myaccounts.capitalone.com"), "https://capitaloneoffers.com/feed");
  assert.equal(C.startUrl("chrome-extension://abc"), "https://capitaloneoffers.com/feed");
  assert.equal(C.route("add", {}, "https://capitaloneoffers.com/feed"), null);
  // The run tab's pages: the offers site only.
  assert.ok(C.pageRe.test("https://capitaloneoffers.com/feed?viewInstanceId=00000000-0000-4000-8000-000000000001"));
  assert.ok(C.pageRe.test("https://www.capitaloneoffers.com/feed"));
  ["https://www.capitalone.com/", "https://verified.capitalone.com/sign-in", "https://myaccounts.capitalone.com/accountSummary",
   "https://capitaloneoffers.com.evil.example/feed"].forEach(function (u) { assert.ok(!C.pageRe.test(u), u); });
  // A sign-in (myaccounts) or the run tab.
  assert.ok(C.hostRe.test("https://myaccounts.capitalone.com/accountSummary"));
  assert.ok(C.hostRe.test("https://capitaloneoffers.com/feed"));
  assert.ok(!C.hostRe.test("https://capitaloneshopping.com/"));
  assert.ok(!C.hostRe.test("https://verified.capitalone.com/sign-in"));
  ["myaccounts.capitalone.com", "capitaloneoffers.com", "www.capitaloneoffers.com"].forEach(function (h) { assert.ok(C.siteRe.test(h), h); });
  ["capitaloneshopping.com", "notcapitalone.com", "capitaloneoffers.com.evil.example"].forEach(function (h) { assert.ok(!C.siteRe.test(h), h); });
});
