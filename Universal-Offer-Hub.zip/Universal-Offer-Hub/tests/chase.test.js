/*
 * Unit tests for lib/issuers/chase.js: reading Chase's account labels and
 * offer tiles, matching the offers page's account list to the overview's
 * account ids. Synthetic ids and endings only.
 *   node --test --test-timeout=30000 tests/*.test.js
 */
"use strict";
var test = require("node:test");
var assert = require("node:assert/strict");
require("../lib/issuers/chase.js");
var C = globalThis.UOH_ISSUERS.Chase;

test("account labels from the overview, the account list and the selector", function () {
  assert.deepEqual(C.parseAccountLabel("Sapphire Reserve (...1111)"), { name: "Sapphire Reserve", last4: "1111" });
  assert.deepEqual(C.parseAccountLabel("Sapphire Reserve...1111"), { name: "Sapphire Reserve", last4: "1111" });
  assert.deepEqual(C.parseAccountLabel("  CHASE COLLEGE  (...2222) "), { name: "CHASE COLLEGE", last4: "2222" });
  assert.deepEqual(C.parseAccountLabel("Freedom Unlimited (…3333)"), { name: "Freedom Unlimited", last4: "3333" });
  assert.equal(C.parseAccountLabel("Choose account").last4, "");
});

test("offer tiles, the wallet count and the account id in the address", function () {
  assert.deepEqual(C.parseTileLabel("1 of 162 Sprouts Farmers Market 5% cash back Add Offer"),
                   { pos: 1, total: 162, added: false });
  assert.deepEqual(C.parseTileLabel("14 of 162 CarParts.com 5% cash back 12 days left Success Added"),
                   { pos: 14, total: 162, added: true });
  assert.deepEqual(C.parseTileLabel(""), { pos: 0, total: 0, added: false });
  assert.equal(C.walletAdded("$12.00 Total amount saved  7 Added offers  3 Expiring offers"), 7);
  assert.equal(C.walletAdded("$1,204.00 Total amount saved 1,020 Added offers"), 1020);
  assert.equal(C.walletAdded(""), null);
  assert.equal(C.accountIdFromHash("#/dashboard/merchantOffers/offer-hub?accountId=2000000002"), "2000000002");
  assert.equal(C.accountIdFromHash("#/dashboard/overview"), "");
});

var ACCOUNTS = [
  { id: "1000000001", label: "CHASE COLLEGE (...2222)" },
  { id: "2000000002", label: "Sapphire Reserve (...1111)" },
  { id: "3000000003", label: "Total Savings (...4444)" }
];
var OPTIONS = [
  { label: "CHASE COLLEGE (...2222)", selected: false },
  { label: "Sapphire Reserve (...1111)", selected: true },
  { label: "Ink Business Cash (...5555)", selected: false }
];

test("the account list maps to the overview's account ids by the last 4", function () {
  var r = C.cards({ accounts: ACCOUNTS, options: OPTIONS, shown: "Sapphire Reserve...1111", hashId: "" });
  assert.deepEqual(r.cards, [
    { key: "Chase|1000000001", id: "1000000001", digits: "2222", name: "CHASE COLLEGE" },
    { key: "Chase|2000000002", id: "2000000002", digits: "1111", name: "Sapphire Reserve" }
  ]);
  assert.equal(r.initialId, "2000000002");                         // the selected entry
  assert.deepEqual(r.loginIds, ["1000000001", "2000000002", "3000000003"]);
  // An entry with no account id is noted and skipped, never saved under a made-up key.
  assert.equal(r.notes.length, 1);
  assert.match(r.notes[0], /Ink Business Cash ••5555: not found/);
  // Every ending of the login, so the savings account or the skipped card isn't "another login".
  ["2222", "1111", "4444", "5555"].forEach(function (d) { assert.ok(r.endings.indexOf(d) > -1, d); });

  // The account id in the address names the card on screen.
  assert.equal(C.cards({ accounts: ACCOUNTS, options: OPTIONS, shown: "", hashId: "1000000001" }).initialId, "1000000001");
  // An id in the address that isn't one of the cards doesn't count.
  assert.equal(C.cards({ accounts: ACCOUNTS, options: OPTIONS, shown: "", hashId: "3000000003" }).initialId, "2000000002");
});

test("two accounts ending the same: the name decides; a login without a list has one card", function () {
  var twins = [{ id: "1", label: "Freedom (...7777)" }, { id: "2", label: "Slate Edge (...7777)" }];
  var r = C.cards({ accounts: twins, options: [{ label: "Slate Edge (...7777)" }, { label: "Freedom (...7777)" }] });
  assert.deepEqual(r.cards.map(function (c) { return c.id; }), ["2", "1"]);

  // No account list: the card the selector names...
  r = C.cards({ accounts: ACCOUNTS, options: [], shown: "Sapphire Reserve...1111" });
  assert.deepEqual(r.cards.map(function (c) { return c.key; }), ["Chase|2000000002"]);
  assert.equal(r.initialId, "2000000002");
  // ...or the login's only account.
  r = C.cards({ accounts: [ACCOUNTS[1]], options: [], shown: "" });
  assert.deepEqual(r.cards.map(function (c) { return c.key; }), ["Chase|2000000002"]);
  // Nothing to go on: no cards.
  assert.equal(C.cards({ accounts: ACCOUNTS, options: [], shown: "" }).cards.length, 0);
});

test("the run opens the overview on the host the user is signed into", function () {
  assert.equal(C.startUrl("https://secure05ea.chase.com"), "https://secure05ea.chase.com/web/auth/dashboard#/dashboard/overview");
  assert.equal(C.startUrl("https://secure.chase.com"), "https://secure.chase.com/web/auth/dashboard#/dashboard/overview");
  assert.equal(C.startUrl("https://www.chase.com"), "https://secure.chase.com/web/auth/dashboard#/dashboard/overview");
  assert.equal(C.startUrl(""), "https://secure.chase.com/web/auth/dashboard#/dashboard/overview");
  assert.ok(C.pageRe.test("https://secure.chase.com/web/auth/dashboard#/dashboard/merchantOffers/offer-hub"));
  assert.ok(!C.pageRe.test("https://secure.chase.com/web/auth/#/logon/logon/chaseOnline"));
  assert.ok(C.hostRe.test("https://secure05ea.chase.com/web/auth/dashboard"));
  assert.ok(C.siteRe.test("secure.chase.com") && !C.siteRe.test("notchase.com"));
  assert.equal(C.route("add", {}, "https://secure.chase.com/web/auth/dashboard#/dashboard/overview"), null);
});
