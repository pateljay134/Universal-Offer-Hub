/*
 * Shared by the MCP plugin tests: a sample offers.json, and the plugin
 * started as its own process the way an AI app runs it (JSON-RPC over stdio).
 * Not a test file itself (tests/*.test.js only).
 */
"use strict";
var cp = require("child_process"), fs = require("fs"), os = require("os"), path = require("path");
global.self = global;
var UOH = require("../lib/offers.js");

var PLUGIN = path.join(__dirname, "../mcp/offer-hub-mcp.js");

// A folder holding offers.json: two hotel offers (one on two cards), one ending tomorrow, one expired.
function fixture() {
  var dir = fs.mkdtempSync(path.join(os.tmpdir(), "uoh-mcp-"));
  var now = Date.now(), DAY = 86400000;
  var orient = { m: "Orient Express - Hotel & Train Reservations", v: "Spend $2,000 or more, earn $400 back", site: "Amex",
                 ts: now, expiresTs: now + 60 * DAY, firstSeen: now - 30 * DAY };
  var recs = [
    Object.assign({ card: "Platinum Card® ••22001", cardId: "22001" }, orient),
    Object.assign({ card: "Blue Cash Everyday® ••91009", cardId: "91009" }, orient),
    { m: "Hyatt: Miraval & Alila", v: "$250 cash back", site: "Chase", card: "Chase ••7319", cardId: "acc1", last4: "7319",
      ts: now, expiresTs: now + 40 * DAY, firstSeen: now - DAY },
    { m: "Pizza Hut", v: "10% back", site: "Amex", card: "Platinum Card® ••22001", cardId: "22001", ts: now,
      expiresTs: now + 1 * DAY, firstSeen: now - 40 * DAY },
    { m: "Old Hotel", v: "$5 back", site: "Amex", card: "Platinum Card® ••22001", cardId: "22001", ts: now,
      expiresTs: now - 3 * DAY, firstSeen: now - 50 * DAY }
  ];
  var json = UOH.toLiveJson(recs, {
    now: now, cards: { "Amex|22001": { nick: "Jay Plat" } },
    categoryOf: function (o) { return /hotel|hyatt|express/i.test(o.m) ? "Hotels" : "Dining"; }
  });
  fs.writeFileSync(path.join(dir, "offers.json"), JSON.stringify(json));
  return dir;
}

// script: the plugin file to run (default: the repo's own copy).
function start(dir, script) {
  var child = cp.spawn(process.execPath, [script || PLUGIN, "--dir", dir], { stdio: ["pipe", "pipe", "pipe"] });
  var buf = "", waiting = {}, id = 0;
  child.stdout.on("data", function (d) {
    buf += d;
    var i;
    while ((i = buf.indexOf("\n")) > -1) {
      var text = buf.slice(0, i); buf = buf.slice(i + 1);
      if (!text.trim()) continue;
      var m = JSON.parse(text);
      if (waiting[m.id]) { waiting[m.id](m); delete waiting[m.id]; }
    }
  });
  return {
    call: function (method, params) {
      var my = ++id;
      return new Promise(function (res) {
        waiting[my] = res;
        child.stdin.write(JSON.stringify({ jsonrpc: "2.0", id: my, method: method, params: params || {} }) + "\n");
      });
    },
    notify: function (method) { child.stdin.write(JSON.stringify({ jsonrpc: "2.0", method: method }) + "\n"); },
    close: function () { child.stdin.end(); child.kill(); }
  };
}
function text(r) { return r.result.content[0].text; }

module.exports = { fixture: fixture, start: start, text: text };
