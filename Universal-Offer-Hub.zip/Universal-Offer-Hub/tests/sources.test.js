/*
 * Unit tests for lib/sources.js: which source the popup detects on a page,
 * and that each source is told apart (its id, short name and color).
 *   node --test --test-timeout=30000 tests/*.test.js
 */
"use strict";
var test = require("node:test");
var assert = require("node:assert/strict");
globalThis.self = globalThis;
require("../lib/sources.js");

function id(url) { var s = globalThis.UOH_detectSource(url); return s ? s.id : null; }

test("Capital One Shopping is its own source, apart from Capital One's card offers", function () {
  assert.equal(id("https://capitaloneshopping.com/"), "Capital One Shopping");
  assert.equal(id("https://www.capitaloneshopping.com/event/preview-black-friday-offers"), "Capital One Shopping");
  assert.equal(id("https://capitaloneoffers.com/feed?viewInstanceId=00000000-0000-4000-8000-000000000001"), "Capital One");
  assert.equal(id("https://myaccounts.capitalone.com/accountSummary"), "Capital One");
  assert.equal(id("https://www.walgreens.com/offers/offers.jsp"), "Walgreens");
  assert.equal(id("https://example.com/"), null);
  var c1s = globalThis.UOH_SOURCES.filter(function (s) { return s.id === "Capital One Shopping"; })[0];
  assert.equal(c1s.shortName, "CapitalOne Shopping");
  assert.equal(c1s.landingUrl, "https://capitaloneshopping.com/");
  // Only Capital One Shopping gets the choice of minutes beside Run.
  assert.equal(c1s.runMinutes, 5);
  assert.deepEqual(globalThis.UOH_SOURCES.filter(function (s) { return s.runMinutes; }).map(function (s) { return s.id; }),
                   ["Capital One Shopping"]);
});

test("every source has its own id, short name and color, and a landing page it detects", function () {
  var S = globalThis.UOH_SOURCES;
  ["id", "shortName", "color"].forEach(function (f) {
    var vals = S.map(function (s) { return String(s[f]).toLowerCase(); });
    assert.equal(new Set(vals).size, vals.length, f + ": " + vals.join(", "));
  });
  S.forEach(function (s) { assert.equal(id(s.landingUrl), s.id, s.landingUrl); });
});
