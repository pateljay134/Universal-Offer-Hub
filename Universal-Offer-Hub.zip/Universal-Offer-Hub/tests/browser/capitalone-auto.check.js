/*
 * Browser check: Capital One auto-add on made-up Capital One pages in headless
 * Chrome (capitalone-feed.fixture.html as /feed at
 * capitaloneoffers.com.localhost, capitalone-summary.fixture.html as
 * /accountSummary at myaccounts.capitalone.com.localhost). The page scripts
 * (content/capitalone-auto.js on content/auto-core.js) read the card menu,
 * pick each card and run "Run CapitalOne Autopilot" itself
 * (content/scraper.js) on the service worker's clock, as lib/autorun.js does.
 *   node tests/browser/capitalone-auto.check.js
 * Needs Node 22 or later; set CHROME when Chrome isn't at the macOS default.
 */
"use strict";
var assert = require("node:assert/strict");
var H = require("./harness.js");

// The fixture's offers: "Alpha Store 0..11" on Venture X ••4417 (6 shown, two
// more pages of 3), "Beta Store 0..8" on Discover it ••7720 (6, one more page).
function keys(prefix, last4, n) {
  var out = [];
  for (var i = 0; i < n; i++) out.push("cap1_" + last4 + "_" + (prefix + " Store " + i).replace(/\W/g, ""));
  return out;
}
var ALPHA = keys("Alpha", "4417", 12), BETA = keys("Beta", "7720", 9);

// Exactly these offers were saved, each under its own card, and nothing was
// activated.
function saved(out, expected) {
  var sw = out.sw;
  assert.deepEqual(Object.keys(sw.saves).sort(), expected.slice().sort(), "saved keys");
  expected.forEach(function (k) {
    var o = sw.saves[k], d = k.split("_")[1];
    assert.equal(o.site, "Capital One", k); assert.equal(o.cardId, d, k); assert.equal(o.status, "available", k);
  });
  if (expected.indexOf(ALPHA[0]) > -1) assert.equal(sw.saves[ALPHA[0]].card, "Venture X ••4417");
  if (expected.indexOf(BETA[0]) > -1) assert.equal(sw.saves[BETA[0]].card, "Discover it ••7720");
  assert.equal((out.count || {})["add offers"], undefined, "Add Offers never pressed");
}

function bothCards(out) {
  assert.deepEqual(out.errors, [], "page errors");
  var sw = out.sw;
  assert.deepEqual(sw.fails, [], "failed jobs");
  assert.deepEqual(sw.results.map(function (r) { return r.job + " " + (r.card || ""); }),
                   ["discover ", "add Capital One|7720", "add Capital One|4417"]);
  var d = sw.results[0].result;
  assert.deepEqual(d.options, [{ label: "Venture X...4417", selected: true }, { label: "Discover it...7720", selected: false }]);
  assert.equal(d.shown, "Venture X...4417");
  var B = sw.results[1].result, A = sw.results[2].result;
  assert.equal(B.note, "Done (9)"); assert.equal(B.saved, 9); assert.equal(B.count, 0);
  assert.equal(A.note, "Done (12)"); assert.equal(A.saved, 12); assert.equal(A.count, 0);
  saved(out, ALPHA.concat(BETA));
  // Its status line reached the service worker as progress.
  assert.ok(sw.progress.some(function (t) { return /^Loading\.\.\. \(\d+\)$/.test(t); }), "progress: " + sw.progress.join(" | "));
  assert.equal(out.count["more 4417"], 2); assert.equal(out.count["more 7720"], 1);
  assert.equal(out.count.picks, 2, "picked 7720, then 4417");
}

var FEED = { host: "capitaloneoffers.com.localhost", path: "/feed" };
var DONE = "JSON.parse(sessionStorage.getItem('fx_sw') || '{}').finished";
function loads(out) { return out.log.filter(function (e) { return /^load/.test(e); }); }
var CASES = [
  { name: "reads the card menu and runs Run CapitalOne Autopilot on each card", at: FEED, query: "", check: function (out) {
      bothCards(out);
      // The second card is picked on a fresh page: the first card's run left this one heavy.
      assert.deepEqual(loads(out), ["load 4417", "load 7720"]);
    } },
  { name: "Capital One's handler for picking sits on the card's name", at: FEED, query: "pick=inner", check: bothCards },
  { name: "Capital One picks a card only from its radio button", at: FEED, query: "pick=radio", check: bothCards },
  { name: "Capital One ignores events a script sends: the pick is played through React's handlers", at: FEED, query: "trusted=1", check: function (out) {
      bothCards(out);
      assert.equal(out.count["react clicks"], 2, "one played click per switch");
      assert.equal(out.count.ignored, undefined, "no script-sent pick was needed");
    } },
  { name: "in a tab you can see (a closed menu leaves the page)", at: FEED, query: "visible=1", check: bothCards },
  { name: "Capital One slow to show the picked card: the run waits for the header", at: FEED, query: "switch=2500", check: bothCards },
  { name: "the last card's offers linger after a switch: none saved under the new card", at: FEED, query: "tiles=3000", check: bothCards },
  { name: "picking a card loads the page again: the same job carries on", at: FEED, query: "reload=1", check: function (out) {
      bothCards(out);
      assert.deepEqual(loads(out), ["load 4417", "load 7720", "load 7720", "load 4417"]);
    } },
  { name: "a card that can't be picked fails, saying what was tried; the next card still runs", at: FEED, query: "pick=none", check: function (out) {
      assert.deepEqual(out.errors, [], "page errors");
      assert.deepEqual(out.sw.results.map(function (r) { return r.job + " " + (r.card || ""); }), ["discover ", "add Capital One|4417"]);
      assert.equal(out.sw.fails.length, 1);
      assert.equal(out.sw.fails[0].card, "Capital One|7720");
      assert.equal(out.sw.fails[0].reason, "switch-failed: menu opened 3 of 3 tries; " +
        "react (row.onPointerDown,row.onPointerUp,row.onClick; menu closed), pointer (menu closed), radio (menu closed); " +
        "the page kept ••4417, also after loading it again");
      assert.deepEqual(loads(out), ["load 4417", "load 4417"]);
      saved(out, ALPHA);
    } },
  { name: "a login with one card and no card menu", at: FEED, query: "single=1", check: function (out) {
      assert.deepEqual(out.errors, [], "page errors");
      assert.deepEqual(out.sw.fails, [], "failed jobs");
      assert.deepEqual(out.sw.results[0].result, { options: [], shown: "Venture X...4417" });
      assert.equal(out.sw.results[1].card, "Capital One|4417");
      saved(out, ALPHA);
    } },
  { name: "Run CapitalOne Autopilot from the toolbar is unchanged (its own timers, no ticks)", at: FEED, query: "manual=1",
    done: "JSON.parse(sessionStorage.getItem('fx_manualFinished') || 'false')", check: function (out) {
      assert.deepEqual(out.errors, [], "page errors");
      assert.deepEqual(out.sw.results, [], "no auto-add jobs");
      assert.deepEqual(out.manualDone, { note: "Done (12)", saved: 12, added: 0 });
      assert.equal(out.title, "Done (12)");
      assert.equal(out.ticks, null);
      saved(out, ALPHA);
    } },
  { name: "the sign-in page reports the account tiles' endings", at: { host: "myaccounts.capitalone.com.localhost", path: "/accountSummary" },
    query: "", done: "sessionStorage.getItem('fx_seen')", check: function (out) {
      assert.deepEqual(out.errors, [], "page errors");
      assert.deepEqual(out.seen, ["4417", "7720", "9001"]);
    } }
];

var RESULT = "JSON.stringify({ sw: JSON.parse(sessionStorage.getItem('fx_sw') || '{}'), " +
  "count: JSON.parse(sessionStorage.getItem('fx_count') || '{}'), log: JSON.parse(sessionStorage.getItem('fx_log') || '[]'), " +
  "seen: JSON.parse(sessionStorage.getItem('fx_seen') || 'null'), manualDone: JSON.parse(sessionStorage.getItem('fx_manualDone') || 'null'), " +
  "title: (document.getElementById('c1-ti') || {}).innerText || '', ticks: sessionStorage.getItem('UOH_AutoTicks') })";

H.serve({ "/feed": "tests/browser/capitalone-feed.fixture.html", "/accountSummary": "tests/browser/capitalone-summary.fixture.html" })
  .then(function (server) {
    return H.cases(CASES, function (c) {
      return H.run("http://" + c.at.host + ":" + server.port + c.at.path + (c.query ? "?" + c.query : ""),
                   c.done || DONE, RESULT, 180000);
    });
  });
