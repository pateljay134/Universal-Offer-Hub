/*
 * Browser check: Run CapitalOne Shopping Autopilot (content/scraper.js) on a
 * made-up Capital One Shopping home page in headless Chrome
 * (capitaloneshopping.fixture.html as /home at
 * capitaloneshopping.com.localhost). The autopilot reads the offers on the
 * page for the minutes it's given, scrolling down as the page adds more, and
 * presses nothing. Per store it saves the best rate without an end date, and
 * a rate with an end date apart when it beats that one.
 *   node tests/browser/capitaloneshopping.check.js
 * Needs Node 22 or later; set CHROME when Chrome isn't at the macOS default.
 */
"use strict";
var assert = require("node:assert/strict");
var H = require("./harness.js");

var SITE = "Capital One Shopping";
// The end of the day `days` after `at`, or of the day `hours` after `at` falls on.
function endOf(at, days, hours) {
  var d = new Date(at + (hours || 0) * 3600000);
  d.setDate(d.getDate() + (days || 0));
  d.setHours(23, 59, 59, 999);
  return d.getTime();
}

// The fixture's offers: one entry per store and rate ("__event" for a rate
// shown only with an end date); end: [days, hours] from the run. link: the
// offer's own redirect, from the props React keeps on its tile (none for a
// product, and Mu Market has none).
function link(d) { return "https://capitaloneshopping.com/api/v3/r?d=" + d + "&t=fx"; }
var PAGE = {
  c1s_AlphaOutfitters__2pctback:   { m: "Alpha Outfitters", v: "2% back", t: "PERCENT", n: 2, badge: "", domain: "alphaoutfitters.example",
                                     title: "Save at Alpha Outfitters", link: link("alphaoutfitters") },
  c1s_EtaEyewear__25pctback:       { m: "Eta Eyewear", v: "25% back", t: "PERCENT", n: 25, badge: "Top Offer", domain: "etaeyewear.example",
                                     title: "Frames for the whole family.", link: link("etaeyewear") },
  c1s_ThetaTea__45pctback:         { m: "Theta Tea", v: "45% back", t: "PERCENT", n: 45, badge: "Top Offer", domain: "",
                                     title: "Take the quiz and save.", link: link("thetatea") },
  c1s_BetaBeauty__11pctback__event: { m: "Beta Beauty", v: "11% back", t: "PERCENT", n: 11, badge: "Limited Time Event", domain: "betabeauty.example",
                                     title: "Preview: Holiday Offers", link: link("betabeauty"), days: "Exclusive rates for next 2 days", end: [2, 0] },
  c1s_GammaGear__12pctback__event: { m: "Gamma Gear", v: "12% back", t: "PERCENT", n: 12, badge: "Limited Time Event", domain: "gammagear.example",
                                     title: "Shop Holiday Gear", link: link("gammagear"), days: "Exclusive rates for next 1 day", end: [1, 0] },
  c1s_IotaInternet__usd150back__event: { m: "Iota Internet", v: "$150 back", t: "DOLLAR", n: 150, badge: "Limited Time Event", domain: "iota-internet.example",
                                     title: "Preview: Holiday Offers", link: link("iotainternet"), days: "Exclusive rates for next 1 day", end: [1, 0] },
  c1s_GammaGear__6pctback:         { m: "Gamma Gear", v: "6% back", t: "PERCENT", n: 6, badge: "Featured Offer", domain: "gammagear.example",
                                     title: "Jackets for every season.", link: link("gammagear") },
  c1s_DeltaDrinks__13pctback:      { m: "Delta Drinks", v: "13% back", t: "PERCENT", n: 13, badge: "Featured Offer", domain: "deltadrinks.example",
                                     title: "Up to 30% off your purchase", link: link("deltadrinks") },
  c1s_ZetaHome__9pctback:          { m: "Zeta Home", v: "9% back", t: "PERCENT", n: 9, badge: "Featured Offer", domain: "zetahome.example",
                                     title: "5% back on your first order. Sale ends tomorrow", link: link("zetahome") },
  c1s_DeltaDrinks__26pctback:      { m: "Delta Drinks", v: "26% back", t: "PERCENT", n: 26, badge: "Exclusive Offer", domain: "deltadrinks.example",
                                     title: "Up to 30% off your purchase", link: link("deltadrinks") },
  c1s_EpsilonShoes__upto1pctback:  { m: "Epsilon Shoes", v: "Up to 1% back", t: "PERCENT", n: 1, badge: "Price Drop", domain: "epsilonshoes.example",
                                     title: "", link: "" },
  c1s_MuMarket__upto7_5pctbackusd500max: { m: "Mu Market", v: "Up to 7.5% back ($500 max)", t: "PERCENT", n: 7.5, badge: "Exclusive Deal", domain: "mumarket.example",
                                     title: "Save at This Site You Recently Visited", link: "" }
};
// The first batch the page adds; every batch ends with ten Rho Rugs offers.
var LATE = Object.assign({}, PAGE, {
  c1s_NuNotes__3pctback:           { m: "Nu Notes", v: "3% back", t: "PERCENT", n: 3, badge: "", domain: "nunotes.example",
                                     title: "Save at Nu Notes", link: link("nunotes") },
  c1s_XiXylophones__8pctback__event: { m: "Xi Xylophones", v: "8% back", t: "PERCENT", n: 8, badge: "Limited Time Event", domain: "xixylophones.example",
                                     title: "Shop Holiday Music", link: link("xixylophones"), days: "Exclusive rates for next 5 hours", end: [0, 5] },
  c1s_RhoRugs__1pctback:           { m: "Rho Rugs", v: "1% back", t: "PERCENT", n: 1, badge: "", domain: "rhorugs.example",
                                     title: "Save at Rho Rugs", link: link("rhorugs") }
});
// Two batches: Alpha Outfitters' Exclusive Offer further down is a second rate, saved beside its 2%.
var LATE2 = Object.assign({}, LATE, {
  c1s_AlphaOutfitters__4pctback:   { m: "Alpha Outfitters", v: "4% back", t: "PERCENT", n: 4, badge: "Exclusive Offer", domain: "alphaoutfitters.example",
                                     title: "Shop Deals and more at Alpha Outfitters", link: link("alphaoutfitters") },
  c1s_OmicronOptics__5pctback:     { m: "Omicron Optics", v: "5% back", t: "PERCENT", n: 5, badge: "", domain: "omicronoptics.example",
                                     title: "Save at Omicron Optics", link: link("omicronoptics") }
});
var LATE3 = Object.assign({}, LATE2, {
  c1s_PiPets__3_5pctback:          { m: "Pi Pets", v: "3.5% back", t: "PERCENT", n: 3.5, badge: "", domain: "pipets.example",
                                     title: "Save at Pi Pets", link: link("pipets") }
});

// Exactly these offers were saved, with no card, and nothing on the page was
// pressed or shown.
function saved(out, expected) {
  assert.deepEqual(out.errors, [], "page errors");
  assert.deepEqual(Object.keys(out.saves).sort(), Object.keys(expected).sort(), "saved keys");
  Object.keys(expected).forEach(function (k) {
    var o = out.saves[k], e = expected[k], mk = k.split("__")[0];
    assert.equal(o.site, SITE, k); assert.equal(o.status, "available", k);
    assert.equal(o.m, e.m, k); assert.equal(o.v, e.v, k); assert.equal(o.t, e.t, k); assert.equal(o.n, e.n, k);
    assert.equal(o.badge, e.badge, k); assert.equal(o.domain, e.domain, k);
    assert.equal(o.title, e.title, k + " title"); assert.equal(o.link, e.link, k + " link");
    // The store's keys from the one-rate-per-store hub, to be removed.
    assert.deepEqual(o.replaces, [mk, mk + "_event"], k + " replaces");
    assert.ok(!("card" in o) && !("cardId" in o), k + " has no card");
    if (e.end) {
      assert.equal(o.days, e.days, k);
      var ok = [out.t0, out.t1].some(function (at) { return o.expiresTs === endOf(at, e.end[0], e.end[1]); });
      assert.ok(ok, k + " ends " + new Date(o.expiresTs).toString());
    } else {
      assert.ok(!("expiresTs" in o) && !("days" in o), k + " has no end date");
    }
  });
  assert.equal(out.clicks, 0, "pressed nothing on the page");
  assert.equal(out.panels, 0, "no panel on the page");
  assert.ok(!out.panelEarly, "nothing of the run's on the page while it read");
  assert.equal(out.y, 0, "back where the page was");
}

function reported(out, done, stats) {
  out.done.forEach(function (d) {
    assert.deepEqual({ site: d.site, note: d.note, added: d.added, saved: d.saved, history: d.history, error: d.error }, done);
  });
  assert.equal(out.status, done.note);
  assert.equal(out.lastRun, done.saved);
  if (stats) assert.deepEqual(out.stats, stats, "side panel: offers read, stores, with an end date, couldn't read");
  // The badge and the popup heard how it went, and that it's done.
  assert.ok(out.progressN >= 2, "progress messages: " + out.progressN);
  assert.deepEqual({ site: out.progress.site, status: out.progress.status, done: out.progress.done }, { site: SITE, status: done.note, done: true });
}

// The run scrolled only down while the page still had batches to add.
function downOnly(out, batches) {
  assert.equal(out.added, batches, "batches the page added");
  assert.equal(out.upsEarly, 0, "scrolls upward before the last batch came: " + JSON.stringify(out.upLog));
}

function done(n, timed, stores, more) {
  return { site: SITE, note: "Done. " + n + " offers saved (" + timed + " with an end date). 1 couldn't be read." + (more || ""), added: 0, saved: n, history: 0,
           error: "Couldn't read the reward on 1 of the " + stores + " stores." };
}
// The site takes its load mark away after its last batch: the run stops there.
var ALL = " The page had no more offers to add.";
var DONE_ALL = done(12, 3, 11);
var CASES = [
  { name: "reads every offer, one entry per store; a better rate with an end date apart", query: "min=0.15", check: function (out) {
      saved(out, PAGE);
      assert.equal(out.done.length, 1);
      reported(out, DONE_ALL, [12, 10, 3, 1]);
    } },
  // The live page asks for its next batch when a mark ten offers before the
  // end comes into view. A run waiting at the bottom of the page, below the
  // store list, never brings the next mark into view, so the page stops
  // adding (68 offers in Jay's first live run).
  { name: "batches the page adds as it is scrolled are all read, the run scrolls only down while they come, and stops when the page has no more",
    query: "late=3&lateMs=1000&min=1", check: function (out) {
      saved(out, LATE3);
      reported(out, done(18, 4, 16, ALL), [18, 15, 4, 1]);
      downOnly(out, 3);
      assert.ok(out.ms < 40000, "stopped after " + out.ms + " ms, not after its minute");
    } },
  { name: "batches that take 1, 3 and 6 s: it waits at the end while the page shows its spinner, and a better rate further down wins",
    query: "late=3&lateMs=1000,3000,6000&min=1", check: function (out) {
      saved(out, LATE3);
      reported(out, done(18, 4, 16, ALL), [18, 15, 4, 1]);
      downOnly(out, 3);
    } },
  { name: "a page that adds offers only once the bottom of the page shows: found when the run looks around",
    query: "late=1&loader=bottom&min=0.5", check: function (out) {
      saved(out, LATE);
      reported(out, done(15, 4, 14), [15, 13, 4, 1]);
    } },
  { name: "batches that come only when the end of the offers shows again (the first time is lost): it looks back up and reads them",
    query: "late=2&lateMs=1000&loader=sentinel&min=0.75", check: function (out) {
      saved(out, LATE2);
      reported(out, done(17, 4, 15), [17, 14, 4, 1]);
    } },
  // Its minutes run out while the page is still adding offers: it saves what
  // it read and says so. Never scrolls up while reading.
  { name: "a page that keeps adding offers: the run ends when its minutes run out, saves what it read and says the page was still adding",
    query: "endless=1&lateMs=800&min=0.35", check: function (out) {
      var more = Object.keys(out.saves).filter(function (k) { return !LATE3[k]; });
      assert.ok(more.length >= 1 && more.every(function (k) { return /^c1s_SigmaShop\d+__2pctback$/.test(k); }), "stores from later batches: " + more);
      var page = Object.assign({}, out, { saves: {} });
      Object.keys(LATE3).forEach(function (k) { page.saves[k] = out.saves[k]; });
      saved(page, LATE3);
      var n = 18 + more.length;
      reported(out, { site: SITE, note: "Done. " + n + " offers saved (4 with an end date). 1 couldn't be read. The page was still adding " +
                      "offers when the 21 seconds ran out. Choose more minutes beside Run to read more.", added: 0, saved: n, history: 0,
                      error: "Couldn't read the reward on 1 of the " + (16 + more.length) + " stores." });
      assert.ok(out.added >= 4, "batches added: " + out.added);
      assert.equal(out.ups, 0, "scrolls upward while reading: " + JSON.stringify(out.upLog));
    } },
  // The popup's Stop reaches the page through the tab's bridge: the run ends
  // there and saves what it has read.
  { name: "the popup's Stop ends the run at once and saves what it read", query: "late=3&lateMs=1000&min=1&stop=5000", check: function (out) {
      var keys = Object.keys(out.saves);
      assert.ok(Object.keys(PAGE).every(function (k) { return keys.indexOf(k) > -1 || k === "c1s_AlphaOutfitters"; }), "the page's own offers: " + keys);
      assert.ok(keys.every(function (k) { return LATE3[k] || k === "c1s_AlphaOutfitters"; }), "nothing made up: " + keys);
      assert.equal(out.done.length, 1);
      var note = out.done[0].note;
      assert.match(note, /^Done\. \d+ offers saved \(\d with an end date\)\. 1 couldn't be read\.$/);
      assert.equal(out.status, note);
      assert.deepEqual({ status: out.progress.status, done: out.progress.done }, { status: note, done: true });
      assert.ok(!out.panelEarly, "nothing of the run's on the page until it was done");
      assert.ok(out.ms < 15000, "stopped after " + out.ms + " ms");
    } },
  { name: "a page without offers saves nothing and says where to go", query: "empty=1&min=1", check: function (out) {
      saved(out, {});
      reported(out, { site: SITE, note: "No offers on this page. Open capitaloneshopping.com (its home page) and press Run again.",
                      added: 0, saved: 0, history: 0, error: "" }, [0, 0, 0, 0]);
      assert.ok(out.ms < 30000, "done after " + out.ms + " ms, not after its minute");
    } },
  { name: "rewards it can't read fail loudly instead of saving nothing quietly", query: "broken=1&min=1", check: function (out) {
      saved(out, {});
      reported(out, { site: SITE, note: "Couldn't read the reward on any of the 10 offers on this page. Capital One Shopping may have changed its page.",
                      added: 0, saved: 0, history: 0, error: "Couldn't read the reward on any of the 10 offers on this page." }, [0, 0, 0, 10]);
      assert.ok(out.ms < 30000, "done after " + out.ms + " ms, not after its minute");
    } },
  { name: "Run pressed again while it reads: one run", query: "twice=1&min=0.15", check: function (out) {
      saved(out, PAGE);
      assert.equal(out.done.length, 1);
      reported(out, DONE_ALL);
    } },
  { name: "Run pressed again after it's done: a fresh run, the same offers", query: "again=1&min=0.15", dones: 2, check: function (out) {
      saved(out, PAGE);
      assert.equal(out.done.length, 2);
      reported(out, DONE_ALL, [12, 10, 3, 1]);
    } }
];

var RESULT = "JSON.stringify({ saves: JSON.parse(sessionStorage.getItem('fx_saves') || '{}'), " +
  "done: JSON.parse(sessionStorage.getItem('fx_done') || '[]'), lastRun: JSON.parse(sessionStorage.getItem('fx_lastRun') || 'null'), " +
  "clicks: JSON.parse(sessionStorage.getItem('fx_clicks') || '0'), panels: document.querySelectorAll('#c1s-autopilot-ui').length, " +
  "status: (JSON.parse(sessionStorage.getItem('fx_progress') || '{}')).status || '', " +
  "stats: (function (p) { return [p.read, p.stores, p.timed, p.bad]; })(JSON.parse(sessionStorage.getItem('fx_progress') || '{}')), " +
  "ups: JSON.parse(sessionStorage.getItem('fx_ups') || '0'), upsEarly: JSON.parse(sessionStorage.getItem('fx_upsEarly') || '0'), " +
  "upLog: JSON.parse(sessionStorage.getItem('fx_upLog') || '[]'), panelEarly: JSON.parse(sessionStorage.getItem('fx_panelEarly') || 'false'), progressN: JSON.parse(sessionStorage.getItem('fx_progressN') || '0'), " +
  "progress: JSON.parse(sessionStorage.getItem('fx_progress') || '{}'), " +
  "added: JSON.parse(sessionStorage.getItem('fx_added') || '0'), y: scrollY })";

H.serve({ "/home": "tests/browser/capitaloneshopping.fixture.html" }).then(function (server) {
  return H.cases(CASES, function (c) {
    var done = "JSON.parse(sessionStorage.getItem('fx_done') || '[]').length >= " + (c.dones || 1) +
               " && Date.now() - JSON.parse(sessionStorage.getItem('fx_doneAt')) > 1000";
    var t0 = Date.now();
    return H.run("http://capitaloneshopping.com.localhost:" + server.port + "/home" + (c.query ? "?" + c.query : ""), done, RESULT, 90000)
      .then(function (out) { out.t0 = t0; out.t1 = Date.now(); return out; });
  });
});
