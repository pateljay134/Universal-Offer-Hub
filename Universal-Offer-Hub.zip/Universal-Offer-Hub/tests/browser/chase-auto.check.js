/*
 * Browser check: Chase auto-add on a made-up Chase page
 * (chase-hub.fixture.html) in headless Chrome. The page scripts
 * (content/chase-auto.js on content/auto-core.js) open each card and run
 * "Run Chase Autopilot" itself (content/scraper.js) on the service worker's
 * clock, as lib/autorun.js does.
 *   node tests/browser/chase-auto.check.js
 * Needs Node 22 or later; set CHROME when Chrome isn't at the macOS default.
 */
"use strict";
var assert = require("node:assert/strict");
var H = require("./harness.js");

// The fixture's offers: "Alpha Store 0..22" on Sapphire Reserve ••1111 (0-2
// not added yet), "Beta Store 0..11" on CHASE COLLEGE ••2222 (0-1).
function keys(prefix, accountId, n) {
  var out = [];
  for (var i = 0; i < n; i++) out.push("chase_" + accountId + "_" + (prefix + " Store " + i).replace(/\W/g, ""));
  return out;
}
var ALPHA = keys("Alpha", "2000000002", 23), BETA = keys("Beta", "1000000001", 12);

function adding(out) {
  assert.deepEqual(out.errors, [], "page errors");
  assert.deepEqual(out.report.fails, [], "failed jobs");
  var r = out.report.results;
  assert.equal(r.length, 3);
  var d = r[0].result;
  assert.deepEqual(d.accounts.map(function (a) { return a.id; }), ["1000000001", "2000000002", "3000000003"]);
  assert.deepEqual(d.options.map(function (o) { return o.label; }), ["CHASE COLLEGE (...2222)", "Sapphire Reserve (...1111)"]);
  var A = r[1].result, B = r[2].result;
  // What the autopilot reported (its own counts and status line).
  assert.equal(r[1].card, "Chase|2000000002");
  assert.equal(A.count, 3); assert.equal(A.harvested, 23);
  assert.equal(A.note, "Done. 3 added, 23 from history.");
  assert.equal(A.check.addedBefore, 20); assert.equal(A.check.urlId, "2000000002");
  assert.equal(B.count, 2); assert.equal(B.harvested, 12);
  assert.equal(B.check.addedBefore, 10); assert.equal(B.check.urlId, "1000000001");
  // Every offer not added yet clicked once, and nothing else.
  var clicks = out.fixture.clicks;
  assert.deepEqual(Object.keys(clicks).sort(), ["TST:Alpha:0", "TST:Alpha:1", "TST:Alpha:2", "TST:Beta:0", "TST:Beta:1"]);
  Object.keys(clicks).forEach(function (k) { assert.equal(clicks[k], 1, k); });
  assert.equal(out.fixture.backs, 5, "Back once from each offer's page");
  assert.equal(out.fixture.overviews, 1, "never sent back to the accounts page");
  // Every offer on both cards saved by the autopilot under its own key (the
  // account id from the address), as added, with the card's name and ending.
  ALPHA.concat(BETA).forEach(function (k) { assert.ok(out.report.saves[k], "saved " + k); assert.equal(out.report.saves[k].status, "added", k); });
  assert.equal(out.report.saves[ALPHA[0]].card, "Sapphire Reserve ••1111");
  assert.equal(out.report.saves[BETA[1]].card, "CHASE COLLEGE ••2222");
  assert.equal(out.report.saves[ALPHA[0]].cardId, "2000000002");
  assert.equal(out.report.saves[ALPHA[0]].last4, "1111");
}

var CASES = [
  { name: "adds every offer through Run Chase Autopilot on both cards", query: "hidden=1", check: adding },
  { name: "Chase slow to go back: one Back per offer page", query: "hidden=1&slowback=2500", check: adding },
  { name: "a loading screen after Back: no offer is skipped", query: "hidden=1&gap=1500", check: adding },
  { name: "Chase ignores the account id in the address: picked in Choose account", query: "hidden=1&ignoreid=1", check: function (out) {
      adding(out);
      assert.equal(out.fixture.switches, 1);
    } },
  { name: "Chase puts the card it has open back into the address: picked in Choose account", query: "hidden=1&rewriteid=1", check: function (out) {
      adding(out);
      assert.equal(out.fixture.switches, 1);
    } },
  { name: "Chase never shows an account id: each card is skipped and nothing is saved under another card", query: "hidden=1&noid=1", check: function (out) {
      assert.deepEqual(out.errors, [], "page errors");
      assert.deepEqual(out.report.fails.map(function (f) { return f.card + " " + f.reason; }),
                       ["Chase|2000000002 card-unverified", "Chase|1000000001 card-unverified"]);
      assert.deepEqual(out.report.saves, {});
      assert.deepEqual(out.fixture.clicks, {});
    } },
  { name: "the error banner before a card's run: Try again, then the run", query: "hidden=1&error=1", check: function (out) {
      adding(out);
      assert.equal(out.fixture.tryAgain, 1);
    } }
];

H.serve().then(function (server) {
  return H.cases(CASES, function (c) {
    return H.run("http://secure.chase.com.localhost:" + server.port + "/tests/browser/chase-hub.fixture.html?" + c.query + "#/dashboard/overview",
                 "window.__finished", "JSON.stringify({ report: window.__report, fixture: window.__fixture })", 180000);
  });
});
