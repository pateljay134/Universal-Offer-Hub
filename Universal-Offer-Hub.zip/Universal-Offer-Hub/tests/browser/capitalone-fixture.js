// Shared by capitalone-feed.fixture.html and capitalone-summary.fixture.html,
// for tests/browser/capitalone-auto.check.js: a made-up Capital One login (two
// cards with offers and a bank account: endings 4417, 7720 and 9001) and the
// service worker's side of the port (lib/autorun.js). Both live in the tab's
// sessionStorage, so they carry across page loads. Query:
//   single=1   one card, no card menu
//   manual=1   no auto-add (role "none"); the page runs the autopilot the
//              way the popup's Run button does
(function () {
  var Q = new URLSearchParams(location.search);
  var FX = window.FX = { Q: Q, SINGLE: Q.get("single") === "1", MANUAL: Q.get("manual") === "1" };
  FX.CARDS = [
    { digits: "4417", name: "Venture X", prefix: "Alpha", n: 12 },
    { digits: "7720", name: "Discover it", prefix: "Beta", n: 9 }
  ];
  if (FX.SINGLE) FX.CARDS = FX.CARDS.slice(0, 1);
  FX.get = function (k, d) { try { var v = sessionStorage.getItem("fx_" + k); return v ? JSON.parse(v) : d; } catch (e) { return d; } };
  FX.set = function (k, v) { sessionStorage.setItem("fx_" + k, JSON.stringify(v)); };
  FX.log = function (e) { var l = FX.get("log", []); l.push(e); FX.set("log", l); };
  FX.count = function (k) { var c = FX.get("count", {}); c[k] = (c[k] || 0) + 1; FX.set("count", c); };
  FX.esc = function (s) { return String(s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/"/g, "&quot;"); };
  FX.card = function () {
    var d = FX.get("card", "4417");
    return FX.CARDS.filter(function (c) { return c.digits === d; })[0] || FX.CARDS[0];
  };
  var ROLE = /accountSummary/.test(location.pathname) ? "watch" : FX.MANUAL ? "none" : "run";

  // The service worker: discover, then one add job per card in rank order
  // (7720 first, though the feed opens on 4417), started the way
  // lib/autorun.js starts it, ticking at the issuer's pace.
  var JOBS = [{ kind: "discover" }].concat((FX.SINGLE ? ["4417"] : ["7720", "4417"]).map(function (d) {
    var c = FX.CARDS.filter(function (x) { return x.digits === d; })[0];
    return { kind: "add", card: { key: "Capital One|" + d, id: d, digits: d, name: c.name } };
  }));
  var LOGIN = ["4417", "7720", "9001"];
  var sw = FX.get("sw", null) || { n: 0, started: false, results: [], fails: [], saves: {}, progress: [], finished: false };
  var port = null, ticker = null;
  function keep() { FX.set("sw", sw); }
  function each(m) { port._l.forEach(function (f) { f(m); }); }
  function sendJob() {
    var j = JOBS[sw.n];
    clearInterval(ticker);
    if (!j) { sw.finished = true; keep(); return; }
    ticker = setInterval(function () { each({ t: "TICK" }); }, 250);
    each({ t: "JOB", job: { id: "j" + sw.n, kind: j.kind, card: j.card || null, started: sw.started, loginDigits: LOGIN } });
  }
  function next(entry, list) {
    entry.job = JOBS[sw.n].kind; entry.card = JOBS[sw.n].card ? JOBS[sw.n].card.key : null;
    list.push(entry); sw.n++; sw.started = false; keep();
    setTimeout(sendJob, 50);
  }
  FX.inject = function () {
    var b = document.createElement("script");
    b.src = "/content/bridge.js";
    b.onload = function () { var s = document.createElement("script"); s.src = "/content/scraper.js"; document.body.appendChild(s); };
    document.body.appendChild(b);
  };
  window.chrome = { runtime: {
    id: "test", lastError: undefined,
    sendMessage: function (m, cb) {
      var r = {};
      if (m.type === "UOH_SAVE") { Object.assign(sw.saves, m.offers || {}); keep(); }
      if (m.type === "UOH_HELLO") r = { role: ROLE, runId: "r1" };
      if (m.type === "UOH_SEEN") { FX.set("seen", m.ids); r = { started: false, reason: "off" }; }
      if (cb) cb(r);
    },
    onMessage: { addListener: function () {} },
    connect: function () {
      port = { _l: [], onMessage: { addListener: function (f) { port._l.push(f); } }, onDisconnect: { addListener: function () {} },
        postMessage: function (m) {
          if (m.t === "AUTOPILOT") { if (!sw.started) { sw.started = true; keep(); FX.inject(); } }
          else if (m.t === "DONE") next({ result: m.result }, sw.results);
          else if (m.t === "FAIL") next({ reason: m.reason }, sw.fails);
          else if (m.t === "PROGRESS" && sw.progress.indexOf(m.text) < 0 && sw.progress.length < 300) { sw.progress.push(m.text); keep(); }
        } };
      setTimeout(sendJob, 50);
      return port;
    }
  } };
})();
