/*
 * Shared by the browser checks: a static file server for the extension
 * folder, and headless Chrome over the DevTools protocol. Needs Node 22 or
 * later (built-in WebSocket and fetch); no packages. Set CHROME to the
 * browser binary when it isn't at the macOS default.
 *
 * The autopilots in content/scraper.js run only on their bank's host, so the
 * made-up pages are opened at <bank host>.localhost, which Chrome sends to
 * this computer.
 */
"use strict";
var fs = require("fs"), os = require("os"), path = require("path"), http = require("http"), net = require("net"), cp = require("child_process");

var CHROME = process.env.CHROME || "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome";
var ROOT = path.join(__dirname, "..", "..");
var TYPES = { ".html": "text/html", ".js": "text/javascript", ".css": "text/css", ".json": "application/json" };

function sleep(ms) { return new Promise(function (r) { setTimeout(r, ms); }); }

// A port nothing on this computer is listening on.
function freePort() {
  return new Promise(function (resolve, reject) {
    var s = net.createServer();
    s.on("error", reject);
    s.listen(0, "127.0.0.1", function () { var p = s.address().port; s.close(function () { resolve(p); }); });
  });
}

// Serves the extension folder. routes maps a path ("/offers") to a file in it.
function serve(routes) {
  return freePort().then(function (port) {
    var server = http.createServer(function (req, res) {
      var url = decodeURIComponent(req.url.split("?")[0]);
      var file = path.join(ROOT, routes && routes[url] ? routes[url] : url);
      if (file.indexOf(ROOT) !== 0) { res.writeHead(403); res.end(); return; }
      fs.readFile(file, function (err, data) {
        if (err) { res.writeHead(404); res.end(); return; }
        res.writeHead(200, { "content-type": TYPES[path.extname(file)] || "application/octet-stream" });
        res.end(data);
      });
    });
    return new Promise(function (resolve) {
      server.listen(port, "127.0.0.1", function () { resolve({ port: port, close: function () { server.close(); } }); });
    });
  });
}

// Opens url in headless Chrome and waits until doneExpr is true in whatever
// page the tab is on (a run may load several); returns JSON.parse of
// resultExpr, plus the page errors seen and the time taken.
function run(url, doneExpr, resultExpr, limitMs) {
  return freePort().then(async function (dport) {
    var profile = fs.mkdtempSync(path.join(os.tmpdir(), "uoh-check-"));
    var chrome = cp.spawn(CHROME, ["--headless=new", "--disable-gpu", "--no-first-run", "--user-data-dir=" + profile,
      "--window-size=1200,900", "--remote-debugging-port=" + dport, url], { stdio: "ignore" });
    var ws = null;
    try {
      var list = [];
      for (var i = 0; i < 100 && !list.some(function (t) { return t.type === "page"; }); i++) {
        try { list = await (await fetch("http://127.0.0.1:" + dport + "/json/list")).json(); } catch (e) { await sleep(100); }
      }
      var target = list.filter(function (t) { return t.type === "page"; })[0];
      ws = new WebSocket(target.webSocketDebuggerUrl);
      var id = 0, pending = {}, errors = [];
      ws.onmessage = function (m) {
        var d = JSON.parse(m.data);
        if (d.id && pending[d.id]) { pending[d.id](d.result); delete pending[d.id]; return; }
        if (d.method === "Runtime.exceptionThrown") {
          var x = d.params.exceptionDetails;
          errors.push(x.exception ? x.exception.description : x.text);
        }
      };
      await new Promise(function (r) { ws.onopen = r; });
      var send = function (method, params) {
        return new Promise(function (r) { var n = ++id; pending[n] = r; ws.send(JSON.stringify({ id: n, method: method, params: params })); });
      };
      var evaluate = function (expr) {
        return send("Runtime.evaluate", { expression: expr, returnByValue: true })
          .then(function (r) { return r && r.result ? r.result.value : undefined; });
      };
      await send("Runtime.enable");
      var t0 = Date.now();
      while (!(await evaluate("(function () { try { return !!(" + doneExpr + "); } catch (e) { return false; } })()"))) {
        if (Date.now() - t0 > limitMs) {
          throw new Error("timed out at " + (await evaluate("location.href")) + "; so far: " +
                          String(await evaluate(resultExpr)).slice(0, 900));
        }
        await sleep(500);
      }
      var out = JSON.parse(await evaluate(resultExpr));
      out.errors = errors;
      out.ms = Date.now() - t0;
      return out;
    } finally {
      if (ws) try { ws.close(); } catch (e) {}
      chrome.kill();
      await sleep(500);
      try { fs.rmSync(profile, { recursive: true, force: true }); } catch (e) {}
    }
  });
}

// Runs each case in turn; prints one line each; exits 1 if any failed.
async function cases(list, start) {
  var failed = 0;
  for (var i = 0; i < list.length; i++) {
    var c = list[i];
    try {
      var out = await start(c);
      c.check(out);
      console.log("ok   " + c.name + " (" + Math.round(out.ms / 1000) + " s)");
    } catch (e) {
      failed++;
      console.log("FAIL " + c.name + ": " + (e && e.message || e));
    }
  }
  process.exit(failed ? 1 : 0);
}

module.exports = { serve: serve, run: run, cases: cases };
