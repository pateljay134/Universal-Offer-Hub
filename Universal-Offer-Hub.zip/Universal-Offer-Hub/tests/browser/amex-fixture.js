// Shared by amex-offers.fixture.html and amex-enrolled.fixture.html, for
// tests/browser/amex-auto.check.js: a made-up Amex login (two cards, a
// checking account, six offers; an offer stays on one card per login), and
// the service worker's side of the port (lib/autorun.js). Both live in the
// tab's sessionStorage, so they carry across Amex's page loads.
(function () {
  var FX = window.FX = {};
  FX.CARDS = [
    { digits: "11111", name: "Platinum Card®", optId: "AAAA" },
    { digits: "22222", name: "Blue Cash Everyday®", optId: "BBBB" }
  ];
  // Offers 4 and 5 are on the Platinum card only.
  FX.OFFERS = [0, 1, 2, 3, 4, 5].map(function (i) {
    return { m: "Shop " + i, v: "Spend $" + (50 + i) + " or more, earn $10 back", only: i >= 4 ? "11111" : "" };
  });
  FX.get = function (k, d) { try { var v = sessionStorage.getItem("fx_" + k); return v ? JSON.parse(v) : d; } catch (e) { return d; } };
  FX.set = function (k, v) { sessionStorage.setItem("fx_" + k, JSON.stringify(v)); };
  FX.card = function () { var d = FX.get("card", "11111"); return FX.CARDS.filter(function (c) { return c.digits === d; })[0]; };
  FX.log = function (e) { var l = FX.get("log", []); l.push(e); FX.set("log", l); };
  FX.esc = function (s) { return String(s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/"/g, "&quot;"); };
  // The account switcher's closed combobox, showing card c.
  FX.switcher = function (c) {
    return '<div data-testid="simple_switcher_combobox" role="combobox" aria-expanded="false">' +
      '<span data-testid="simple_switcher_display_name">' + FX.esc(c.name) + "</span>" +
      '<span data-testid="simple_switcher_display_number_val">-' + c.digits + "</span></div>";
  };

  // The service worker: discover, then one add job per card in rank order
  // (22222 first), started the way lib/autorun.js starts it.
  var JOBS = [{ kind: "discover" },
    { kind: "add", card: { key: "Amex|22222", id: "22222", digits: "22222", name: "Blue Cash Everyday®", optId: "BBBB" } },
    { kind: "add", card: { key: "Amex|11111", id: "11111", digits: "11111", name: "Platinum Card®", optId: "AAAA" } }];
  var LOGIN = ["11111", "22222", "3333"];
  var sw = FX.get("sw", null) || { n: 0, started: false, results: [], fails: [], saves: {}, finished: false };
  var port = null, ticker = null;
  function keep() { FX.set("sw", sw); }
  function each(m) { port._l.forEach(function (f) { f(m); }); }
  function sendJob() {
    var j = JOBS[sw.n];
    clearInterval(ticker);
    if (!j) { sw.finished = true; keep(); return; }
    // A card's run starts on /offers (lib/issuers/amex.js route()); while it
    // runs, the tab stays where the autopilot takes it.
    if (j.kind === "add" && !sw.started && /\/offers\/enrolled/.test(location.pathname)) {
      FX.log("to /offers");
      location.href = "/offers";
      return;
    }
    ticker = setInterval(function () { each({ t: "TICK" }); }, j.kind === "add" ? 250 : 100);
    each({ t: "JOB", job: { id: "j" + sw.n, kind: j.kind, card: j.card || null, started: sw.started, loginDigits: LOGIN } });
  }
  function next(entry, list) {
    entry.job = JOBS[sw.n].kind; entry.card = JOBS[sw.n].card ? JOBS[sw.n].card.key : null;
    list.push(entry); sw.n++; sw.started = false; keep();
    setTimeout(sendJob, 50);
  }
  function inject() {
    var b = document.createElement("script");
    b.src = "/content/bridge.js";
    b.onload = function () { var s = document.createElement("script"); s.src = "/content/scraper.js"; document.body.appendChild(s); };
    document.body.appendChild(b);
  }
  window.chrome = { runtime: {
    id: "test", lastError: undefined,
    sendMessage: function (m, cb) {
      if (m.type === "UOH_SAVE") { Object.assign(sw.saves, m.offers || {}); keep(); }
      if (cb) cb(m.type === "UOH_HELLO" ? { role: "run", runId: "r1" } : {});
    },
    onMessage: { addListener: function () {} },
    connect: function () {
      port = { _l: [], onMessage: { addListener: function (f) { port._l.push(f); } }, onDisconnect: { addListener: function () {} },
        postMessage: function (m) {
          if (m.t === "AUTOPILOT") { if (!sw.started) { sw.started = true; keep(); inject(); } }
          else if (m.t === "DONE") next({ result: m.result }, sw.results);
          else if (m.t === "FAIL") next({ reason: m.reason }, sw.fails);
        } };
      setTimeout(sendJob, 50);
      return port;
    }
  } };
})();
