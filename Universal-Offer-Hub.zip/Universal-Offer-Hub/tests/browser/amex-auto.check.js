/*
 * Browser check: Amex auto-add on made-up Amex pages (amex-offers.fixture.html
 * as /offers, amex-enrolled.fixture.html as /offers/enrolled) in headless
 * Chrome. The page scripts (content/amex-auto.js on content/auto-core.js)
 * switch to each card and run "Run Amex Autopilot" itself
 * (content/scraper.js) on the service worker's clock, as lib/autorun.js does;
 * the autopilot's own page load to the card's Added page and its harvest
 * there are part of the run.
 *   node tests/browser/amex-auto.check.js
 * Needs Node 22 or later; set CHROME when Chrome isn't at the macOS default.
 */
"use strict";
var assert = require("node:assert/strict");
var H = require("./harness.js");

var CASES = [
  { name: "adds every offer through Run Amex Autopilot, top card first, and reads each card's Added page", check: function (out) {
      assert.deepEqual(out.errors, [], "page errors");
      var sw = out.sw;
      assert.deepEqual(sw.fails, [], "failed jobs");
      assert.deepEqual(sw.results.map(function (r) { return r.job + " " + (r.card || ""); }),
                       ["discover ", "add Amex|22222", "add Amex|11111"]);
      var d = sw.results[0].result;
      assert.equal(d.displayed.digits, "11111");
      assert.equal(d.options.length, 3);
      // Offers 0-3 go to the top card; Amex keeps an offer on one card, so the
      // next card gets only what's left (its own 4 and 5).
      var A = sw.results[1].result, B = sw.results[2].result;
      assert.equal(A.count, 4); assert.equal(A.harvested, 4); assert.equal(A.note, "Done. 4 added, 4 from history.");
      assert.equal(B.count, 2); assert.equal(B.harvested, 2); assert.equal(B.note, "Done. 2 added, 2 from history.");
      assert.deepEqual(out.clicks, { "22222:0": 1, "22222:1": 1, "22222:2": 1, "22222:3": 1, "11111:4": 1, "11111:5": 1 });
      assert.deepEqual(out.added, { 0: "22222", 1: "22222", 2: "22222", 3: "22222", 4: "11111", 5: "11111" });
      // Each card's Added page was read by the autopilot itself; each card's
      // run started with a switch on /offers (Amex opened on 11111).
      assert.deepEqual(out.log, ["switch 22222", "enrolled 22222", "to /offers", "switch 11111", "enrolled 11111"]);
      // The autopilot's own rows: the manual key, added, with the card's name.
      ["amex_22222_Shop0", "amex_22222_Shop3", "amex_11111_Shop4", "amex_11111_Shop5"].forEach(function (k) {
        assert.ok(sw.saves[k], "saved " + k);
        assert.equal(sw.saves[k].status, "added", k);
      });
      assert.equal(sw.saves.amex_22222_Shop0.card, "Blue Cash Everyday® ••22222");
      assert.equal(sw.saves.amex_11111_Shop4.cardId, "11111");
      assert.equal(sw.saves.amex_11111_Shop4.days, "Expires 12/31/26");
    } }
];

H.serve({ "/offers": "tests/browser/amex-offers.fixture.html", "/offers/enrolled": "tests/browser/amex-enrolled.fixture.html" })
  .then(function (server) {
    return H.cases(CASES, function () {
      return H.run("http://global.americanexpress.com.localhost:" + server.port + "/offers",
                   "JSON.parse(sessionStorage.getItem('fx_sw') || '{}').finished",
                   "JSON.stringify({ sw: JSON.parse(sessionStorage.getItem('fx_sw') || '{}'), " +
                   "clicks: JSON.parse(sessionStorage.getItem('fx_clicks') || '{}'), added: JSON.parse(sessionStorage.getItem('fx_added') || '{}'), " +
                   "log: JSON.parse(sessionStorage.getItem('fx_log') || '[]') })", 180000);
    });
  });
