/*
 * Browser check: Amex auto-add on made-up Amex pages (amex-offers.fixture.html
 * as /offers, amex-enrolled.fixture.html as /offers/enrolled) in headless
 * Chrome. The page scripts (content/amex-auto.js on content/auto-core.js)
 * switch to each card and run "Run Amex Autopilot" itself
 * (content/scraper.js) on the service worker's clock, as lib/autorun.js does;
 * the autopilot's own page load to the card's Added page and its harvest
 * there are part of the run, in each markup of Amex's offer rows the made-up
 * pages draw (hashed, old, future, broken: amex-fixture.js). On the pages a
 * sign-in lands on (amex-overview.fixture.html as /overview and /dashboard)
 * the user's tab reports the login's account endings, which starts a run.
 *   node tests/browser/amex-auto.check.js
 * Needs Node 22 or later; set CHROME when Chrome isn't at the macOS default.
 */
"use strict";
var assert = require("node:assert/strict");
var H = require("./harness.js");

// The whole run, in one markup of Amex's offer rows (amex-fixture.js): every
// offer added, top card first, and each card's Added page read back in full.
function fullRun(out) {
  assert.deepEqual(out.errors, [], "page errors");
  var sw = out.sw;
  assert.deepEqual(sw.fails, [], "failed jobs");
  assert.deepEqual(sw.results.map(function (r) { return r.job + " " + (r.card || ""); }),
                   ["discover ", "add Amex|22222", "add Amex|11111"]);
  var d = sw.results[0].result;
  assert.equal(d.displayed.digits, "11111");
  assert.equal(d.options.length, 3);
  // Offers 0-3 go to the top card; Amex keeps an offer on one card, so the
  // next card gets only what's left (its own 4 and 5).
  var A = sw.results[1].result, B = sw.results[2].result;
  assert.equal(A.count, 4); assert.equal(A.harvested, 4); assert.equal(A.note, "Done. 4 added, 4 from history.");
  assert.equal(B.count, 2); assert.equal(B.harvested, 2); assert.equal(B.note, "Done. 2 added, 2 from history.");
  assert.equal(A.error, undefined); assert.equal(B.error, undefined);
  assert.deepEqual(out.clicks, { "22222:0": 1, "22222:1": 1, "22222:2": 1, "22222:3": 1, "11111:4": 1, "11111:5": 1 });
  assert.deepEqual(out.added, { 0: "22222", 1: "22222", 2: "22222", 3: "22222", 4: "11111", 5: "11111" });
  // Each card's Added page was read by the autopilot itself; each card's
  // run started with a switch on /offers (Amex opened on 11111).
  assert.deepEqual(out.log, ["switch 22222", "enrolled 22222", "to /offers", "switch 11111", "enrolled 11111"]);
  // The autopilot's own rows: the manual key, added, with every detail.
  ["amex_22222_Shop0", "amex_22222_Shop3", "amex_11111_Shop4", "amex_11111_Shop5"].forEach(function (k) {
    assert.ok(sw.saves[k], "saved " + k);
    assert.equal(sw.saves[k].status, "added", k);
  });
  assert.equal(sw.saves.amex_22222_Shop0.m, "Shop 0");
  assert.equal(sw.saves.amex_22222_Shop0.v, "Spend $50 or more, earn $10 back");
  assert.equal(sw.saves.amex_22222_Shop0.card, "Blue Cash Everyday® ••22222");
  assert.equal(sw.saves.amex_11111_Shop4.cardId, "11111");
  assert.equal(sw.saves.amex_11111_Shop4.days, "Expires 12/31/26");
  assert.ok(sw.saves.amex_11111_Shop4.expiresTs > 0);
}

var CASES = [
  { name: "adds every offer through Run Amex Autopilot, top card first, and reads each card's Added page " +
          "(Amex's markup since Nov 2026; the Added page's rows arrive in two parts)", markup: "hashed", check: fullRun },
  { name: "the same with Amex's markup before Nov 2026", markup: "old", check: fullRun },
  { name: "the same with no classes, no title heading and no test ids on the Added page's rows", markup: "future", check: fullRun },
  { name: "an Added page whose offers can't be read: each card's run fails, saying how many it read", markup: "broken",
    check: function (out) {
      assert.deepEqual(out.errors, [], "page errors");
      var sw = out.sw;
      assert.deepEqual(sw.fails, [], "failed jobs");
      var A = sw.results[1].result, B = sw.results[2].result;
      assert.equal(A.count, 4); assert.equal(A.harvested, 0);
      assert.equal(A.error, "Read 0 of the 4 offers on this card's Added page. Amex may have changed that page.");
      assert.equal(A.note, A.error);
      assert.equal(B.error, "Read 0 of the 2 offers on this card's Added page. Amex may have changed that page.");
      // What it pressed + on is still saved, as available.
      assert.equal(sw.saves.amex_22222_Shop0.status, "available");
      assert.equal(sw.saves.amex_22222_Shop0.v, "Spend $50 or more, earn $10 back");
      assert.ok(!Object.keys(sw.saves).some(function (k) { return sw.saves[k].status === "added"; }));
    } },
  { name: "the sign-in landing page (Overview in the switcher) reports its account tiles' endings, cards first", at: "/overview",
    check: function (out) { overview(out, ["11111", "22222", "3333", "4444", "55555"]); } },
  { name: "Overview's tiles show up after 10 s: the page keeps looking for 20 s", at: "/overview?late=14000",
    check: function (out) { overview(out, ["11111", "22222", "3333", "4444", "55555"]); } },
  { name: "Overview, then a card's page by an in-app move past 20 s: the page looks again and reads the switcher", at: "/overview?route=22000&to=dashboard",
    check: function (out) {
      overview(out, ["11111"]);
      assert.match(out.href, /\/dashboard\?account_key=TESTKEY0001$/);
    } },
  { name: "a card's page loaded directly reports the card in the switcher", at: "/dashboard?account_key=TESTKEY0001",
    check: function (out) { overview(out, ["11111"]); } },
  { name: "Overview's tiles without their locators: the first card ending in the page's text", at: "/overview?locators=0",
    check: function (out) { overview(out, ["11111"]); } }
];

var SEEN = { done: "sessionStorage.getItem('fx_seen')",
             result: "JSON.stringify({ seen: JSON.parse(sessionStorage.getItem('fx_seen') || 'null'), href: location.href })" };
function overview(out, ids) {
  assert.deepEqual(out.errors, [], "page errors");
  assert.deepEqual(out.seen, ids);
}

H.serve({ "/offers": "tests/browser/amex-offers.fixture.html", "/offers/enrolled": "tests/browser/amex-enrolled.fixture.html",
          "/overview": "tests/browser/amex-overview.fixture.html", "/dashboard": "tests/browser/amex-overview.fixture.html" })
  .then(function (server) {
    return H.cases(CASES, function (c) {
      var base = "http://global.americanexpress.com.localhost:" + server.port;
      if (c.at) return H.run(base + c.at, SEEN.done, SEEN.result, 40000);
      return H.run(base + "/offers" + (c.markup ? "?markup=" + c.markup : ""),
                   "JSON.parse(sessionStorage.getItem('fx_sw') || '{}').finished",
                   "JSON.stringify({ sw: JSON.parse(sessionStorage.getItem('fx_sw') || '{}'), " +
                   "clicks: JSON.parse(sessionStorage.getItem('fx_clicks') || '{}'), added: JSON.parse(sessionStorage.getItem('fx_added') || '{}'), " +
                   "log: JSON.parse(sessionStorage.getItem('fx_log') || '[]') })", 180000);
    });
  });
