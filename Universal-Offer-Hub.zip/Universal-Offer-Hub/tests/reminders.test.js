/*
 * Unit tests for the offer reminder in background.js: the service worker is
 * loaded in a sandbox with a stub chrome (lib/sources.js, lib/offers.js and
 * lib/categories.js load as importScripts would load them; auto-add and the
 * live copy are left out), a tab finishes loading, and the test reads which
 * saved offers the reminder would show. Made-up stores and sites.
 *   node --test --test-timeout=30000 tests/*.test.js
 */
"use strict";
var test = require("node:test");
var assert = require("node:assert/strict");
var fs = require("fs"), path = require("path"), vm = require("vm");

var ROOT = path.join(__dirname, "..");
var DAY = 86400000;

function load(db) {
  var listeners = {}, shown = [];
  var on = function (name) { return { addListener: function (f) { listeners[name] = f; } }; };
  var ctx = {
    console: console, URL: URL, Date: Date, Promise: Promise, setTimeout: setTimeout, clearTimeout: clearTimeout,
    chrome: {
      tabs: { onUpdated: on("updated"), onRemoved: on("removed") },
      runtime: { onMessage: on("message"), onInstalled: on("installed"), lastError: undefined },
      storage: { local: { get: function (keys, cb) { cb({ UOH_Database: db, UOH_Settings: {} }); } } },
      scripting: { executeScript: function (o) { shown.push(o.args[0].matches); return Promise.resolve(); } }
    }
  };
  ctx.self = ctx;
  ctx.importScripts = function () {
    Array.prototype.forEach.call(arguments, function (f) {
      if (/^lib\/(sources|offers|categories)\.js$/.test(f)) vm.runInContext(fs.readFileSync(path.join(ROOT, f), "utf8"), ctx, { filename: f });
    });
  };
  vm.createContext(ctx);
  vm.runInContext(fs.readFileSync(path.join(ROOT, "background.js"), "utf8"), ctx, { filename: "background.js" });
  var tab = 0;
  return {
    ctx: ctx,
    // The stores the reminder lists when a tab finishes loading url (copied
    // out of the sandbox, whose arrays have their own prototype).
    visit: function (url) {
      shown.length = 0;
      listeners.updated(++tab, { status: "complete" }, { url: url });
      return shown.length ? Array.from(shown[0], function (o) { return o.m; }).sort() : [];
    }
  };
}

var LATER = Date.now() + 5 * DAY;
var DB = {
  // Capital One Shopping saves the store's site from its logo; the name alone
  // doesn't match it.
  "c1s_TauMobileHomeInternet_event": { m: "Tau Mobile Home Internet", v: "$150 back", site: "Capital One Shopping",
                                       domain: "tau-mobile.example", expiresTs: LATER },
  "c1s_SigmaMail": { m: "Sigma Mail", v: "$23.50 back", site: "Capital One Shopping", domain: "products-mail.sigmahq.example" },
  "c1s_AlphaOutfitters": { m: "Alpha Outfitters", v: "2% back", site: "Capital One Shopping", domain: "alphaoutfitters.example" },
  // Other sources save no site; their names match as before.
  "chase_7319_AlphaOutfitters": { m: "Alpha Outfitters", v: "10% cash back", site: "Chase", cardId: "7319", card: "Sapphire ••7319" },
  "cap1_4417_OmegaOnline": { m: "Omega Online", v: "5% back", site: "Capital One", cardId: "4417", card: "Venture X ••4417" }
};

test("a Capital One Shopping offer shows on its store's site, found by the site it saved", function () {
  var bg = load(DB);
  assert.deepEqual(bg.visit("https://www.tau-mobile.example/plans"), ["Tau Mobile Home Internet"]);
  // A subdomain on either side: the brand is what's compared.
  assert.deepEqual(bg.visit("https://sigmahq.example/"), ["Sigma Mail"]);
  assert.deepEqual(bg.visit("https://shop.sigmahq.example/pricing"), ["Sigma Mail"]);
});

test("a saved site matches only its own store's site, and names match as before", function () {
  var bg = load(DB);
  assert.deepEqual(bg.visit("https://www.tau-mobile-deals.example/"), []);
  // The saved site's subdomain isn't the store.
  assert.deepEqual(bg.visit("https://products-mail.example/"), []);
  assert.deepEqual(bg.visit("https://www.omegaonline.example/"), ["Omega Online"]);
  // The same store from two sources: both show.
  assert.deepEqual(bg.visit("https://shop.alphaoutfitters.example/jackets"), ["Alpha Outfitters", "Alpha Outfitters"]);
});

test("the reminder colors every source's tag as the popup does", function () {
  var bg = load({});
  var toast = bg.ctx.uohRenderToast.toString();
  bg.ctx.UOH_SOURCES.forEach(function (s) {
    var key = /^\w+$/.test(s.id) ? "(?:" + s.id + "|\"" + s.id + "\")" : "\"" + s.id + "\"";
    assert.match(toast, new RegExp(key + "\\s*:\\s*\"" + s.color + "\""), s.id);
  });
});
