/*
 * The MCP plugin (mcp/offer-hub-mcp.js) started as its own process, the way
 * an AI app runs it, talking JSON-RPC over stdio to a sample offers.json.
 *   node --test tests/*.test.js
 */
"use strict";
var test = require("node:test");
var assert = require("node:assert/strict");
var fs = require("fs"), os = require("os"), path = require("path");
var H = require("./mcp-helpers.js");
var UOH = require("../lib/offers.js");
var fixture = H.fixture, start = H.start, text = H.text;

test("MCP plugin: handshake, tool list, and searches over offers.json", async function () {
  var s = start(fixture());
  try {
    var init = await s.call("initialize", { protocolVersion: "2025-06-18", capabilities: {}, clientInfo: { name: "test", version: "1" } });
    assert.equal(init.result.protocolVersion, "2025-06-18");
    assert.ok(init.result.capabilities.tools);
    assert.equal(init.result.serverInfo.name, "offer-hub");
    s.notify("notifications/initialized");
    var tools = await s.call("tools/list");
    assert.deepEqual(tools.result.tools.map(function (t) { return t.name; }), ["search_offers", "list_cards", "offers_overview"]);
    assert.equal(tools.result.tools[0].annotations.readOnlyHint, true);

    var r = await s.call("tools/call", { name: "search_offers", arguments: { query: "hotel", sort: "value" } });
    assert.equal(r.result.isError, false);
    assert.match(text(r), /^2 offers match\./);
    var rows = text(r).split("\n").slice(2);
    assert.match(rows[0], /^Orient Express .*\| Jay Plat ••22001, Blue Cash Everyday® ••91009 \|/);   // one row, both cards
    assert.match(rows[1], /^Hyatt/);
    assert.equal(text(r).indexOf("Old Hotel"), -1);                                                    // expired left out

    r = await s.call("tools/call", { name: "search_offers", arguments: { expiring_within_days: 3 } });
    assert.match(text(r), /^1 offer matches[\s\S]*Pizza Hut/);
    r = await s.call("tools/call", { name: "search_offers", arguments: { card: "3058" } });
    assert.match(text(r), /^1 offer matches[\s\S]*Hyatt/);
    r = await s.call("tools/call", { name: "search_offers", arguments: { new_only: true } });
    assert.match(text(r), /^1 offer matches[\s\S]*Hyatt/);
    r = await s.call("tools/call", { name: "search_offers", arguments: { query: "away samsonite" } });
    assert.match(text(r), /^No saved offers match/);

    r = await s.call("tools/call", { name: "list_cards", arguments: {} });
    assert.match(text(r), /Amex \| Platinum Card® ••22001 \| Jay Plat \| 22001 \| 3/);
    r = await s.call("tools/call", { name: "offers_overview", arguments: {} });
    assert.match(text(r), /^3 active offers/);
    assert.match(text(r), /Expiring within 7 days: 1/);

    assert.equal((await s.call("tools/call", { name: "nope", arguments: {} })).error.code, -32602);
    assert.equal((await s.call("resources/list")).error.code, -32601);
  } finally { s.close(); }
});

test("MCP plugin: a missing offers.json says where to choose the folder", async function () {
  var s = start(fs.mkdtempSync(path.join(os.tmpdir(), "uoh-mcp-empty-")));
  try {
    var init = await s.call("initialize", { protocolVersion: "1999-01-01" });
    assert.equal(init.result.protocolVersion, "2025-06-18");              // an unknown version gets one we speak
    var r = await s.call("tools/call", { name: "search_offers", arguments: {} });
    assert.equal(r.result.isError, true);
    assert.match(text(r), /choose a folder in step 1/);
    assert.equal(/--dir|offers\.json/.test(text(r)), false);               // no command-line advice
  } finally { s.close(); }
});

test("toChatCsv: the compact CSV the Open AI chat button downloads", function () {
  var now = Date.now();
  var csv = UOH.toChatCsv([{ m: "Hyatt, Inc", v: "$250 back", site: "Chase", card: "Chase ••3058", cardId: "a", last4: "3058",
                              expiresTs: now + 3 * 86400000, firstSeen: now }], { now: now, categoryOf: function () { return "Hotels"; } });
  var lines = csv.replace(/^﻿/, "").split("\n");
  assert.equal(lines[0], "Store,Offer,Card,Expires,Days Left,Category,Source,New");
  assert.match(lines[1], /^"Hyatt, Inc","\$250 back","Chase ••3058","\d{4}-\d{2}-\d{2}","3","Hotels","Chase","yes"$/);
});
