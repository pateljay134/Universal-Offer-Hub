/*
 * Universal Offer Hub — Ask AI characters
 * ---------------------------------------
 * The little character on the Ask AI button. The chat's character menu offers
 * twelve; the choice is saved in UOH_Settings.aiCharacter (Clear all keeps it)
 * and mirrored in localStorage so the page paints the right one before storage
 * answers. Drawings are inline SVG sharing the gradients in DEFS; the motion is
 * in characters.css.
 */
(function () {
  "use strict";

  var DEFS = '<svg class="uohc-defs" width="0" height="0" aria-hidden="true" focusable="false"><defs>' +
    '<radialGradient id="uohc-coin" cx="0.36" cy="0.3" r="0.85"><stop offset="0" stop-color="#fff4b8"/><stop offset="0.5" stop-color="#fcd34d"/><stop offset="1" stop-color="#f59e0b"/></radialGradient>' +
    '<linearGradient id="uohc-bot" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#b4bfff"/><stop offset="1" stop-color="#7f8cf7"/></linearGradient>' +
    '<linearGradient id="uohc-chat" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#6ee7d8"/><stop offset="1" stop-color="#7cc4fb"/></linearGradient>' +
    '<linearGradient id="uohc-pig" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#fcd6ea"/><stop offset="1" stop-color="#f7a6cf"/></linearGradient>' +
    '<linearGradient id="uohc-owl" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#b2a1fb"/><stop offset="1" stop-color="#7c6cf6"/></linearGradient>' +
    '<linearGradient id="uohc-bee" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#fef08a"/><stop offset="1" stop-color="#facc15"/></linearGradient>' +
    '<clipPath id="uohc-beeclip"><ellipse cx="16" cy="18" rx="9.4" ry="8.8"/></clipPath>' +
    '<linearGradient id="uohc-gift" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#f9a8d4"/><stop offset="1" stop-color="#c084fc"/></linearGradient>' +
    '<radialGradient id="uohc-halo"><stop offset="0" stop-color="#fde68a" stop-opacity="0.85"/><stop offset="0.5" stop-color="#fde68a" stop-opacity="0.3"/><stop offset="1" stop-color="#fde68a" stop-opacity="0"/></radialGradient>' +
    '<linearGradient id="uohc-bulb" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#fffbe0"/><stop offset="1" stop-color="#fde047"/></linearGradient>' +
    '<linearGradient id="uohc-wal" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#5eead4"/><stop offset="1" stop-color="#10b981"/></linearGradient>' +
    '</defs></svg>';

  // Shared pieces: round eyes with a glint, a smile, and the robots' screen eyes.
  function r2(n) { return Math.round(n * 100) / 100; }
  function eyes(lx, rx, y, ex, ey, color) {
    return '<g class="c-eyes"><ellipse cx="' + lx + '" cy="' + y + '" rx="' + ex + '" ry="' + ey + '" fill="' + color + '"/>' +
      '<ellipse cx="' + rx + '" cy="' + y + '" rx="' + ex + '" ry="' + ey + '" fill="' + color + '"/>' +
      '<circle cx="' + r2(lx + 0.5) + '" cy="' + r2(y - 0.7) + '" r="0.5" fill="#fff"/><circle cx="' + r2(rx + 0.5) + '" cy="' + r2(y - 0.7) + '" r="0.5" fill="#fff"/></g>';
  }
  function smile(d, color) { return '<path d="' + d + '" fill="none" stroke="' + color + '" stroke-width="1.2" stroke-linecap="round"/>'; }
  function visorEyes(x1, x2, y, w, h) {
    return '<g class="c-look"><g class="c-eyes"><rect x="' + x1 + '" y="' + y + '" width="' + w + '" height="' + h + '" rx="' + r2(w / 2) + '" fill="#67e8f9"/>' +
      '<rect x="' + x2 + '" y="' + y + '" width="' + w + '" height="' + h + '" rx="' + r2(w / 2) + '" fill="#67e8f9"/></g></g>';
  }

  // In the menu's order. Each moves a little when idle and more while an answer is on its way.
  var LIST = [
    { id: "pennybot", name: "Pennybot", art:
      '<g class="c-spin"><line x1="16" y1="7.4" x2="16" y2="4.4" stroke="#d97706" stroke-width="1.4" stroke-linecap="round"/>' +
      '<circle class="c-ant" cx="16" cy="3.4" r="1.9" fill="#f472b6"/>' +
      '<circle cx="16" cy="18" r="11" fill="url(#uohc-coin)"/><circle cx="16" cy="18" r="8.9" fill="none" stroke="#d97706" stroke-width="0.9" opacity="0.5"/>' +
      '<rect x="9.4" y="12.6" width="13.2" height="8.2" rx="4.1" fill="#1b1946"/>' + visorEyes(12.1, 17.5, 14.7, 2.4, 4) +
      smile("M14.3 23.6Q16 25 17.7 23.6", "#7c4a03") + '</g>' },
    { id: "penny", name: "Penny", art:
      '<g class="c-hop"><g class="c-spin"><circle cx="16" cy="16" r="12" fill="url(#uohc-coin)"/>' +
      '<circle cx="16" cy="16" r="9.7" fill="none" stroke="#d97706" stroke-width="0.9" opacity="0.5"/>' +
      eyes(12.7, 19.3, 14.7, 1.55, 2.1, "#3a2410") + smile("M13.9 18.7Q16 20.8 18.1 18.7", "#3a2410") +
      '<ellipse cx="10.5" cy="18.1" rx="1.4" ry="0.8" fill="#fb7185" opacity="0.5"/><ellipse cx="21.5" cy="18.1" rx="1.4" ry="0.8" fill="#fb7185" opacity="0.5"/></g></g>' },
    { id: "bolt", name: "Bolt", art:
      '<g class="c-bob"><line x1="16" y1="8.4" x2="16" y2="5" stroke="#b4bfff" stroke-width="1.4" stroke-linecap="round"/>' +
      '<circle class="c-ant" cx="16" cy="4" r="2" fill="#f472b6"/>' +
      '<circle cx="5.2" cy="17" r="1.7" fill="#7f8cf7"/><circle cx="26.8" cy="17" r="1.7" fill="#7f8cf7"/>' +
      '<rect x="6" y="8.2" width="20" height="17.6" rx="6" fill="url(#uohc-bot)"/><rect x="8.8" y="11.2" width="14.4" height="10.6" rx="4" fill="#1b1946"/>' +
      visorEyes(11.4, 18, 14.2, 2.6, 3.8) + '</g>' },
    { id: "piggy", name: "Piggy", art:
      '<circle class="c-coin" cx="16" cy="2.8" r="2.3" fill="#fbbf24" stroke="#d97706" stroke-width="0.6"/>' +
      '<g class="c-squish"><path d="M7.8 11L9 5.6L13 8.8ZM24.2 11L23 5.6L19 8.8Z" fill="#f7a6cf"/>' +
      '<circle cx="16" cy="17" r="10.5" fill="url(#uohc-pig)"/><rect x="13.4" y="7.4" width="5.2" height="1.4" rx="0.7" fill="#9d174d" opacity="0.7"/>' +
      eyes(11.6, 20.4, 14.8, 1.5, 2, "#4a1630") +
      '<ellipse cx="16" cy="19.8" rx="4.2" ry="3" fill="#f472b6"/>' +
      '<ellipse cx="14.6" cy="19.8" rx="0.8" ry="1.1" fill="#9d174d"/><ellipse cx="17.4" cy="19.8" rx="0.8" ry="1.1" fill="#9d174d"/></g>' },
    { id: "chatty", name: "Chatty", art:
      '<g class="c-float"><path class="c-tail" d="M9.6 21L6.6 27.4L14.6 22.4Z" fill="#74d4ea"/>' +
      '<rect x="3.5" y="5.5" width="25" height="17.5" rx="8.5" fill="url(#uohc-chat)"/>' +
      '<g class="c-face">' + eyes(12.6, 19.4, 13, 1.6, 2.2, "#0b3b47") + smile("M14 16.9Q16 18.8 18 16.9", "#0b3b47") + '</g>' +
      '<g class="c-dots"><circle cx="11" cy="14.3" r="1.7" fill="#0b3b47"/><circle cx="16" cy="14.3" r="1.7" fill="#0b3b47"/><circle cx="21" cy="14.3" r="1.7" fill="#0b3b47"/></g></g>' },
    { id: "lucky", name: "Lucky", art:
      '<path d="M7 14L8.2 5.6L13.4 9.6Q16 9 18.6 9.6L23.8 5.6L25 14Q25.6 24 16 24.4Q6.4 24 7 14Z" fill="#fff7ed"/>' +
      '<path d="M9 8.4L9.6 11.3L11.8 9.6ZM23 8.4L22.4 11.3L20.2 9.6Z" fill="#fda4af"/>' +
      '<path d="M10.8 15.6Q12.4 13.8 14 15.6M18 15.6Q19.6 13.8 21.2 15.6" fill="none" stroke="#3f2a1d" stroke-width="1.3" stroke-linecap="round"/>' +
      '<path d="M15.2 17.3H16.8L16 18.3Z" fill="#fb7185"/>' +
      '<path d="M14.6 18.9Q15.3 19.8 16 18.9Q16.7 19.8 17.4 18.9" fill="none" stroke="#3f2a1d" stroke-width="0.9" stroke-linecap="round"/>' +
      '<ellipse cx="10.6" cy="18.6" rx="1.4" ry="0.8" fill="#fda4af" opacity="0.75"/><ellipse cx="21.4" cy="18.6" rx="1.4" ry="0.8" fill="#fda4af" opacity="0.75"/>' +
      '<rect x="9.5" y="21.6" width="13" height="2.6" rx="1.3" fill="#ef4444"/><circle cx="16" cy="24.6" r="1.6" fill="#fbbf24"/>' +
      '<g class="c-paw"><rect x="23.4" y="8.6" width="4.6" height="8.6" rx="2.3" fill="#fff7ed" stroke="#f1d7c2" stroke-width="0.6"/>' +
      '<ellipse cx="25.7" cy="10.8" rx="1.15" ry="0.9" fill="#fda4af"/></g>' },
    { id: "scout", name: "Scout", art:
      '<g class="c-scan"><line x1="20.7" y1="20.7" x2="27" y2="27" stroke="#8b5cf6" stroke-width="4.2" stroke-linecap="round"/>' +
      '<circle cx="13.5" cy="13.5" r="9.2" fill="#e8f4ff"/><circle cx="13.5" cy="13.5" r="9.2" fill="none" stroke="#a78bfa" stroke-width="2.4"/>' +
      '<g class="c-eyes"><circle cx="13.5" cy="13.5" r="4.7" fill="#3b82f6"/>' +
      '<g class="c-pupil"><circle cx="13.5" cy="13.5" r="2.4" fill="#0b1220"/><circle cx="14.6" cy="12.3" r="0.95" fill="#fff"/></g></g></g>' },
    { id: "walty", name: "Walty", art:
      '<g class="c-card"><rect x="8.6" y="5.6" width="14.6" height="9.6" rx="1.8" fill="#818cf8"/><rect x="10.6" y="7.6" width="3.2" height="2.5" rx="0.6" fill="#fde68a"/></g>' +
      '<rect x="4" y="10.6" width="24" height="16.6" rx="4" fill="url(#uohc-wal)"/>' +
      '<path d="M28 15.4H22.6Q20.6 15.4 20.6 17.6Q20.6 19.8 22.6 19.8H28Z" fill="#0f766e"/><circle cx="23" cy="17.6" r="0.95" fill="#fde68a"/>' +
      eyes(10, 15.6, 17.4, 1.45, 1.95, "#073b33") + smile("M11.2 21Q12.8 22.6 14.4 21", "#073b33") },
    { id: "buzz", name: "Buzz", art:
      '<g class="c-hover"><g class="c-wing"><ellipse cx="10.2" cy="9.4" rx="4.8" ry="3.3" fill="#e0f2fe" opacity="0.9" transform="rotate(-28 10.2 9.4)"/></g>' +
      '<g class="c-wing"><ellipse cx="21.8" cy="9.4" rx="4.8" ry="3.3" fill="#e0f2fe" opacity="0.9" transform="rotate(28 21.8 9.4)"/></g>' +
      '<path d="M13 9.6Q11.6 6 9.4 5M19 9.6Q20.4 6 22.6 5" fill="none" stroke="#1f2937" stroke-width="1" stroke-linecap="round"/>' +
      '<circle cx="9.4" cy="5" r="1.05" fill="#1f2937"/><circle cx="22.6" cy="5" r="1.05" fill="#1f2937"/>' +
      '<ellipse cx="16" cy="18" rx="9.4" ry="8.8" fill="url(#uohc-bee)"/>' +
      '<g clip-path="url(#uohc-beeclip)"><rect x="5" y="21.4" width="22" height="2.2" fill="#1f2937"/><rect x="5" y="25.2" width="22" height="2.4" fill="#1f2937"/></g>' +
      eyes(12.6, 19.4, 15.6, 1.5, 2, "#1f2937") + smile("M14.4 18.6Q16 20 17.6 18.6", "#1f2937") + '</g>' },
    { id: "boxy", name: "Boxy", art:
      '<path class="c-sparkle" d="M25.5 3.5C25.8 5.2 26.3 5.7 28 6C26.3 6.3 25.8 6.8 25.5 8.5C25.2 6.8 24.7 6.3 23 6C24.7 5.7 25.2 5.2 25.5 3.5Z" fill="#fde68a"/>' +
      '<rect x="6.5" y="13.6" width="19" height="13.4" rx="2.6" fill="url(#uohc-gift)"/><rect x="14.6" y="13.6" width="2.8" height="13.4" fill="#fde68a"/>' +
      eyes(11, 21, 19, 1.45, 1.95, "#3b1446") + smile("M14.2 22.6Q16 24.3 17.8 22.6", "#3b1446") +
      '<g class="c-lid"><rect x="5" y="9.8" width="22" height="4.6" rx="1.6" fill="#f0abfc"/><rect x="14.6" y="9.8" width="2.8" height="4.6" fill="#fcd34d"/>' +
      '<path d="M16 9.8C12.4 4.6 8.6 7.8 16 9.8ZM16 9.8C19.6 4.6 23.4 7.8 16 9.8Z" fill="#fcd34d" stroke="#f59e0b" stroke-width="0.6"/></g>' },
    { id: "idea", name: "Idea", art:
      '<circle class="c-halo" cx="16" cy="12.6" r="14" fill="url(#uohc-halo)"/>' +
      '<path d="M16 3.4C21.6 3.4 25 7.5 25 12.3C25 15.7 23.2 17.8 21.4 19.5C20.4 20.5 20 21.3 20 22.5H12C12 21.3 11.6 20.5 10.6 19.5C8.8 17.8 7 15.7 7 12.3C7 7.5 10.4 3.4 16 3.4Z" fill="url(#uohc-bulb)"/>' +
      '<rect x="12" y="22.4" width="8" height="5.4" rx="1.6" fill="#94a3b8"/><path d="M12 24.3H20M12.6 26.1H19.4" stroke="#64748b" stroke-width="0.8"/>' +
      eyes(13, 19, 12.4, 1.5, 2, "#4a3a06") + smile("M14.3 16Q16 17.7 17.7 16", "#4a3a06") },
    { id: "hoot", name: "Hoot", art:
      '<g class="c-tilt"><path d="M7.4 9.4L8.8 4.4L12.6 7.6ZM24.6 9.4L23.2 4.4L19.4 7.6Z" fill="#7c6cf6"/>' +
      '<ellipse cx="16" cy="17.6" rx="10" ry="10.4" fill="url(#uohc-owl)"/><ellipse cx="16" cy="23" rx="6" ry="4.4" fill="#ddd6fe" opacity="0.45"/>' +
      '<g class="c-eyes"><circle cx="11.6" cy="14.8" r="4.3" fill="#fff"/><circle cx="20.4" cy="14.8" r="4.3" fill="#fff"/>' +
      '<g class="c-pupils"><circle cx="11.6" cy="15" r="2.2" fill="#1e1b4b"/><circle cx="20.4" cy="15" r="2.2" fill="#1e1b4b"/>' +
      '<circle cx="12.4" cy="14.1" r="0.7" fill="#fff"/><circle cx="21.2" cy="14.1" r="0.7" fill="#fff"/></g></g>' +
      '<path d="M14.8 18.8L17.2 18.8L16 20.8Z" fill="#f59e0b"/></g>' }
  ];
  var DEFAULT = "pennybot";
  var byId = {};
  LIST.forEach(function (c) { byId[c.id] = c; });

  function svg(id) {
    var c = byId[id] || byId[DEFAULT];
    return '<svg class="uohc uohc-' + c.id + '" viewBox="0 0 32 32" aria-hidden="true" focusable="false">' + c.art + '</svg>';
  }

  self.UOH_CHARS = { LIST: LIST, DEFAULT: DEFAULT, DEFS: DEFS, svg: svg, has: function (id) { return !!byId[id]; } };
  if (typeof document === "undefined") return;     // Node tests only need the list

  /* ---------- the button and the menu ---------- */

  var $ = function (id) { return document.getElementById(id); };
  var CARET = '<svg class="char-caret" viewBox="0 0 10 10" aria-hidden="true"><path d="M2 3.5l3 3 3-3"/></svg>';
  var cur = null, pop = null;

  function paint(id) {
    if (!byId[id]) id = DEFAULT;
    cur = id;
    $("ai-char").innerHTML = svg(id);
    var pick = $("chat-char");
    pick.innerHTML = svg(id) + "<span>" + byId[id].name + "</span>" + CARET;
    pick.setAttribute("aria-label", "Ask AI character: " + byId[id].name + ". Change");
    if (pop) Array.prototype.forEach.call(pop.querySelectorAll("[data-char]"), function (b) {
      b.setAttribute("aria-checked", String(b.getAttribute("data-char") === id));
    });
    try { localStorage.setItem("uohChar", id); } catch (e) { /* private window: storage below still has it */ }
  }

  function choose(id) {
    paint(id);
    closeMenu(true);
    chrome.runtime.sendMessage({ type: "UOH_PATCH_SETTINGS", patch: { aiCharacter: id } }, function () { void chrome.runtime.lastError; });
  }

  function buildMenu() {
    pop = document.createElement("div");
    pop.className = "char-pop"; pop.id = "char-pop"; pop.hidden = true;
    pop.setAttribute("role", "menu"); pop.setAttribute("aria-label", "Ask AI character");
    pop.innerHTML = '<div class="char-pop-title">Pick your Ask AI character</div><div class="char-grid">' +
      LIST.map(function (c) {
        return '<button type="button" role="menuitemradio" data-char="' + c.id + '" aria-checked="' + (c.id === cur) + '">' +
          svg(c.id) + "<span>" + c.name + "</span></button>";
      }).join("") + "</div>";
    pop.addEventListener("click", function (e) { var b = e.target.closest("[data-char]"); if (b) choose(b.getAttribute("data-char")); });
    pop.addEventListener("keydown", function (e) {            // arrows move through the 4-wide grid
      var step = { ArrowLeft: -1, ArrowRight: 1, ArrowUp: -4, ArrowDown: 4 }[e.key];
      if (!step) return;
      var items = pop.querySelectorAll("[data-char]"), i = Array.prototype.indexOf.call(items, document.activeElement);
      items[Math.max(0, Math.min(items.length - 1, i < 0 ? 0 : i + step))].focus();
      e.preventDefault();
    });
    document.body.appendChild(pop);
  }

  function openMenu() {
    if (!pop) buildMenu();
    var btn = $("chat-char"), r = btn.getBoundingClientRect();
    pop.hidden = false;
    pop.style.top = (r.bottom + 6) + "px";
    pop.style.left = Math.max(8, Math.min(r.right - pop.offsetWidth, window.innerWidth - pop.offsetWidth - 8)) + "px";
    btn.setAttribute("aria-expanded", "true");
    var on = pop.querySelector('[aria-checked="true"]');
    if (on) on.focus();
  }
  function closeMenu(refocus) {
    if (!pop || pop.hidden) return;
    pop.hidden = true;
    $("chat-char").setAttribute("aria-expanded", "false");
    if (refocus) $("chat-char").focus();
  }

  document.body.insertAdjacentHTML("afterbegin", DEFS);
  var first = null;
  try { first = localStorage.getItem("uohChar"); } catch (e) { /* no mirror: the default until storage answers */ }
  paint(first || DEFAULT);

  $("chat-char").addEventListener("click", function (e) {
    e.stopPropagation();
    if (pop && !pop.hidden) closeMenu(); else openMenu();
  });
  document.addEventListener("click", function (e) {
    if (pop && !pop.hidden && !e.target.closest("#char-pop")) closeMenu();
  });
  // Esc closes this menu before the dashboard's own Esc handling (which would close the chat).
  window.addEventListener("keydown", function (e) {
    if (e.key !== "Escape" || !pop || pop.hidden) return;
    closeMenu(true);
    e.stopImmediatePropagation();
    e.preventDefault();
  }, true);
  window.addEventListener("resize", function () { closeMenu(); });

  chrome.storage.local.get(["UOH_Settings"]).then(function (r) {
    var id = ((r && r.UOH_Settings) || {}).aiCharacter;
    if (id && byId[id] && id !== cur) paint(id);
  });
  chrome.storage.onChanged.addListener(function (changes, area) {     // picked in another dashboard tab
    if (area !== "local" || !changes.UOH_Settings) return;
    var id = (changes.UOH_Settings.newValue || {}).aiCharacter;
    if (id && byId[id] && id !== cur) paint(id);
  });
})();
