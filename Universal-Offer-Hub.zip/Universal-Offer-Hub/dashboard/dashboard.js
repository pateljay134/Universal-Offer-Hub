/*
 * Universal Offer Hub — Dashboard
 * --------------------------------
 * The full-page view of the hub, opened from the popup:
 *   - every active offer, one row per distinct offer (the same offer on
 *     several cards lists all of them), with views for New this week and
 *     Expiring soon;
 *   - spreadsheet-style table: click a column title to sort, use the ▾ in
 *     the header to filter (cards are grouped by issuer);
 *   - Cards: nicknames and each card's priority (drag or arrows); the
 *     higher card is listed first, and Amex auto-add uses a login's order;
 *   - Ask AI: a chat answered by the AI the user connects with their own
 *     key (lib/ai.js), or by plain rules when none is connected; replies
 *     list every match and can be downloaded;
 *   - Copy (the rows on screen), CSV, the live copy for AI apps, and Open AI
 *     chat: ChatGPT, Claude or Gemini in the browser, or the Claude Desktop
 *     app through a one-time plugin setup (lib/mcpb.js).
 *
 * Reads come straight from chrome.storage; writes are messages to the
 * service worker, the hub's only writer.
 */
(function () {
  "use strict";

  var $ = function (id) { return document.getElementById(id); };
  function esc(s) {
    return String(s == null ? "" : s)
      .replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;").replace(/'/g, "&#39;");
  }
  function send(msg) {
    return new Promise(function (resolve) {
      chrome.runtime.sendMessage(msg, function (r) { void chrome.runtime.lastError; resolve(r || {}); });
    });
  }
  function ago(ts) {
    var s = Math.max(0, Math.round((Date.now() - ts) / 1000));
    if (s < 60) return "just now";
    if (s < 3600) return Math.round(s / 60) + " min ago";
    if (s < 86400) return Math.round(s / 3600) + " h ago";
    return Math.round(s / 86400) + " days ago";
  }
  var toastTimer = null;
  function toast(msg, ms) {
    var t = $("toast");
    t.textContent = msg;
    t.hidden = false;
    clearTimeout(toastTimer);
    toastTimer = setTimeout(function () { t.hidden = true; }, ms || 4500);
  }

  /* ---------- state ---------- */
  var S = { db: {}, settings: {}, cats: {}, auto: {}, live: {}, run: null };
  // f.cards / f.cats / f.types: null = everything, else the list that's ticked.
  var UI = { view: "all", query: "", sort: { key: "expires", dir: 1 }, f: { cards: null, cats: null, types: null, exp: "any" } };
  var limit = 300;
  var rows = [];      // active offers, merged across cards, with .cat / .usd / .extra
  try {
    var saved = JSON.parse(localStorage.getItem("uoh-dash2") || "{}");
    if (saved.view) UI.view = saved.view;
    if (saved.sort && saved.sort.key) UI.sort = saved.sort;
    if (saved.f) UI.f = Object.assign(UI.f, saved.f);
    if (typeof saved.query === "string") UI.query = saved.query;
  } catch (e) {}
  function saveUI() { try { localStorage.setItem("uoh-dash2", JSON.stringify(UI)); } catch (e) {} }

  function load() {
    return Promise.all([
      chrome.storage.local.get(["UOH_Database", "UOH_Settings", "UOH_Categories", "UOH_AutoState", "UOH_LiveFile"]),
      chrome.storage.session.get(["UOH_Run"])
    ]).then(function (r) {
      S.db = r[0].UOH_Database || {};
      S.settings = r[0].UOH_Settings || {};
      S.cats = r[0].UOH_Categories || {};
      S.auto = r[0].UOH_AutoState || {};
      S.live = r[0].UOH_LiveFile || {};
      S.run = r[1].UOH_Run || null;
      rebuild();
    });
  }

  function records() { return Object.keys(S.db).map(function (k) { return S.db[k]; }); }

  function rebuild() {
    var now = Date.now();
    var active = records().filter(function (o) { return UOH.isActive(o, now); });
    rows = UOH.mergeDuplicates(active, { cards: S.settings.cards });
    rows.forEach(function (r) {
      r.cat = UOH_CATS.categorize(r.m, r.v, S.cats);
      r.usd = UOH.estValueUsd(r.v);
      r.pct = UOH.parseTerms(r.v).pct;
      r.extra = r.cards.map(function (c) { return c.label; }).join(" ") + " " + r.cat;
    });
  }

  // Every card in the hub, for the Card filter and Ask: issuer by issuer,
  // each issuer's cards in the order set in the Cards panel. Store coupons
  // (Walgreens, Safeway) have no card; they count as one entry.
  function cardList() {
    var reg = S.settings.cards || {}, seen = {}, out = [];
    records().forEach(function (o) {
      var k = UOH.cardKey(o);
      if (seen[k]) { seen[k].count++; return; }
      var name = String(o.card || "").replace(/\s*••\d+$/, "");
      var e = seen[k] = { key: k, site: o.site, count: 1,
                          label: UOH.cardLabel(o, S.settings.cards) || (o.site + " coupons"),
                          nick: (reg[k] && reg[k].nick) || "", name: (reg[k] && reg[k].name) || name };
      out.push(e);
    });
    // The sort is stable: the issuer sort keeps each issuer's card order.
    return UOH.sortCards(out, reg, function (c) { return c.label; })
      .sort(function (a, b) { return String(a.site).localeCompare(String(b.site)); });
  }

  /* ---------- header, run line, notice, KPIs ---------- */
  function renderHeader() {
    var cards = {};
    rows.forEach(function (r) { r.cards.forEach(function (c) { cards[c.key] = 1; }); });
    var last = 0;
    records().forEach(function (o) { if ((o.ts || 0) > last) last = o.ts; });
    var n = Object.keys(cards).length;
    $("meta").textContent = rows.length.toLocaleString() + " active offers · " + n + (n === 1 ? " card" : " cards") +
      (last ? " · updated " + ago(last) : "");
  }

  function renderRunLine() {
    var el = $("run-line");
    if (S.run && S.run.phase !== "done") {
      el.hidden = false;
      el.innerHTML = "Background Amex run: " + esc(S.run.status || "starting") + ' <button class="link" id="stop-run">Stop</button>';
      $("stop-run").onclick = function () { send({ type: "UOH_STOP_RUN" }); };
    } else {
      el.hidden = true;
    }
  }

  function unconfirmedLogins() {
    var reg = S.settings.cards || {}, out = {};
    Object.keys(reg).forEach(function (k) {
      if (k.indexOf("Amex|") === 0 && reg[k].login && !reg[k].confirmed) out[reg[k].login] = 1;
    });
    return Object.keys(out);
  }

  function renderNotice() {
    var el = $("notice"), pending = unconfirmedLogins();
    if (!pending.length) { el.hidden = true; return; }
    el.hidden = false;
    el.innerHTML = esc((pending.length === 1 ? "Amex auto-add is waiting for you:" : pending.length + " Amex logins are waiting for you:") +
      " choose which cards get offers and their order. Nothing is added until you confirm.") +
      ' <button class="link" id="notice-cards">Choose cards</button>';
    $("notice-cards").onclick = openCards;
  }

  function renderKpis() {
    var now = Date.now(), fresh = rows.filter(function (r) { return UOH.isNew(r, now); }).length;
    $("kpis").innerHTML =
      '<div class="kpi"><div class="kpi-label">Active offers</div><div class="kpi-num">' + rows.length.toLocaleString() +
      '</div><div class="kpi-sub">one row per offer, all cards</div></div>' +
      '<div class="kpi new"><div class="kpi-label">New this week</div><div class="kpi-num">' + fresh.toLocaleString() +
      '</div><div class="kpi-sub">first seen in the last 7 days</div></div>';
  }

  /* ---------- views ---------- */
  var VIEWS = [["all", "All"], ["new", "New this week"], ["soon", "Expiring soon"]];
  function inView(r, v, now) {
    if (v === "new") return UOH.isNew(r, now);
    if (v === "soon") { var d = UOH.daysLeft(r, now); return d != null && d <= 7; }
    return true;
  }
  function renderViews() {
    var now = Date.now();
    $("views").innerHTML = VIEWS.map(function (v) {
      var n = rows.filter(function (r) { return inView(r, v[0], now); }).length;
      return '<button class="view' + (UI.view === v[0] ? " active" : "") + '" data-view="' + v[0] + '" role="tab">' +
        esc(v[1]) + '<span class="count">' + n.toLocaleString() + "</span></button>";
    }).join("");
  }

  /* ---------- filtering and sorting ---------- */
  var TYPES = [["PERCENT", "% back"], ["DOLLAR", "$ back"], ["MILES", "Points and miles"], ["MULTI", "Multiplier"], ["OTHER", "Other"]];
  var EXP = [["any", "Any time"], ["0", "Today"], ["3", "Next 3 days"], ["7", "Next 7 days"], ["30", "Next 30 days"], ["none", "No end date"]];
  function typeOf(r) {
    var t = r.t || "OTHER";
    if (t === "SPEND_GET") return "DOLLAR";
    return TYPES.some(function (x) { return x[0] === t; }) ? t : "OTHER";
  }

  // `skip` leaves one filter out, for the counts shown inside that filter.
  function passes(r, now, skip) {
    var f = UI.f;
    if (skip !== "cards" && f.cards && !r.cards.some(function (c) { return f.cards.indexOf(c.key) > -1; })) return false;
    if (skip !== "cats" && f.cats && f.cats.indexOf(r.cat) < 0) return false;
    if (skip !== "types" && f.types && f.types.indexOf(typeOf(r)) < 0) return false;
    if (skip !== "exp" && f.exp !== "any") {
      var d = UOH.daysLeft(r, now);
      if (f.exp === "none") { if (d != null) return false; }
      else if (d == null || d > +f.exp) return false;
    }
    return true;
  }

  function filtered() {
    var now = Date.now(), tokens = UOH.tokenize(UI.query);
    var out = rows.filter(function (r) {
      return inView(r, UI.view, now) && passes(r, now) && (!tokens.length || UOH.scoreOffer(r, tokens, r.extra) > 0);
    });
    var k = UI.sort.key, dir = UI.sort.dir;
    var exp = function (r) { var e = UOH.expiresAt(r); return e == null ? 8.64e15 : e; };
    var byName = function (a, b) { return (a.m || "").localeCompare(b.m || ""); };
    out.sort(function (a, b) {
      var c = 0;
      if (k === "store") c = byName(a, b);
      else if (k === "offer") c = ((a.usd || 0) - (b.usd || 0)) || ((a.pct || 0) - (b.pct || 0)) || ((a.n || 0) - (b.n || 0));
      else if (k === "category") c = (a.cat || "").localeCompare(b.cat || "");
      else if (k === "card") c = (a.cards[0] ? a.cards[0].label : "").localeCompare(b.cards[0] ? b.cards[0].label : "");
      else if (k === "source") c = (a.site || "").localeCompare(b.site || "");
      else c = exp(a) - exp(b);
      return dir * c || byName(a, b);
    });
    return out;
  }

  function filtersActive() {
    var f = UI.f;
    return !!(f.cards || f.cats || f.types || f.exp !== "any");
  }

  // Plain words for what the list shows; heads the copied text.
  function describeFilters() {
    var f = UI.f, parts = [];
    if (UI.view !== "all") parts.push(UI.view === "new" ? "new this week" : "expiring in 7 days");
    if (f.cards) {
      var lab = {};
      cardList().forEach(function (c) { lab[c.key] = c.label; });
      parts.push("cards: " + f.cards.map(function (k) { return lab[k] || k; }).join(", "));
    }
    if (f.cats) parts.push("categories: " + f.cats.join(", "));
    if (f.types) parts.push("types: " + f.types.map(function (t) { return (TYPES.filter(function (x) { return x[0] === t; })[0] || [t, t])[1]; }).join(", "));
    if (f.exp !== "any") parts.push(f.exp === "none" ? "no end date" : (f.exp === "0" ? "expiring today" : "expiring within " + f.exp + " days"));
    if (UI.query) parts.push('matching "' + UI.query + '"');
    return parts.join("; ");
  }

  function renderHead() {
    Array.prototype.forEach.call(document.querySelectorAll(".th-sort"), function (b) {
      var on = b.getAttribute("data-sort") === UI.sort.key;
      b.classList.toggle("active", on);
      b.querySelector(".arrow").textContent = on ? (UI.sort.dir > 0 ? "↑" : "↓") : "";
    });
    Array.prototype.forEach.call(document.querySelectorAll(".th-filter"), function (b) {
      var k = b.getAttribute("data-filter");
      b.classList.toggle("on", k === "exp" ? UI.f.exp !== "any" : !!UI.f[k]);
    });
  }

  /* ---------- table ---------- */
  function valueChips(v) {
    var t = UOH.parseTerms(v), out = [];
    if (t.reward != null) out.push((t.spendMin != null ? "Spend $" + t.spendMin.toLocaleString() + " → " : "") + "$" + t.reward.toLocaleString() + " back");
    if (t.times && t.total != null) out.push("×" + t.times + " · up to $" + t.total.toLocaleString());
    if (t.pct != null) out.push(t.pct + "% back" + (t.cap != null ? " · up to $" + t.cap.toLocaleString() : ""));
    if (t.points != null) out.push((t.spendMin != null ? "Spend $" + t.spendMin.toLocaleString() + " → " : "") + t.points.toLocaleString() + " pts");
    if (t.ptsPerDollar != null) out.push("+" + t.ptsPerDollar + " pts/$" + (t.ptsCap != null ? " · up to " + t.ptsCap.toLocaleString() : ""));
    return out;
  }

  function expiryCell(r, now) {
    if (!r.expiresTs) return esc(r.days || "");
    var dl = UOH.daysLeft(r, now);
    var cls = dl <= 3 ? "dl urgent" : dl <= 7 ? "dl soon" : "dl";
    var d = new Date(r.expiresTs);
    return esc(d.toLocaleDateString(undefined, { month: "short", day: "numeric" })) + '<div class="' + cls + '">' +
      esc(dl === 0 ? "today" : dl === 1 ? "1 day" : dl + " days") + "</div>";
  }

  function rowHtml(r, now) {
    var src = UOH_SOURCES.find(function (s) { return s.id === r.site; });
    var chips = valueChips(r.v).map(function (c) { return '<span class="vchip">' + esc(c) + "</span>"; }).join("");
    return "<tr>" +
      '<td><span class="store">' + esc(r.m) + (UOH.isNew(r, now) ? '<span class="new-tag">NEW</span>' : "") + "</span></td>" +
      '<td><div class="otext">' + esc(r.v) + "</div>" + (chips ? '<div class="vchips">' + chips + "</div>" : "") + "</td>" +
      '<td><span class="cat">' + esc(r.cat) + "</span></td>" +
      '<td><div class="cards">' + r.cards.map(function (c) {
        return '<span class="card-tag" title="' + esc(c.label) + '">' + esc(c.label || r.site) + "</span>";
      }).join("") + "</div></td>" +
      '<td><span class="site-tag" style="background:' + (src ? src.color : "#475569") + '">' + esc(src ? src.shortName : r.site) + "</span></td>" +
      '<td class="exp">' + expiryCell(r, now) + "</td>" +
      "</tr>";
  }

  function renderTable() {
    var list = filtered(), now = Date.now();
    $("count").textContent = list.length.toLocaleString() + (list.length === 1 ? " offer" : " offers") +
      (list.length > limit ? " · showing " + limit.toLocaleString() : "");
    $("clear-filters").hidden = !filtersActive();
    $("copy-list").disabled = !list.length;
    $("rows").innerHTML = list.length ? list.slice(0, limit).map(function (r) { return rowHtml(r, now); }).join("")
      : '<tr><td colspan="6" class="empty">' + (rows.length ? "No offers match these filters." : "No offers saved yet. Open a supported site and run its autopilot.") + "</td></tr>";
    $("more").hidden = list.length <= limit;
    renderHead();
  }

  function renderAll() {
    // Clear all emptied the hub: the chat's offers go with it.
    if (!records().length && chat.turns.length) newChat();
    renderHeader(); renderRunLine(); renderNotice(); renderKpis(); renderViews(); renderTable(); renderLive();
    if ($("cards-panel").hidden === false) renderCards();
    if (!$("filter-pop").hidden && popKind) renderPop();
  }

  /* ---------- column filter dropdown ---------- */
  var popKind = null;

  function openPop(kind, anchor) {
    if (popKind === kind && !$("filter-pop").hidden) { closePop(); return; }
    popKind = kind;
    renderPop();
    var pop = $("filter-pop"), r = anchor.getBoundingClientRect();
    pop.hidden = false;
    pop.style.left = Math.max(8, Math.min(r.left - 8, window.innerWidth - pop.offsetWidth - 12)) + "px";
    pop.style.top = (r.bottom + 4) + "px";
  }
  function closePop() { $("filter-pop").hidden = true; popKind = null; }

  // Counts inside a filter ignore that filter itself, like a spreadsheet.
  function countsFor(kind, keysOf) {
    var now = Date.now(), tokens = UOH.tokenize(UI.query), out = {};
    rows.forEach(function (r) {
      if (!inView(r, UI.view, now) || !passes(r, now, kind)) return;
      if (tokens.length && !UOH.scoreOffer(r, tokens, r.extra)) return;
      keysOf(r).forEach(function (k) { out[k] = (out[k] || 0) + 1; });
    });
    return out;
  }

  function checkRow(value, label, count, checked, cls, group) {
    return '<label class="fp-row ' + (cls || "") + '"><input type="checkbox" ' +
      (group ? 'data-group="' + esc(group) + '"' : 'value="' + esc(value) + '"') + (checked ? " checked" : "") +
      '><span class="fp-label">' + esc(label) + '</span><span class="fp-count">' +
      (count == null ? "" : count.toLocaleString()) + "</span></label>";
  }

  function renderPop() {
    var pop = $("filter-pop"), f = UI.f, html = "";
    if (popKind === "exp") {
      html = EXP.map(function (e) {
        return '<label class="fp-row"><input type="radio" name="fp-exp" value="' + e[0] + '"' + (f.exp === e[0] ? " checked" : "") +
          '><span class="fp-label">' + esc(e[1]) + "</span></label>";
      }).join("");
    } else {
      html = '<div class="fp-actions"><button class="link" data-all="1">Select all</button><button class="link" data-none="1">Clear</button></div>';
      if (popKind === "types") {
        var tc = countsFor("types", function (r) { return [typeOf(r)]; });
        html += TYPES.map(function (t) { return checkRow(t[0], t[1], tc[t[0]] || 0, !f.types || f.types.indexOf(t[0]) > -1); }).join("");
      } else if (popKind === "cats") {
        var cc = countsFor("cats", function (r) { return [r.cat]; });
        html += UOH_CATS.LIST.filter(function (c) { return rows.some(function (r) { return r.cat === c; }); }).map(function (c) {
          return checkRow(c, c, cc[c] || 0, !f.cats || f.cats.indexOf(c) > -1);
        }).join("");
      } else if (popKind === "cards") {
        // Issuer first, its cards under it. Ticking the issuer ticks them all.
        var kc = countsFor("cards", function (r) { return r.cards.map(function (c) { return c.key; }); });
        var bySite = {};
        cardList().forEach(function (c) { (bySite[c.site] = bySite[c.site] || []).push(c); });
        Object.keys(bySite).sort().forEach(function (site) {
          var list = bySite[site];   // already in the order set in Cards (cardList)
          var on = list.filter(function (c) { return !f.cards || f.cards.indexOf(c.key) > -1; }).length;
          var total = list.reduce(function (n, c) { return n + (kc[c.key] || 0); }, 0);
          html += checkRow("", site, total, on === list.length, "fp-group" + (on && on < list.length ? " partial" : ""), site);
          if (list.length > 1 || list[0].label !== site + " coupons") {
            html += list.map(function (c) { return checkRow(c.key, c.label, kc[c.key] || 0, !f.cards || f.cards.indexOf(c.key) > -1, "fp-child"); }).join("");
          }
        });
      }
    }
    pop.innerHTML = html;
    // An issuer whose cards are only partly ticked shows the in-between state.
    Array.prototype.forEach.call(pop.querySelectorAll(".fp-group.partial input"), function (i) { i.indeterminate = true; });
  }

  function allValues(kind) {
    if (kind === "types") return TYPES.map(function (t) { return t[0]; });
    if (kind === "cats") return UOH_CATS.LIST.slice();
    return cardList().map(function (c) { return c.key; });
  }

  function setFilter(kind, list) {
    var full = allValues(kind).every(function (v) { return list.indexOf(v) > -1; });
    UI.f[kind] = full ? null : list;
    limit = 300; saveUI(); renderPop(); renderTable();
  }

  function onPopChange(e) {
    var t = e.target, kind = popKind;
    if (!kind) return;
    if (kind === "exp") { UI.f.exp = t.value; limit = 300; saveUI(); renderTable(); return; }
    var current = UI.f[kind] ? UI.f[kind].slice() : allValues(kind);
    var group = t.getAttribute("data-group");
    var keys = group ? cardList().filter(function (c) { return c.site === group; }).map(function (c) { return c.key; }) : [t.value];
    keys.forEach(function (k) {
      var i = current.indexOf(k);
      if (t.checked && i < 0) current.push(k);
      if (!t.checked && i > -1) current.splice(i, 1);
    });
    setFilter(kind, current);
  }

  /* ---------- cards panel ----------
   * Each Amex login auto-add found is a group; per issuer, every other card
   * (other issuers, and Amex cards no login claimed yet) is one more. The
   * order inside a group is the cards' priority: drag a row by its grip
   * (bind()), or use its arrows. Every move saves the whole group's order
   * (UOH.rankPatch), then the panel redraws from the saved settings. */
  function openCards() { $("cards-panel").hidden = false; renderCards(); if (location.hash !== "#cards") history.replaceState(null, "", "#cards"); }
  function closeCards() { $("cards-panel").hidden = true; history.replaceState(null, "", location.pathname); }

  function cardIndex() {
    var reg = S.settings.cards || {}, seen = {};
    records().forEach(function (o) {
      if (!o.card && !o.cardId) return;
      var k = UOH.cardKey(o), e = seen[k];
      if (!e) e = seen[k] = { key: k, site: o.site, name: String(o.card || "").replace(/\s*••\d+$/, ""), digits: UOH.cardDigits(o), count: 0 };
      e.count++;
    });
    Object.keys(reg).forEach(function (k) {
      if (!seen[k]) seen[k] = { key: k, site: k.split("|")[0], name: reg[k].name || "", digits: reg[k].digits || "", count: 0 };
      else if (reg[k].name) seen[k].name = reg[k].name;
    });
    return seen;
  }

  // Ranked cards first, lowest rank on top; the rest by name.
  function inOrder(list) {
    return UOH.sortCards(list, S.settings.cards, function (c) { return c.name + c.digits; });
  }

  function renderCards() {
    var reg = S.settings.cards || {}, idx = cardIndex(), bySite = {}, keep = focusedArrow();
    Object.keys(idx).forEach(function (k) { (bySite[idx[k].site] = bySite[idx[k].site] || []).push(idx[k]); });
    var html = "";
    Object.keys(bySite).sort().forEach(function (site) {
      var list = bySite[site], logins = {}, loose = [];
      list.forEach(function (c) {
        var l = reg[c.key] && reg[c.key].login;
        if (site === "Amex" && l) (logins[l] = logins[l] || []).push(c); else loose.push(c);
      });
      html += '<div class="issuer"><div class="issuer-name">' + esc(site) + "</div>";
      Object.keys(logins).forEach(function (l) {
        var cards = inOrder(logins[l]);
        var confirmed = cards.every(function (c) { return reg[c.key] && reg[c.key].confirmed; });
        html += '<div class="login' + (confirmed ? "" : " pending") + '" data-login="' + esc(l) + '"><div class="login-head"><span>Login with ' +
          esc(cards.map(function (c) { return "••" + c.digits; }).join(", ")) + "</span>" +
          (confirmed ? '<span><span class="ok">Order confirmed</span> <button class="link" data-addnow="1">Add offers now</button></span>' : "") +
          "</div>" +
          (confirmed ? "" : '<p class="login-ask">Offer Hub read these cards. Leave Add on for the cards that should get offers, ' +
            "put them in order (the top card gets an offer first), then confirm.</p>") +
          cardGroup(cards, true) +
          (confirmed ? "" : '<div class="login-go"><button class="btn-primary" data-confirm="' + esc(l) + '">Confirm and add offers</button></div>') +
          "</div>";
      });
      if (loose.length) {
        html += (Object.keys(logins).length ? '<div class="group-head">Other cards</div>' : "") + cardGroup(inOrder(loose));
      }
      html += "</div>";
    });
    $("cards-body").innerHTML = html || '<p class="panel-intro">No cards yet. Run an autopilot, or turn on Amex auto-add in the popup.</p>';
    focusArrow(keep);
  }
  function cardGroup(cards, autoAdd) {
    return '<ol class="card-list">' + cards.map(function (c, i) { return cardItem(c, i, cards.length, autoAdd); }).join("") + "</ol>";
  }

  var GRIP = '<svg viewBox="0 0 8 14" aria-hidden="true"><circle cx="2" cy="2" r="1.2"/><circle cx="6" cy="2" r="1.2"/>' +
    '<circle cx="2" cy="7" r="1.2"/><circle cx="6" cy="7" r="1.2"/><circle cx="2" cy="12" r="1.2"/><circle cx="6" cy="12" r="1.2"/></svg>';
  // Grip, rank, name, nickname, offers, arrows, Add. Every row has the same
  // columns, so names line up across groups; a card alone in its group has
  // nothing to order, so .solo hides those parts but keeps their space. Add
  // (auto-add logins only) turns adding offers to that card on or off.
  function cardItem(c, i, n, autoAdd) {
    var set = (S.settings.cards || {})[c.key] || {}, nick = set.nick || "", skip = autoAdd && set.skip === true;
    var label = (c.name || c.site) + (c.digits ? " ••" + c.digits : ""), name = esc(label), key = esc(c.key);
    return '<li class="card-item' + (n === 1 ? " solo" : "") + (skip ? " skipped" : "") + '" data-key="' + key + '">' +
      '<span class="grip" title="Drag to change the order">' + GRIP + "</span>" +
      '<span class="rank">' + (i + 1) + "</span>" +
      '<span class="cname" title="' + name + '">' + name + "</span>" +
      '<input class="nick" data-nick="' + key + '" value="' + esc(nick) + '" placeholder="Nickname (e.g. Mom)" maxlength="24">' +
      '<span class="cnt">' + c.count + (c.count === 1 ? " offer" : " offers") + "</span>" +
      '<span class="moves"><button class="mv" data-up="' + key + '"' + (i === 0 ? " disabled" : "") +
      ' aria-label="' + esc("Move " + label + " up") + '">▲</button>' +
      '<button class="mv" data-down="' + key + '"' + (i === n - 1 ? " disabled" : "") +
      ' aria-label="' + esc("Move " + label + " down") + '">▼</button></span>' +
      (autoAdd ? '<label class="add-tog" title="' + esc("Add offers to " + label) + '"><input type="checkbox" data-add="' + key + '"' +
                 (skip ? "" : " checked") + "> Add</label>" : '<span class="add-tog"></span>') +
      '<button class="rm" data-rm="' + key + '" title="Remove this card from Offer Hub" aria-label="' +
      esc("Remove " + label + " from Offer Hub") + '">×</button></li>';
  }

  // Remove asks first, in a line under the card: the card's saved offers go
  // with it. Nothing changes at the bank.
  function askRemove(btn) {
    var li = btn.closest(".card-item"), key = li.getAttribute("data-key"), open = li.nextElementSibling;
    if (open && open.classList.contains("card-confirm")) { open.remove(); return; }
    var c = cardIndex()[key] || {}, label = (c.name || c.site || "") + (c.digits ? " ••" + c.digits : "");
    li.insertAdjacentHTML("afterend", '<li class="card-confirm"><span>' + esc("Remove " + label +
      (c.count ? " and its " + c.count + (c.count === 1 ? " saved offer" : " saved offers") : "") +
      " from Offer Hub? Nothing changes at the bank.") + '</span><button class="btn-ghost" data-rm-no="1">Keep</button>' +
      '<button class="btn-danger" data-rm-yes="' + esc(key) + '">Remove</button></li>');
    li.nextElementSibling.querySelector("[data-rm-no]").focus();
  }
  function removeCard(key) {
    send({ type: "UOH_REMOVE_CARD", key: key }).then(function (r) {
      toast(r && r.ok ? "Removed the card" + (r.removed ? " and " + r.removed + (r.removed === 1 ? " offer." : " offers.") : ".")
                      : "Couldn't remove the card.");
    });
  }

  function rowKeys(list) {
    return Array.prototype.filter.call(list.children, function (li) { return li.classList.contains("card-item"); })
      .map(function (li) { return li.getAttribute("data-key"); });
  }
  // Shows the group in this order right away, then saves it. The redraw
  // that follows the save draws the same order.
  function setOrder(list, keys) {
    var rows = {}, n = keys.length;
    Array.prototype.forEach.call(list.querySelectorAll(".card-confirm"), function (li) { li.remove(); });
    Array.prototype.forEach.call(list.children, function (li) { rows[li.getAttribute("data-key")] = li; });
    keys.forEach(function (k, i) {
      var li = rows[k];
      list.appendChild(li);
      li.querySelector(".rank").textContent = i + 1;
      li.querySelector("[data-up]").disabled = i === 0;
      li.querySelector("[data-down]").disabled = i === n - 1;
    });
    // Name and digits go with the rank: a card with no offers left (after Clear all)
    // is listed from its settings alone and would otherwise show as just the issuer.
    var idx = cardIndex(), reg = S.settings.cards || {}, patch = UOH.rankPatch(keys);
    keys.forEach(function (k) {
      var c = idx[k], have = reg[k] || {};
      if (c && c.name && !have.name) patch[k].name = c.name;
      if (c && c.digits && !have.digits) patch[k].digits = c.digits;
    });
    send({ type: "UOH_PATCH_SETTINGS", patch: { cards: patch } });
  }

  function moveCard(btn, key, dir) {
    var list = btn.closest(".card-list"), keys = rowKeys(list), to = keys.indexOf(key) + dir;
    if (to < 0 || to >= keys.length) return;
    setOrder(list, UOH.moveKey(keys, key, to));
    focusArrow({ key: key, up: dir < 0 });
  }

  // Arrow focus survives a move and the redraw after it: the same arrow of
  // the same card, or its other arrow once the card reaches that end.
  function focusedArrow() {
    var a = document.activeElement, k;
    if (!a || !$("cards-body").contains(a)) return null;
    if ((k = a.getAttribute("data-up"))) return { key: k, up: true };
    if ((k = a.getAttribute("data-down"))) return { key: k, up: false };
    return null;
  }
  function focusArrow(f) {
    if (!f) return;
    var find = function (attr) {
      return Array.prototype.filter.call($("cards-body").querySelectorAll("[" + attr + "]"), function (b) {
        return b.getAttribute(attr) === f.key;
      })[0];
    };
    var same = find(f.up ? "data-up" : "data-down"), other = find(f.up ? "data-down" : "data-up");
    var b = same && !same.disabled ? same : other && !other.disabled ? other : null;
    if (b) b.focus();
  }

  function confirmLogin(login) {
    var reg = S.settings.cards || {}, patch = {};
    Object.keys(reg).forEach(function (k) {
      if (reg[k].login === login) patch[k] = { confirmed: true };
    });
    send({ type: "UOH_PATCH_SETTINGS", patch: { cards: patch } }).then(addNow);
  }
  // Adds offers now: Amex opens in a new window and every offer on each card
  // marked Add is added, top card first. Uses your existing Amex sign-in.
  function addNow() {
    send({ type: "UOH_RUN_NOW", issuer: "Amex" }).then(function (r) {
      toast(r && r.ok ? "Adding offers now in a new Amex window, top card first. Leave it open; it closes itself when done."
          : r && r.reason === "running" ? "Offer Hub is already adding offers. Your order applies from the next run."
          : "Couldn't start. Sign in to Amex in this browser, then try again.", 9000);
    });
  }
  function setAdd(box) {
    var key = box.getAttribute("data-add"), patch = {};
    patch[key] = { skip: !box.checked };
    box.closest(".card-item").classList.toggle("skipped", !box.checked);
    send({ type: "UOH_PATCH_SETTINGS", patch: { cards: patch } });
  }

  /* ---------- ask ---------- */
  var EXAMPLES = [
    "Any luggage offers, like Away or Samsonite?",
    "Birthday gift ideas for my wife",
    "Restaurants or stores where I could buy a gift card in person",
    "What expires in the next 2 days?"
  ];
  var asking = false;

  function renderAiLine() {
    var el = $("ai-line"), c = UOH_AI.config();
    if (UOH_AI.ready()) {
      el.innerHTML = esc("Answers from " + UOH_AI.name() + " (" + c.models[c.provider] + "). " +
        "Each question sends it the matching offers.") + ' <button class="link" id="ai-change">Change</button>';
    } else {
      el.innerHTML = 'No AI connected, so the chat finds offers by plain rules. ' +
        '<button class="link" id="ai-change">Connect ChatGPT, Claude or Gemini</button>';
    }
    $("ai-change").onclick = openConnect;
  }

  /* ---------- connect an AI (own API key) ---------- */
  var connectFor = "openai";

  function openConnect() {
    var c = UOH_AI.config();
    connectFor = c.provider || connectFor;
    $("ai-panel").hidden = false;
    renderConnect();
    $("ai-key").focus();
  }
  function closeConnect() { $("ai-panel").hidden = true; }

  // ids: the models a key check just listed, so they aren't fetched again.
  function renderConnect(status, isError, ids) {
    var c = UOH_AI.config(), p = UOH_AI.PROVIDERS[connectFor], key = c.keys[connectFor] || "";
    Array.prototype.forEach.call(document.querySelectorAll("#ai-providers [data-p]"), function (b) {
      var id = b.getAttribute("data-p");
      b.classList.toggle("active", id === connectFor);
      b.querySelector(".on-dot").hidden = !(c.keys[id] && c.provider === id);
    });
    $("ai-key").value = key;
    $("ai-key").placeholder = "Paste your " + p.company + " key";
    $("ai-key-link").href = p.keyUrl;
    $("ai-key-link").textContent = "Get a key from " + p.company;
    $("ai-forget").hidden = !key;
    $("ai-save").textContent = key && c.provider === connectFor ? "Save" : key ? "Use " + p.name : "Connect";
    $("ai-data-note").textContent = "Each question sends " + p.company + " your question and its matching offers " +
      "(store, offer, card and ending, expiry, category). Your key stays in this browser.";
    var st = $("ai-status");
    st.textContent = status || (c.provider === connectFor && key ? "Connected. Answers come from " + p.name + "." : "");
    st.classList.toggle("error", !!isError);
    if (key && !status) fillModels(ids);
    else if (!key) $("ai-model-row").hidden = true;
  }

  // Lists the models this key can use; the one in use stays selected.
  function fillModels(known) {
    var c = UOH_AI.config(), forP = connectFor;
    (known ? Promise.resolve(known.slice()) : UOH_AI.models(forP)).then(function (ids) {
      if (forP !== connectFor) return;
      var cur = c.models[forP] || UOH_AI.PROVIDERS[forP].pick(ids);
      if (ids.indexOf(cur) < 0) ids.unshift(cur);
      $("ai-model").innerHTML = ids.map(function (id) {
        return '<option value="' + esc(id) + '"' + (id === cur ? " selected" : "") + ">" + esc(id) + "</option>";
      }).join("");
      $("ai-model-row").hidden = false;
    }, function () { $("ai-model-row").hidden = true; });
  }

  function saveConnect() {
    var key = $("ai-key").value.trim(), forP = connectFor;
    if (!key) { renderConnect("Paste a key first.", true); return; }
    $("ai-save").disabled = true;
    $("ai-status").classList.remove("error");
    $("ai-status").textContent = "Checking the key with " + UOH_AI.PROVIDERS[forP].company + "…";
    UOH_AI.connect(forP, key).then(function (ids) {
      renderConnect(null, false, ids);
      renderAiLine();
    }, function (e) {
      renderConnect(e.status === 401 || e.status === 403 || e.status === 400
        ? "That key didn't work: " + e.message : "Couldn't reach " + UOH_AI.PROVIDERS[forP].company + ": " + e.message, true);
      $("ai-key").value = key;
    }).then(function () { $("ai-save").disabled = false; });
  }

  function askCtx() { return { now: Date.now(), cards: cardList() }; }

  /* ---------- chat ----------
   * A conversation keeps its filters until New chat (UOH.readChatMessage).
   * Every reply lists every match: 15 rows, then 300 more per click. The
   * thread lives in this page only: New chat, a reload or an emptied hub
   * clears it. */
  var PLACEHOLDER = "Ask about your offers, e.g. any luggage offers from Away or Samsonite?";
  var chat = { turns: [], gen: 0, ctrl: null, expanded: false };

  function lastDone() {
    for (var i = chat.turns.length - 1; i >= 0; i--) if (chat.turns[i].status === "done") return chat.turns[i];
    return null;
  }

  // opts.fresh: leave earlier messages out; opts.replace: the turn to redo.
  function ask(q, opts) {
    q = String(q || "").trim();
    opts = opts || {};
    if (!q || asking) return;
    var ctx = askCtx(), prev = opts.fresh ? null : lastDone();
    var read = UOH.readChatMessage(q, prev ? prev.plan : null, ctx);
    var turn = { q: q, plan: read.plan, action: read.action, cont: read.cont, matches: [], picks: [], points: [],
                 answer: "", ai: "", who: UOH_AI.ready() && !read.command ? UOH_AI.name() : "", note: "", shown: 15, status: "working" };
    if (opts.replace != null) chat.turns[opts.replace] = turn; else chat.turns.push(turn);
    asking = true;
    $("ask-btn").disabled = true;
    $("ai-btn").classList.add("busy");
    renderChat();
    var gen = chat.gen;
    var ctrl = chat.ctrl = typeof AbortController !== "undefined" ? new AbortController() : null;
    // Commands on the last list ("as csv", "show all") don't need the model.
    var run = function (r) {
      if (!UOH_AI.ready() || r.command) {
        return Promise.resolve({ answer: "", picks: [], matches: UOH_AI.find(q, rows, ctx, {}, r.plan).matches, plan: {} });
      }
      return UOH_AI.ask(q, rows, ctx, UOH_CATS.LIST, {
        local: r.plan, subject: r.subject, readBack: UOH.describePlan(r.plan, ctx).join("; "), top: r.action.top,
        signal: ctrl && ctrl.signal
      }).then(function (res) { res.ai = UOH_AI.name(); return res; });
    };
    run(read).then(function (res) {
      if (gen !== chat.gen || res.matches.length || !read.cont) return res;
      // Nothing fits together with the earlier filters: try the message alone.
      var fresh = UOH.readChatMessage(q, null, ctx);
      return run(fresh).then(function (res2) {
        if (!res2.matches.length) return res;
        turn.plan = fresh.plan;
        turn.cont = false;
        turn.note = "Nothing matched together with your earlier filters, so this searched all your offers.";
        return res2;
      });
    }).then(function (res) {
      if (gen === chat.gen) finishTurn(turn, res);
    }, function (e) {
      if (gen !== chat.gen || (e && e.name === "AbortError")) return;
      turn.status = "error";
      turn.answer = "Couldn't get an answer: " + ((e && e.message) || e);
    }).then(function () {
      if (gen !== chat.gen) return; // New chat started meanwhile
      asking = false;
      chat.ctrl = null;
      $("ask-btn").disabled = false;
      $("ai-btn").classList.remove("busy");
      renderChat();
    });
  }

  function finishTurn(t, res) {
    // Keep the model's search ideas so a follow-up searches the same way.
    var p = res.plan || {};
    t.plan.brands = t.plan.brands.concat(p.brands || []);
    t.plan.keywords = t.plan.keywords.concat(p.keywords || []);
    if (!t.plan.giftCards) (p.categories || []).forEach(function (c) { if (t.plan.categories.indexOf(c) < 0) t.plan.categories.push(c); });
    var m = t.action.top ? res.matches.slice(0, t.action.top) : res.matches;
    t.matches = m;
    t.picks = (res.picks || []).filter(function (r) { return m.indexOf(r) > -1; });
    t.ai = res.ai && res.answer ? res.ai : "";
    t.answer = res.answer || ruleText(t);
    t.points = t.ai ? res.points || [] : [];
    if (res.error) {
      t.note = (t.note ? t.note + " " : "") + "Couldn't get an answer from " + res.ai + ": " + res.error + "." +
        (res.status === 401 || res.status === 403 ? " Check the key with Change, below." : "") +
        " These are the matches found by plain rules.";
    }
    if (t.action.showAll) t.shown = Math.max(t.shown, Math.min(m.length, 300));
    t.status = "done";
  }

  // The reply when the model is off, or for a command.
  function ruleText(t) {
    var n = t.matches.length, a = t.action;
    if (!n) return "None of your saved offers match that.";
    var count = n.toLocaleString() + (n === 1 ? " offer" : " offers");
    if (a.file) return "Here's a " + a.file.toUpperCase() + " file with " + (n === 1 ? "this offer." : "these " + count + ".");
    if (a.top && n === 1) return "The biggest match is **" + t.matches[0].m + "**: " + t.matches[0].v + " on " + cardsText(t.matches[0]) + ".";
    if (a.top) return "The top " + n + " by value.";
    var best = null, bestUsd = 0;
    t.matches.forEach(function (r) {
      var u = r.usd != null ? r.usd : UOH.estValueUsd(r.v);
      if (u != null && u > bestUsd) { bestUsd = u; best = r; }
    });
    return "**" + count + "** match." + (best && n > 1 ? " The largest is **" + best.m + "**: " + best.v + " on " + cardsText(best) + "." : "");
  }

  // Escaped first, then **bold** and "- " lists, so the model can't add HTML.
  var LIST_MARK = /^\s*(?:[-*•]|\d+[.)])\s+/;
  function inline(text) { return esc(String(text || "").replace(LIST_MARK, "")).replace(/\*\*([^*]+)\*\*/g, "<strong>$1</strong>"); }
  function richText(text) {
    var html = "", inList = false;
    String(text || "").split(/\n+/).forEach(function (line) {
      if (LIST_MARK.test(line)) {
        if (!inList) { html += "<ul>"; inList = true; }
        html += "<li>" + inline(line) + "</li>";
        return;
      }
      if (inList) { html += "</ul>"; inList = false; }
      if (line.trim()) html += "<p>" + inline(line) + "</p>";
    });
    return html + (inList ? "</ul>" : "");
  }

  function cardsText(r) { return r.cards.map(function (c) { return c.label; }).join(", "); }
  // The offers the model mentioned come first, unless the question set an
  // order (biggest first, soonest first, A to Z); then they're only marked.
  function orderedRows(t) {
    if (t.plan.sort && t.plan.sort !== "score") return t.matches;
    return t.picks.concat(t.matches.filter(function (r) { return t.picks.indexOf(r) < 0; }));
  }
  function readAs(t) { return UOH.describePlan(t.plan, askCtx()); }

  function turnHtml(t, i) {
    var html = '<div class="turn" data-i="' + i + '"><div class="msg me">' + esc(t.q) + "</div>";
    if (t.status === "working") return html + '<div class="msg bot"><div class="answer-label">' +
      esc(t.who ? "Asking " + t.who + "…" : "Searching…") + "</div></div></div>";
    if (t.status === "error") return html + '<div class="msg bot"><div class="bot-text">' + esc(t.answer) + "</div></div></div>";
    var rb = readAs(t), n = t.matches.length, last = i === chat.turns.length - 1;
    html += '<div class="msg bot">' +
      (t.ai ? '<div class="answer-label">' + esc(t.ai) + "</div>" : "") +
      '<div class="bot-text">' + richText(t.answer) +
      (t.points.length ? "<ul>" + t.points.map(function (p) { return "<li>" + inline(p) + "</li>"; }).join("") + "</ul>" : "") +
      "</div>" +
      (t.note ? '<div class="bot-note">' + esc(t.note) + "</div>" : "") +
      '<div class="read-as">' + esc((rb.length ? "Looked for: " + rb.join(" · ") : "Looked through all your offers") +
        (t.cont ? " (with your earlier filters)" : "")) +
        (last && t.cont ? ' <button class="link" data-fresh="' + i + '">Search all offers instead</button>' : "") + "</div>";
    if (t.action.file && n) {
      html += '<div class="file-chip"><span class="file-name">' + esc(fileName(t, t.action.file)) + '</span><span class="dim">' +
        n.toLocaleString() + (n === 1 ? " offer" : " offers") + '</span><button class="btn-primary" data-dl="' + i +
        '" data-kind="' + t.action.file + '">Download</button></div>';
    }
    if (n) {
      var now = Date.now(), left = n - t.shown;
      html += '<div class="chat-table-wrap"><table class="chat-table"><thead><tr><th>Store</th><th>Offer</th><th>Card</th><th>Expires</th></tr></thead><tbody>' +
        orderedRows(t).slice(0, t.shown).map(function (r) {
          var dl = UOH.daysLeft(r, now);
          return "<tr" + (t.picks.indexOf(r) > -1 ? ' class="pick"' : "") + '><td class="s">' + esc(r.m) +
            (UOH.isNew(r, now) ? ' <span class="new-tag">NEW</span>' : "") + '</td><td class="o">' + esc(r.v) +
            '</td><td class="c">' + esc(cardsText(r)) + '</td><td class="e">' +
            esc(r.expiresTs ? (dl === 0 ? "today" : dl === 1 ? "1 day" : dl + " days") : "no end date") + "</td></tr>";
        }).join("") + "</tbody></table></div>" +
        '<div class="bot-actions">' +
        (left > 0 ? '<button class="btn-ghost" data-more="' + i + '">Show ' + Math.min(left, 300).toLocaleString() + " more</button>" : "") +
        '<button class="btn-ghost" data-dl="' + i + '" data-kind="csv">Download CSV</button>' +
        '<button class="btn-ghost" data-copy="' + i + '">Copy</button>' +
        '<span class="bot-count">' + (left > 0 ? "Showing " + t.shown.toLocaleString() + " of " : "") +
        n.toLocaleString() + (n === 1 ? " offer" : " offers") + "</span></div>";
    }
    return html + "</div></div>";
  }

  function renderChat() {
    var box = $("thread"), has = chat.turns.length > 0;
    box.hidden = !has;
    $("chat-new").hidden = !has;
    $("ask-chips").hidden = has;
    $("ask-input").placeholder = has ? "Ask a follow-up: only Chase, what about dining, sort by value, as CSV…" : PLACEHOLDER;
    box.innerHTML = chat.turns.map(turnHtml).join("");
    // Show the newest question and the start of its reply.
    var last = box.lastElementChild;
    if (last) box.scrollTop = last.offsetTop - 4;
  }
  function renderTurn(i) {
    var el = $("thread").querySelector('.turn[data-i="' + i + '"]');
    if (el) el.outerHTML = turnHtml(chat.turns[i], i);
  }

  function newChat() {
    chat.gen++;
    if (chat.ctrl) { try { chat.ctrl.abort(); } catch (e) {} }
    chat.ctrl = null;
    chat.turns = [];
    asking = false;
    $("ask-btn").disabled = false;
    $("ai-btn").classList.remove("busy");
    renderChat();
  }

  function setExpanded(on) {
    chat.expanded = on;
    $("ask").classList.toggle("expanded", on);
    document.body.classList.toggle("chat-open", on);
    $("chat-expand").textContent = on ? "Collapse" : "Expand";
    renderChat();
    $("ask-input").focus();
  }

  // The chat stays out of the way until the AI button opens it. Cancel
  // closes it and clears the conversation, so it opens fresh next time.
  function openChat() {
    $("ask").hidden = false;
    $("ai-btn").classList.add("on");
    $("ask-input").focus();
  }
  function closeChat() {
    if (chat.expanded) setExpanded(false);
    newChat();
    $("ask-input").value = "";
    $("ask").hidden = true;
    $("ai-btn").classList.remove("on");
  }

  function fileName(t, kind) {
    var slug = UOH.describePlan(t.plan, {}).join(" ").toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "").slice(0, 48);
    return "offer-hub-" + (slug || "offers") + "-" + new Date().toISOString().slice(0, 10) + "." + kind;
  }

  // Built on click, from the reply's own list, in the main CSV's columns.
  function downloadTurn(i, kind) {
    var t = chat.turns[i];
    if (!t) return;
    var recs = [], opts = { now: Date.now(), cards: S.settings.cards, categoryOf: catOf };
    orderedRows(t).forEach(function (r) { recs = recs.concat(r.records); });
    if (kind === "json") saveFile(JSON.stringify(UOH.toLiveJson(recs, opts), null, 2), "application/json", fileName(t, "json"));
    else saveFile(UOH.toCsv(recs, opts), "text/csv;charset=utf-8", fileName(t, "csv"));
  }

  function onThreadClick(e) {
    var b = e.target.closest("button[data-more], button[data-dl], button[data-copy], button[data-fresh]");
    if (!b) return;
    var i = +(b.getAttribute("data-more") || b.getAttribute("data-dl") || b.getAttribute("data-copy") || b.getAttribute("data-fresh"));
    var t = chat.turns[i];
    if (!t) return;
    if (b.hasAttribute("data-more")) { t.shown = Math.min(t.matches.length, t.shown + 300); renderTurn(i); }
    else if (b.hasAttribute("data-dl")) downloadTurn(i, b.getAttribute("data-kind"));
    else if (b.hasAttribute("data-copy")) copyRows(orderedRows(t), readAs(t).join(", "));
    else ask(t.q, { fresh: true, replace: i });
  }

  /* ---------- copy, CSV ---------- */
  var COPY_MAX = 500;
  function catOf(o) { return UOH_CATS.categorize(o.m, o.v, S.cats); }
  // A list as plain text, up to COPY_MAX rows, headed by what it is.
  function copyRows(list, filters) {
    if (!list.length) return;
    var take = list.slice(0, COPY_MAX);
    var text = UOH.rowsAiText(take, { now: Date.now(), total: list.length, filters: filters });
    navigator.clipboard.writeText(text).then(function () {
      toast("Copied " + take.length.toLocaleString() + (take.length === 1 ? " offer" : " offers") +
            (list.length > take.length ? " (the first " + COPY_MAX + " of " + list.length.toLocaleString() + "; filter to copy fewer)" : "") + ".", 6000);
    }, function () { toast("Couldn't copy to the clipboard."); });
  }
  // The table's Copy: the rows it shows now (view, filters, search, sort).
  function copyList() { copyRows(filtered(), describeFilters()); }
  function saveFile(data, type, name) {
    var a = document.createElement("a");
    a.href = URL.createObjectURL(new Blob([data], { type: type }));
    a.download = name;
    a.click();
    setTimeout(function () { URL.revokeObjectURL(a.href); }, 60000);
  }
  function exportCsv() {
    var recs = records();
    if (!recs.length) { toast("No saved offers yet."); return; }
    saveFile(UOH.toCsv(recs, { now: Date.now(), cards: S.settings.cards, categoryOf: catOf }), "text/csv;charset=utf-8",
             "universal_offer_hub_" + new Date().toISOString().slice(0, 10) + ".csv");
  }

  /* ---------- open AI chat: continue in ChatGPT, Claude or Gemini ----------
   * Their chat pages can't take a file from another site, so the CSV is
   * downloaded for the user to drop in, with a starter message on the
   * clipboard. Uses the user's own account there; no key. */
  var CHAT_SITES = {
    chatgpt: { name: "ChatGPT", url: "https://chatgpt.com/" },
    claude: { name: "Claude", url: "https://claude.ai/new" },
    gemini: { name: "Gemini", url: "https://gemini.google.com/app" }
  };
  function toggleExtPop() {
    var pop = $("ext-pop"), r = $("ext-chat-btn").getBoundingClientRect();
    if (!pop.hidden) { pop.hidden = true; return; }
    pop.hidden = false;
    pop.style.top = (r.bottom + 6) + "px";
    pop.style.left = Math.max(8, Math.min(r.right - pop.offsetWidth, window.innerWidth - pop.offsetWidth - 8)) + "px";
  }
  function openAiChat(site) {
    var s = CHAT_SITES[site], now = Date.now();
    var recs = records().filter(function (o) { return UOH.isActive(o, now); });
    $("ext-pop").hidden = true;
    if (!recs.length) { toast("No active offers to send yet."); return; }
    var date = new Date(now).toISOString().slice(0, 10), name = "offer-hub-offers-" + date + ".csv";
    saveFile(UOH.toChatCsv(recs, { now: now, cards: S.settings.cards, categoryOf: catOf }), "text/csv;charset=utf-8", name);
    var starter = "I've attached " + name + ": my saved credit card and store offers (" + recs.length.toLocaleString() +
      " rows, as of " + date + "). Each row is one offer on one card: store, offer, card name and ending, expiry, " +
      "days left, category and source. Answer my questions using only these offers, and say which card holds each " +
      "offer you suggest.\n\nMy question: ";
    // Clipboard first: it needs this page in front.
    var go = function () { chrome.tabs.create({ url: s.url }); };
    navigator.clipboard.writeText(starter).then(go, go);
  }

  /* ---------- Claude Desktop: set up once, in three steps ----------
   * 1. the live copy (the folder the plugin reads), 2. the plugin file, made
   * here from this extension's own files (lib/mcpb.js), 3. opening it in
   * Claude Desktop, which installs it and asks for that folder. */
  var deskSaved = false;
  var TICK = '<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3.5 8.5l3 3 6-7"/></svg>';

  function openDesk() { $("ext-pop").hidden = true; $("desk-panel").hidden = false; renderDesk(); }
  function closeDesk() { $("desk-panel").hidden = true; }

  function step(n, done, title, note, action) {
    return '<li class="step' + (done ? " done" : "") + '"><span class="num">' + (done ? TICK : n) + "</span>" +
      '<div><div class="step-title">' + esc(title) + '</div><div class="step-note">' + note + "</div></div>" +
      (action ? '<div class="step-act">' + action + "</div>" : "") + "</li>";
  }
  function deskButton(what, label, primary) {
    return '<button class="' + (primary ? "btn-primary" : "btn-ghost") + '" data-desk="' + what + '">' + label + "</button>";
  }
  // A short folder name stays on one line.
  function folderName(name) {
    var q = '"' + esc(name) + '"';
    return name.length <= 24 ? '<span class="nowrap">' + q + "</span>" : q;
  }
  function renderDesk() {
    if ($("desk-panel").hidden) return;
    var st = S.live || {}, dir = st.dir ? folderName(st.dir) : "", first = "Keep a live copy of your offers", one;
    if (st.status === "ok") {
      one = step(1, true, first, "Saving to " + dir + ".", deskButton("choose", "Change"));
    } else if (st.status === "needs-permission") {
      one = step(1, false, first, "Paused: Chrome needs your OK to keep updating " + (dir || "the folder") +
                 '. Then pick "Allow on every visit".', deskButton("grant", "Keep updating", true));
    } else if (st.status === "error") {
      one = step(1, false, first, "Couldn't save there: " + esc(st.error || "unknown error") + ".", deskButton("grant", "Try again", true));
    } else {
      one = step(1, false, first, st.status === "missing" ? "That folder is gone. Choose it again, or a new one."
        : 'A new folder, such as "Offer Hub" in your home folder. Not one synced to iCloud, OneDrive or Google Drive.',
        deskButton("choose", "Choose a folder", true));
    }
    $("desk-steps").innerHTML = one +
      step(2, deskSaved, "Get the plugin", deskSaved ? "Saved " + esc(UOH_MCPB.NAME) + " to your downloads." : "One small file for Claude Desktop.",
           deskSaved ? deskButton("get", "Download again") : deskButton("get", "Download plugin", true)) +
      step(3, false, "Install it", "Open the downloaded file. Claude Desktop asks for a folder: pick " + (dir || "the one from step 1") + "." +
           '<span class="quiet">Doesn\'t open? Use Install Extension in Claude\'s extension settings. ' +
           '<a href="https://claude.ai/download" target="_blank" rel="noopener noreferrer">Get Claude Desktop</a></span>');
  }

  // Its icon in Claude's extension list: the hub's badge, at the 512 px Claude recommends.
  function pluginIcon() {
    return new Promise(function (resolve) {
      try {
        var c = document.createElement("canvas");
        c.width = c.height = 512;
        var g = c.getContext("2d"), grad = g.createLinearGradient(0, 0, 512, 512);
        grad.addColorStop(0, "#3b82f6"); grad.addColorStop(1, "#8b5cf6");
        g.fillStyle = grad;
        g.beginPath(); g.roundRect(0, 0, 512, 512, 128); g.fill();
        g.fillStyle = "#fff"; g.textAlign = "center"; g.textBaseline = "middle";
        g.font = "800 190px " + getComputedStyle(document.body).fontFamily;
        g.fillText("UO", 256, 264);
        c.toBlob(function (b) {
          if (!b) { resolve(null); return; }
          b.arrayBuffer().then(function (buf) { resolve(new Uint8Array(buf)); }, function () { resolve(null); });
        }, "image/png");
      } catch (e) { resolve(null); }
    });
  }

  function downloadPlugin() {
    var read = function (p) {
      return fetch(chrome.runtime.getURL(p)).then(function (r) {
        if (!r.ok) throw new Error(p + " is missing");
        return r.arrayBuffer();
      });
    };
    pluginIcon().then(function (icon) {
      return UOH_MCPB.build(read, chrome.runtime.getManifest().version, icon);
    }).then(function (zip) {
      saveFile(zip, "application/zip", UOH_MCPB.NAME);
      deskSaved = true;
      renderDesk();
    }).catch(function (e) { toast("Couldn't make the plugin file: " + ((e && e.message) || e)); });
  }

  /* ---------- live copy (lib/livefile.js) ---------- */
  function renderLive() {
    var el = $("live-line"), st = S.live || {};
    var manage = ' <button class="link" id="live-choose">Change folder</button> <button class="link" id="live-stop">Stop</button>';
    if (!st.status || st.status === "off") {
      el.innerHTML = "Live copy for AI apps: off." + ' <button class="link" id="live-choose">Choose a folder</button>' +
        esc(" Pick one that isn't synced to iCloud, OneDrive or Google Drive.");
    } else if (st.status === "ok") {
      el.innerHTML = "Live copy: " + esc(st.dir || "folder") + " · updated " + esc(ago(st.lastWriteAt)) + manage;
    } else if (st.status === "needs-permission") {
      el.innerHTML = "Live copy paused: Chrome needs your OK to keep updating " + esc(st.dir || "the folder") + "." +
        ' <button class="link" id="live-grant">Keep updating</button> (pick "Allow on every visit")' + manage;
    } else if (st.status === "missing") {
      el.innerHTML = "Live copy folder not found." + manage;
    } else {
      el.innerHTML = "Live copy error: " + esc(st.error || "unknown") + ' <button class="link" id="live-grant">Try again</button>' + manage;
    }
    if ($("live-choose")) $("live-choose").onclick = chooseFolder;
    if ($("live-grant")) $("live-grant").onclick = grantFolder;
    if ($("live-stop")) $("live-stop").onclick = function () {
      UOH_LIVE.clearDir().then(function () { return UOH_LIVE.setStatus({ status: "off" }); });
    };
    renderDesk();
  }

  function chooseFolder() {
    if (!window.showDirectoryPicker) { toast("This Chrome can't pick folders."); return; }
    // No startIn: Documents and Desktop are cloud-synced on many machines.
    window.showDirectoryPicker({ id: "uoh-live", mode: "readwrite" }).then(function (dir) {
      return UOH_LIVE.setDir(dir).then(function () { return send({ type: "UOH_LIVE_EXPORT" }); });
    }).then(function (st) {
      if (st && st.status === "ok") {
        toast("Your offers are saved in \"" + st.dir + "\" and kept up to date. If Chrome asks later, " +
              "click Keep updating and pick \"Allow on every visit\".", 8000);
      }
    }).catch(function (e) {
      if (e && e.name === "AbortError") return;
      // Chrome refuses the home, Documents, Desktop and Downloads folders themselves.
      toast("Chrome won't use that folder. Make a new folder inside it (for example \"Offer Hub\" in your home folder) and pick that.", 8000);
    });
  }

  function grantFolder() {
    UOH_LIVE.getDir().then(function (dir) {
      if (!dir) return chooseFolder();
      return dir.requestPermission({ mode: "readwrite" }).then(function (p) {
        if (p === "granted") return send({ type: "UOH_LIVE_EXPORT" });
        toast("Chrome didn't allow writing to the folder. Use Change folder or Stop.");
      });
    }).catch(function (e) { toast("Couldn't reach the live copy's folder: " + ((e && e.message) || e)); });
  }

  /* ---------- events ---------- */
  function bind() {
    $("views").addEventListener("click", function (e) {
      var b = e.target.closest(".view"); if (!b) return;
      UI.view = b.getAttribute("data-view"); limit = 300; saveUI(); renderViews(); renderTable();
    });
    $("search").addEventListener("input", function (e) { UI.query = e.target.value; limit = 300; saveUI(); renderTable(); });
    $("more-btn").addEventListener("click", function () { limit += 300; renderTable(); });

    $("head-row").addEventListener("click", function (e) {
      var s = e.target.closest(".th-sort"), f = e.target.closest(".th-filter");
      if (s) {
        var k = s.getAttribute("data-sort");
        // A new column starts in its natural order: A to Z, soonest first, biggest offer first.
        UI.sort = UI.sort.key === k ? { key: k, dir: -UI.sort.dir } : { key: k, dir: k === "offer" ? -1 : 1 };
        saveUI(); renderTable();
      } else if (f) {
        e.stopPropagation();
        openPop(f.getAttribute("data-filter"), f);
      }
    });
    $("filter-pop").addEventListener("change", onPopChange);
    $("filter-pop").addEventListener("click", function (e) {
      if (e.target.getAttribute("data-all")) setFilter(popKind, allValues(popKind));
      else if (e.target.getAttribute("data-none")) setFilter(popKind, []);
    });
    document.addEventListener("click", function (e) {
      if (!$("filter-pop").hidden && !e.target.closest("#filter-pop") && !e.target.closest(".th-filter")) closePop();
    });
    window.addEventListener("resize", closePop);
    window.addEventListener("scroll", closePop, { passive: true });
    $("clear-filters").addEventListener("click", function () {
      UI.f = { cards: null, cats: null, types: null, exp: "any" };
      limit = 300; saveUI(); closePop(); renderTable();
    });

    $("ask-form").addEventListener("submit", function (e) {
      e.preventDefault();
      var q = $("ask-input").value;
      if (!q.trim() || asking) return;
      $("ask-input").value = "";
      ask(q);
    });
    $("ask-chips").innerHTML = EXAMPLES.map(function (q) { return '<button class="chip" type="button">' + esc(q) + "</button>"; }).join("");
    $("ask-chips").addEventListener("click", function (e) {
      var b = e.target.closest(".chip"); if (!b) return;
      ask(b.textContent);
    });
    $("thread").addEventListener("click", onThreadClick);
    $("ai-btn").addEventListener("click", openChat);
    $("chat-close").addEventListener("click", closeChat);
    $("chat-new").addEventListener("click", function () { newChat(); $("ask-input").focus(); });
    $("chat-expand").addEventListener("click", function () { setExpanded(!chat.expanded); });

    $("ai-close").addEventListener("click", closeConnect);
    $("ai-panel").addEventListener("click", function (e) { if (e.target === $("ai-panel")) closeConnect(); });
    $("ai-providers").addEventListener("click", function (e) {
      var b = e.target.closest("[data-p]"); if (!b) return;
      connectFor = b.getAttribute("data-p");
      renderConnect();
      $("ai-key").focus();
    });
    $("ai-save").addEventListener("click", saveConnect);
    $("ai-key").addEventListener("keydown", function (e) { if (e.key === "Enter") saveConnect(); });
    $("ai-model").addEventListener("change", function (e) {
      UOH_AI.setModel(connectFor, e.target.value).then(renderAiLine);
    });
    $("ai-forget").addEventListener("click", function () {
      UOH_AI.disconnect(connectFor).then(function () { renderConnect("Key removed from this browser."); renderAiLine(); });
    });

    $("ext-chat-btn").addEventListener("click", function (e) { e.stopPropagation(); toggleExtPop(); });
    $("ext-pop").addEventListener("click", function (e) {
      var b = e.target.closest("[data-site]"); if (b) openAiChat(b.getAttribute("data-site"));
    });
    document.addEventListener("click", function (e) {
      if (!$("ext-pop").hidden && !e.target.closest("#ext-pop") && !e.target.closest("#ext-chat-btn")) $("ext-pop").hidden = true;
    });
    $("desk-open").addEventListener("click", openDesk);
    $("desk-close").addEventListener("click", closeDesk);
    $("desk-panel").addEventListener("click", function (e) {
      if (e.target === $("desk-panel")) { closeDesk(); return; }
      var b = e.target.closest("[data-desk]"), what = b && b.getAttribute("data-desk");
      if (what === "choose") chooseFolder();
      else if (what === "grant") grantFolder();
      else if (what === "get") downloadPlugin();
    });

    $("copy-list").addEventListener("click", copyList);
    $("csv-btn").addEventListener("click", exportCsv);
    $("cards-btn").addEventListener("click", openCards);
    $("cards-close").addEventListener("click", closeCards);
    $("cards-panel").addEventListener("click", function (e) { if (e.target === $("cards-panel")) closeCards(); });
    document.addEventListener("keydown", function (e) {
      if (e.key !== "Escape") return;
      if (drag) endDrag();   // mid-drag, Escape only drops the drag
      else if (!$("filter-pop").hidden) closePop();
      else if (!$("ext-pop").hidden) $("ext-pop").hidden = true;
      else if (!$("ai-panel").hidden) closeConnect();
      else if (!$("desk-panel").hidden) closeDesk();
      else if (!$("cards-panel").hidden) closeCards();
      else if (chat.expanded) setExpanded(false);
    });
    $("cards-body").addEventListener("click", function (e) {
      var b = e.target.closest("button");
      if (!b) return;
      var up = b.getAttribute("data-up"), down = b.getAttribute("data-down"), conf = b.getAttribute("data-confirm");
      if (up) moveCard(b, up, -1);
      else if (down) moveCard(b, down, 1);
      else if (conf) confirmLogin(conf);
      else if (b.hasAttribute("data-addnow")) addNow();
      else if (b.hasAttribute("data-rm")) askRemove(b);
      else if (b.hasAttribute("data-rm-yes")) removeCard(b.getAttribute("data-rm-yes"));
      else if (b.hasAttribute("data-rm-no")) b.closest(".card-confirm").remove();
    });
    $("cards-body").addEventListener("change", function (e) {
      if (e.target.hasAttribute("data-add")) { setAdd(e.target); return; }
      var key = e.target.getAttribute("data-nick");
      if (!key) return;
      var patch = {};
      patch[key] = { nick: e.target.value.trim() };
      send({ type: "UOH_PATCH_SETTINGS", patch: { cards: patch } });
    });

    /* Drag a card by its grip. The row is draggable only while the grip is
     * held, so the nickname box still selects text and takes typing. A drop
     * counts only inside the row's own group; a line shows where it lands. */
    var drag = null;   // { row, list, key, on (dragging started), to (moveKey index) }
    function marks(row, after) {
      Array.prototype.forEach.call($("cards-body").querySelectorAll(".drop-before, .drop-after"), function (r) {
        r.classList.remove("drop-before", "drop-after");
      });
      if (row) row.classList.add(after ? "drop-after" : "drop-before");
    }
    function endDrag() {
      if (!drag) return;
      drag.row.removeAttribute("draggable");
      drag.row.classList.remove("dragging");
      marks(null);
      drag = null;
      resume();
    }
    $("cards-body").addEventListener("pointerdown", function (e) {
      var grip = e.button === 0 && e.target.closest(".grip"), row = grip && grip.closest(".card-item");
      if (!row || row.classList.contains("solo")) return;
      endDrag();
      drag = { row: row, list: row.parentNode, key: row.getAttribute("data-key"), on: false, to: null };
      row.draggable = true;
    });
    // Released without dragging. (Once a drag starts, dragend comes instead.)
    document.addEventListener("pointerup", function () { if (drag && !drag.on) endDrag(); });
    $("cards-body").addEventListener("dragstart", function (e) {
      if (!drag || e.target !== drag.row) return;
      drag.on = true;
      e.dataTransfer.effectAllowed = "move";
      // Not text/plain: a nickname box would take that as typed text.
      e.dataTransfer.setData("application/x-uoh-card", drag.key);
      var row = drag.row;
      // On the row itself, so the drag still ends cleanly if the row has
      // left the page by then.
      row.addEventListener("dragend", endDrag);
      // Dimmed after the browser has taken its picture of the row.
      setTimeout(function () { if (drag && drag.row === row) row.classList.add("dragging"); }, 0);
    });
    $("cards-body").addEventListener("dragover", function (e) {
      if (!drag || !drag.on) return;
      if (e.target.closest(".card-list") !== drag.list) { marks(null); drag.to = null; return; }
      e.preventDefault();
      e.dataTransfer.dropEffect = "move";
      var row = e.target.closest(".card-item");
      if (!row) return;   // in the gap between two rows: the line stays put
      var keys = rowKeys(drag.list), r = row.getBoundingClientRect(), after = e.clientY > r.top + r.height / 2;
      var to = UOH.dropIndex(keys, drag.key, row.getAttribute("data-key"), after);
      drag.to = to === keys.indexOf(drag.key) ? null : to;
      marks(drag.to == null ? null : row, after);
    });
    $("cards-body").addEventListener("drop", function (e) {
      if (!drag || !drag.on || e.target.closest(".card-list") !== drag.list) return;
      e.preventDefault();
      if (drag.to != null) setOrder(drag.list, UOH.moveKey(rowKeys(drag.list), drag.key, drag.to));
      endDrag();
    });

    var timer = null, deferred = false;
    // A re-render replaces the Cards panel; wait while a nickname is being
    // typed or a card is held for dragging.
    function refresh() {
      if (drag || (document.activeElement && document.activeElement.classList.contains("nick"))) { deferred = true; return; }
      load().then(renderAll);
    }
    function resume() {
      if (deferred) { deferred = false; setTimeout(refresh, 50); }
    }
    chrome.storage.onChanged.addListener(function (changes, area) {
      if (area === "local" && changes.UOH_AIConfig) UOH_AI.load().then(renderAiLine);
      var relevant = area === "session" ? !!changes.UOH_Run
        : !!(changes.UOH_Database || changes.UOH_Settings || changes.UOH_Categories || changes.UOH_AutoState || changes.UOH_LiveFile);
      if (!relevant) return;
      clearTimeout(timer);
      timer = setTimeout(refresh, 300);
    });
    $("cards-body").addEventListener("focusout", resume);
    window.addEventListener("hashchange", function () { if (location.hash === "#cards") openCards(); });
  }

  /* ---------- init ---------- */
  $("search").value = UI.query || "";
  bind();
  load().then(function () {
    renderAll();
    if (location.hash === "#cards") openCards();
    if (S.live && S.live.status === "ok") send({ type: "UOH_LIVE_EXPORT" }); // refresh while the grant is live
  });
  UOH_AI.load().then(renderAiLine);
})();
