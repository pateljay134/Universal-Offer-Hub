# Universal Offer Hub

An unpacked Chrome / Edge / Brave extension that:

- Auto-detects the active tab and runs the right offer autopilot (Chase, Amex, Capital One, Walgreens).
- Saves every clicked / harvested offer to local browser storage — **no network calls, no sign-up, no remote server**.
- Lets you search across every saved card / store with multi-word AND, partial match, scoring, source filters, type filters, value sort, and CSV export.

---

## Install (developer mode)

1. Open `chrome://extensions` (or `edge://extensions`, `brave://extensions`).
2. Toggle **Developer mode** on.
3. Click **Load unpacked**.
4. Select this folder (`Universal-Offer-Hub`).
5. Pin the icon to the toolbar.

No store listing, no signed package. Re-run **Load unpacked** to update after edits.

---

## How to use

1. Open Chase / Amex / Capital One / Walgreens in the active tab.
2. Click the extension icon. The popup detects the site and shows a coloured **Run … Autopilot** button.
3. Click it. The original autopilot UI overlays the page exactly like the standalone bookmarklets, runs to completion, and every offer it touches is mirrored into the hub.
4. Open the popup again any time to search every saved offer across every card and store. The popup does not require you to be on a supported site to search.

If you click the icon on an unsupported tab, the popup shows quick-launch tiles for the four supported sites and still lets you search the saved offer database.

### Search syntax

- `samsung` → matches any offer where any indexed text (merchant, value, source) contains `samsung`.
- `samsung 10%` → AND. Both tokens must match. Same as `samsung & 10%`.
- `"home depot"` → space-separated still works because tokens are ANDed.
- Use the **Sort** dropdown to switch between Best match (relevance), Value high → low, A → Z, Recently saved.
- Use the chip rows to filter by source or type.

---

## Folder layout

```
Universal-Offer-Hub/
├── manifest.json
├── lib/
│   └── sources.js          shared source registry (the only file you edit to add a new site)
├── popup/
│   ├── popup.html
│   ├── popup.css
│   └── popup.js            auto-detect, search engine, filters, CSV export
├── content/
│   └── scraper.js          host-routed autopilots (Chase / Amex / Capital One / Walgreens)
├── bookmarklets/
│   ├── chase-original.txt  user-supplied original Chase script (verbatim)
│   ├── chase-enhanced.txt  user-supplied Chase script + Added Offers harvest
│   ├── amex.txt            user-supplied original Amex script (verbatim)
│   ├── walgreens.txt       user-supplied original Walgreens script (verbatim)
│   └── (Capital One)       not duplicated — preserved inside content/scraper.js
└── README.md
```

Why no Capital One file in `bookmarklets/`? It is the single longest script and is preserved verbatim inside the `host.indexOf("capitalone.com")` branch of `content/scraper.js`. The only added line in that branch is one `saveOffer(...)` call inside the existing scrape loop, so the original UI and behaviour are unchanged.

---

## Original-script preservation policy

The user's original autopilots are treated as immutable artefacts. Inside `content/scraper.js`:

- The **Chase** branch is the original autopilot with two additions: (1) one `captureChaseTile(...)` call after each tile is clicked so we mirror the offer into the hub, and (2) two new phases — `opening_added` and `scraping_added` — that fire **after** the original loop runs out of un-added tiles. They open the "Added offers" page and harvest every existing tile too, then stop. The original "Going back…" sub-navbar logic is untouched.
- The **Amex**, **Capital One**, and **Walgreens** branches are the originals with one `saveOffer(...)` call added inside their existing scrape/click loops. Selectors, timing, DOM observers, drag/min/max UI, sorting, and CSV export logic are byte-equivalent to the user-supplied bookmarklets.

The same originals also live in `bookmarklets/` as plain text so you can paste them directly into a browser bookmark URL if you want the legacy bookmarklet flow.

---

## Storage model

Everything lives in `chrome.storage.local`:

| Key | Shape | Meaning |
| --- | --- | --- |
| `UOH_Database` | `{ [key]: { m, v, site, n, t, r, ts, status?, days?, channel?, badge? } }` | All offers, keyed by `<source>_<sanitised-merchant>` |
| `UOH_LastRunCount` | `number` | How many offers the most recent autopilot run added or clipped |
| `UOH_LastRunAt` | `number` (ms) | Timestamp of the most recent autopilot run |
| `UOH_UIState` | `{ source, type, sort, query }` | Last-used popup filter state, restored on reopen |

Offer record fields:

- `m` — merchant display name
- `v` — offer value text (e.g. "10% cash back", "$200 cash back", "5,000 miles")
- `site` — source id (matches `id` in `lib/sources.js`)
- `n` — parsed numeric value, used for value sort
- `t` — type: `PERCENT`, `DOLLAR`, `MILES`, `MULTI`, `SPEND_GET`, or `OTHER`
- `r` — lowercased haystack used for substring matches
- `ts` — last-update timestamp
- `status` — `added` / `clipped` / `available` (source-dependent)

Each run **upserts** by key. So running the same autopilot again refreshes existing entries instead of duplicating them.

---

## Add a new site (Costco, Target, etc.)

1. In `lib/sources.js` add a new record to `UOH_SOURCES`:

   ```js
   {
     id: "Target",
     name: "Target Circle Offers",
     shortName: "Target",
     color: "#cc0000",
     hostPatterns: ["target.com"],
     landingUrl: "https://www.target.com/circle",
     blurb: "Adds every available Target Circle offer."
   }
   ```

2. In `manifest.json` add a host permission entry for the new domain.
3. In `content/scraper.js` add a new branch:

   ```js
   if (host.indexOf("target.com") > -1) {
     // ... your autopilot here ...
     // Call saveOffer("target_" + merchant.replace(/\W/g, ""), merchant, value, "Target");
     return;
   }
   ```

That's it — the popup's auto-detect, chip filter, and search will pick the new source up on the next open.

---

## Resetting / exporting data

- **Reset…** in the popup wipes either the currently-filtered source or everything (if the source chip is on `All sources`). It always asks for confirmation.
- **CSV** in the top-right exports every saved offer as a single CSV (`merchant, offer, source, type, numeric, status, days, channel, badge, saved_at`).
